import StudioD from './studio/StudioD';

function Mock() {
  return <StudioD state="xfade-t3" />;
}

export default Mock;
