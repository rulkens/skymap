import cx from 'classnames';
import StudioD from './studio/StudioD';
import Glyph from './studio/StudioDGlyph';
import SubjectInspector from './studio/marks/SubjectInspector';
import { approachM31Rows } from './studio/rows-approachM31';
import { rulerSteps } from './studio/rulerSteps';
import s from './studio/StudioD.module.css';

function Mock() {
  const rows = approachM31Rows();
  const { major, minor } = rulerSteps(12);
  return (
    <StudioD
      state="clip"
      clip={{
        title: 'Grand tour 02 — approach M31',
        rows,
        clipEnd: 10,
        viewEnd: 12,
        major,
        minor,
        t: 8.6,
        sel: 'aim',
        undo: 'Undo strafe',
        inspector: <SubjectInspector />,
        legend: (
          <span className={s.legendItem}><Glyph kind="subject" className={cx(s.lgIcon)} />subject</span>
        ),
      }}
    />
  );
}

export default Mock;
