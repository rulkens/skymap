import StudioD from './studio/StudioD';

function Mock() {
  return <StudioD state="cue-selected" />;
}

export default Mock;
