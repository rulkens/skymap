import StudioPhone from './studio/StudioPhone';

function Mock() {
  return <StudioPhone />;
}

export default Mock;
