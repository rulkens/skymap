import StudioB from './studio/StudioB';

function Mock() {
  return <StudioB mode="invalid" />;
}

export default Mock;
