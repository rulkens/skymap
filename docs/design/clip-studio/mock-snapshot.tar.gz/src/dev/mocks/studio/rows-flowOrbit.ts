// Rows for the real `flowOrbit` and `earthCosmicWebLoop` clips (timings from compileClip).
// Every clip gets a closing End row: the wrap is the join between a clip's end and its start,
// so `loop: true` and the seam check live there (Stop / Loop), never in a hidden clip setting.
// A perpetual step (oscillate without `over`, spin with `loop`) carries Dur '∞'; its bar runs to
// End, where the track draws the cut.
import { row } from './stepsD';

export function flowOrbitRows() {
  return [
    row('start', 0, 'start', 'Start', '', 'live view · pinned', '–', 0, 0, { writes: ['dist', 'look', 'turn'] }),
    row('bob', 0, 'osc', 'Bob tilt', '±', '6.9° /30 s', '∞', 0, 30, { ch: 'turn', bg: true, amp: 1, period: 30 }),
    row('spin', 0, 'turn', 'Turn', '+', '360°', '30 s', 0, 30, { ch: 'turn', sub: 'linear' }),
    row('end', 0, 'end', 'End', '', 'stop', '–', 30, 30, {
      sub: 'seam ✓',
      join: { kind: 'stop', a: 0, z: 30, label: 'Stop' },
    }),
  ];
}

export function earthLoopRows() {
  const legs: [string, number, number, string][] = [
    ['out1', 0, 27, '25 kpc'],
    ['out2', 27, 45, '90 kpc'],
    ['out3', 45, 70, '660 Mpc'],
  ];
  const back: [string, number, number, string][] = [
    ['back1', 74, 99, '90 kpc'],
    ['back2', 99, 117, '25 kpc'],
    ['back3', 117, 144, '19,140 km'],
  ];
  const leg = ([id, a, z, v]: [string, number, number, string]) =>
    row(id, 2, 'dist', 'Distance', '→', v, `${z - a} s`, a, z, { ch: 'dist', sub: z - a === 18 ? 'linear' : '' });
  return [
    row('start', 0, 'start', 'Start', '', 'saved view · Earth', '–', 0, 0, { writes: ['dist', 'look', 'turn'] }),
    row('labels', 0, 'hide', 'Hide', '', 'all labels', '0 s', 0, 0, { ch: 'layers' }),
    row('cycle', 0, 'all', 'Together', '', 'In order, Turn', '148 s', 0, 148, { writes: ['dist', 'turn'] }),
    row('trip', 1, 'seq', 'In order', '', 'Distance ×6 · Hold ×2', '148 s', 0, 148, { writes: ['dist'] }),
    ...legs.map(leg),
    row('holdFar', 2, 'hold', 'Hold', '', '', '4 s', 70, 74),
    ...back.map(leg),
    row('holdNear', 2, 'hold', 'Hold', '', '', '4 s', 144, 148),
    row('spin', 1, 'turn', 'Turn', '+', '360°', '148 s', 0, 148, { ch: 'turn', sub: 'linear' }),
    row('end', 0, 'end', 'End', '', 'loop ↺ 0 s', '–', 148, 148, {
      sub: 'seam ✓',
      join: { kind: 'loop', a: 0, z: 148, label: 'Loop' },
    }),
  ];
}
