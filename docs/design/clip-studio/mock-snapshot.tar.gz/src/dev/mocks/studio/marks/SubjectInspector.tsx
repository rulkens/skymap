import Panel, { Head, Grid, Sec, Row, Num, Pick, Out, Seg, Btn, Actions } from '../InspectorGrid';
import Glyph from '../StudioDGlyph';
import s from './Subject.module.css';

type Props = Record<string, never>;

// approachM31's `lookAtId`: the subject is the authored value; the bearing exists only once
// resolved against the pinned Start (Q7), so it shows read-only, dim, beside the Subject / Fixed bind.
function SubjectInspector(_: Props) {
  return (
    <Panel>
      <Head glyph="turn" ch="turn" where="Together · 1/2" range="0.0–3.0 s" title="Aim → M31" />
      <Grid>
        <Sec title="Value" />
        <Row label="Subject" tip="A named object; its position is looked up when the clip plays" span>
          <Pick>
            <Glyph kind="subject" className={s.icon} />
            M31<span className={s.alt}>Andromeda</span>
          </Pick>
          <Btn kbd="P">Pick</Btn>
        </Row>
        <Row label="Bind" tip="Subject: follows the object · Fixed: freezes today's bearing as numbers" span>
          <Seg label="Bind" options={[['subject', 'Subject', 'subject'], ['fixed', 'Fixed']]} value="subject" />
        </Row>
        <Row label="Resolves" tip="Bearing from the pinned Start; must run before any Look-at move" unit="°">
          <Out>31.7, 21.5 · from Start</Out>
        </Row>
        <Sec title="Timing" />
        <Row label="Duration" unit="s" reset>
          <Num value="3.0" fill={0.3} />
        </Row>
        <Row label="Ease">
          <Pick dim>In-out</Pick>
        </Row>
      </Grid>
      <Actions />
    </Panel>
  );
}

export default SubjectInspector;
