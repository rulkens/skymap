import type { ReactNode } from 'react';
import { useCallback, useEffect, useLayoutEffect, useRef, useState } from 'react';
import cx from 'classnames';
import s from './StudioTip.module.css';

// The studio's one tooltip: name, optional meaning, keys as chips, optional state line.
// It renders as a manual popover (top layer), so the dock's backdrop-filter cannot re-base
// it (the CompactInfoTip landmine) and placement is checked against the viewport.
// Opens 150 ms after hover, at once while another tip closed under WARM_MS ago; focus-visible
// opens it too; Escape closes; the pointer can rest on the tip (WCAG 1.4.13).
type Props = {
  readonly name: string;
  readonly meaning?: ReactNode;
  readonly keys?: readonly string[];
  readonly state?: ReactNode;
  // Preferred side; flips when the viewport has no room.
  readonly side?: 'top' | 'bottom';
  // Forced open for a shot.
  readonly open?: boolean;
  readonly className?: string;
  readonly children: ReactNode;
};

const DELAY_MS = 150;
const WARM_MS = 400;
const GAP = 8;
const EDGE = 8;
let warmUntil = 0;

function StudioTip({ name, meaning, keys, state, side = 'top', open: forced, className, children }: Props) {
  const anchor = useRef<HTMLSpanElement>(null);
  const tip = useRef<HTMLSpanElement>(null);
  const timer = useRef(0);
  const [hover, setHover] = useState(false);
  const [x, setX] = useState(0);
  const [y, setY] = useState(0);
  const [caret, setCaret] = useState(0);
  const [below, setBelow] = useState(side === 'bottom');
  const open = Boolean(forced) || hover;

  const show = useCallback(() => {
    window.clearTimeout(timer.current);
    if (performance.now() < warmUntil) setHover(true);
    else timer.current = window.setTimeout(() => setHover(true), DELAY_MS);
  }, []);
  const hide = useCallback(() => {
    window.clearTimeout(timer.current);
    timer.current = window.setTimeout(() => {
      setHover((was) => {
        if (was) warmUntil = performance.now() + WARM_MS;
        return false;
      });
    }, 60);
  }, []);

  const place = useCallback(() => {
    const a = anchor.current?.getBoundingClientRect();
    const el = tip.current;
    if (!a || !el) return;
    const w = el.offsetWidth;
    const h = el.offsetHeight;
    const roomAbove = a.top - GAP - h >= EDGE;
    const roomBelow = a.bottom + GAP + h <= window.innerHeight - EDGE;
    const goBelow = side === 'bottom' ? roomBelow || !roomAbove : !roomAbove && roomBelow;
    const cx0 = a.left + a.width / 2;
    const left = Math.min(Math.max(cx0 - w / 2, EDGE), window.innerWidth - EDGE - w);
    setBelow(goBelow);
    setX(left);
    setY(goBelow ? a.bottom + GAP : a.top - GAP - h);
    setCaret(cx0 - left);
  }, [side]);

  useLayoutEffect(() => {
    const el = tip.current;
    if (!el) return;
    if (open) {
      if (!el.matches(':popover-open')) el.showPopover();
      place();
    } else if (el.matches(':popover-open')) el.hidePopover();
  }, [open, place, name, meaning, state]);

  useEffect(() => {
    if (!open) return;
    const onKey = (e: KeyboardEvent) => e.key === 'Escape' && setHover(false);
    const onResize = () => place();
    window.addEventListener('keydown', onKey);
    window.addEventListener('resize', onResize);
    void document.fonts.ready.then(onResize);
    return () => {
      window.removeEventListener('keydown', onKey);
      window.removeEventListener('resize', onResize);
    };
  }, [open, place]);

  return (
    <span
      ref={anchor}
      className={cx(s.anchor, className)}
      onPointerEnter={show}
      onPointerLeave={hide}
      onFocus={(e) => (e.target as HTMLElement).matches(':focus-visible') && setHover(true)}
      onBlur={() => setHover(false)}
    >
      {children}
      <span
        ref={tip}
        popover="manual"
        role="tooltip"
        className={cx(s.tip, below ? s.below : s.above)}
        style={{ left: x, top: y, ['--caret-x' as string]: `${caret}px` }}
        onPointerEnter={() => window.clearTimeout(timer.current)}
        onPointerLeave={hide}
      >
        <span className={s.head}>
          <b className={s.name}>{name}</b>
          {keys && keys.length > 0 && (
            <span className={s.keys}>
              {keys.map((k) => (
                <kbd key={k} className={s.key}>{k}</kbd>
              ))}
            </span>
          )}
        </span>
        {meaning && <span className={s.meaning}>{meaning}</span>}
        {state && <span className={s.state}>{state}</span>}
      </span>
    </span>
  );
}

export default StudioTip;
