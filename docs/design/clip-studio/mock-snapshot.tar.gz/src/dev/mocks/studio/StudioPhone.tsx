import type { CSSProperties } from 'react';
import cx from 'classnames';
import { STEPS, CLIP_END, VIEW_END } from './steps';
import { useDockCover } from './useDockCover';
import './hideReal.css';
import b from './StudioB.module.css';
import s from './StudioPhone.module.css';

type Props = Record<string, never>;

const x = (a: number, e: number): CSSProperties =>
  ({ '--f': a / VIEW_END, '--w': Math.max(e - a, 0) / VIEW_END }) as CSSProperties;

function StudioPhone(_: Props) {
  const ref = useDockCover();
  return (
    <section ref={ref} className={s.sheet} aria-label="Clip studio">
      <span className={s.handle} aria-hidden />
      <header className={s.top}>
        <span className={b.title}>Cosmic Flows</span>
        <button type="button" className={cx(b.tbtn, s.play)} aria-label="Play">
          ▶
        </button>
        <span className={b.time}>04.0 / 20.0 s</span>
      </header>
      <div className={s.strip} aria-label="Scrub the clip">
        {STEPS.filter((r) => r.shape === 'move' || r.shape === 'gap').map((r) => (
          <span key={r.id} className={cx(s.seg, r.shape === 'move' && s.segMove)} style={x(r.start, r.end)} />
        ))}
        {STEPS.filter((r) => r.shape === 'cue').map((r) => (
          <span key={r.id} className={s.dot} style={x(r.start, r.start)} />
        ))}
        <span className={s.end} style={x(CLIP_END, CLIP_END)} />
        <span className={s.head} style={x(4, 4)} />
      </div>
      <ol className={s.list}>
        {STEPS.map((r) => (
          <li
            key={r.id}
            className={cx(s.item, r.id === 'dolly1' && s.itemSel)}
            style={{ '--d': r.depth } as CSSProperties}
          >
            <span className={s.at}>{r.start.toFixed(1)}</span>
            <span className={cx(b.glyph, b[`g_${r.shape}`])} aria-hidden />
            <span className={s.label}>{r.label}</span>
            <span className={s.dur}>{r.detail}</span>
            <span className={s.chev} aria-hidden>
              ›
            </span>
          </li>
        ))}
      </ol>
    </section>
  );
}

export default StudioPhone;
