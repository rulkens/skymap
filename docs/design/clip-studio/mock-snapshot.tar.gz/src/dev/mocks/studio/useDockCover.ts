import { useCallback, useRef } from 'react';
import { useAppDispatch } from '../../../store/hooks';
import { useViewCover } from '../../../hooks/useViewCover';
import { viewCoverSet } from '../../../state/viewCover/viewCoverSlice';
import type { ViewCover } from '../../../@types/layout/ViewCover';

// Real seam: the dock registers a bottom cover so the renderer centres the view above it.
export function useDockCover() {
  const dispatch = useAppDispatch();
  const ref = useRef<HTMLElement>(null);
  const onCover = useCallback(
    (cover: ViewCover | null) => dispatch(viewCoverSet({ id: 'phoneBottom', cover })),
    [dispatch],
  );
  useViewCover(ref, 'bottom', true, onCover);
  return ref;
}
