import Panel, { Head, Grid, Sec, Row, Wide, Num, Pick, Actions, UseView } from '../InspectorGrid';

type Props = { readonly which: 'aim' | 'roll' };

// perseveranceToSondermarken's literal turn steps at depth 3–4: the outbound look-down aim and
// the swing's roll. Values are the factory's J2000 literals.
function LiteralTurnInspector({ which }: Props) {
  const aim = which === 'aim';
  return (
    <Panel>
      <Head
        glyph="turn"
        ch="turn"
        where={aim ? 'In order › Together › In order · 1/3' : 'In order › Together › In order › Together · 2/2'}
        range={aim ? '0:03.0–0:17.0' : '0:36.0–0:48.0'}
        title={aim ? 'Aim → 30.1°, 2.9°' : 'Roll → 0°'}
      />
      <Grid>
        <Sec title="Value" />
        {aim ? (
          <>
            <Row label="Turn" unit="°" reset>
              <Num value="30.1" fill={0.58} />
            </Row>
            <Row label="Tilt" unit="°" reset>
              <Num value="2.9" fill={0.52} />
            </Row>
          </>
        ) : (
          <Row label="Roll" tip="About the view axis; 0° = north up" unit="°" reset>
            <Num value="0" fill={0.5} />
          </Row>
        )}
        <Row label="Frame" tip="Axes for these angles">
          <Pick dim>ecliptic · J2000</Pick>
        </Row>
        <Wide>
          <UseView captures={aim ? 'Turn and Tilt' : 'Roll'} />
        </Wide>
        <Sec title="Timing" />
        <Row label="Duration" unit="s" reset>
          <Num value={aim ? '14.0' : '12.0'} fill={aim ? 0.14 : 0.12} />
        </Row>
        <Row label="Ease">
          <Pick dim>In-out</Pick>
        </Row>
      </Grid>
      <Actions />
    </Panel>
  );
}

export default LiteralTurnInspector;
