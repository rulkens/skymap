// One time format per clip, chosen by its length, used by the readout, the playhead head, the
// End flag, the ruler, the inspector ranges and Dur. Under 60 s: `7.4 s`. From 60 s: `m:ss.t`
// (`0:35.0 / 1:37.0`). Ruler ticks sit on whole seconds, so they drop the tenth (`0:30`, `4`).
// Durations keep the naming table's precision (`4 s`, `8.7 s`) and read `m:ss.t` from 60 s.
const mss = (v: number, tenths: boolean) => {
  const m = Math.floor(v / 60);
  const sec = v - m * 60;
  return `${m}:${tenths ? sec.toFixed(1).padStart(4, '0') : String(Math.round(sec)).padStart(2, '0')}`;
};

export function clipTime(clipEnd: number) {
  const long = clipEnd >= 60;
  const at = (v: number) => (long ? mss(v, true) : `${v.toFixed(1)} s`);
  return {
    long,
    at,
    tick: (v: number, first: boolean) => (long ? mss(v, false) : first ? `${+v.toFixed(2)} s` : `${+v.toFixed(2)}`),
    span: (a: number, z: number) => (long ? `${at(a)}–${at(z)}` : a === z ? at(a) : `${a.toFixed(1)}–${z.toFixed(1)} s`),
    dur: (d: string) => {
      const m = /^(\d+(?:\.\d+)?) s$/.exec(d);
      return m && Number(m[1]) >= 60 ? mss(Number(m[1]), true) : d;
    },
  };
}
