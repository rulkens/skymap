import type { ReactNode } from 'react';
import s from './LoopGhost.module.css';

type Props = { readonly wrapAt: number; readonly viewEnd: number; readonly children: ReactNode };

// Past the wrap of a `loop: true` clip the track shows the next cycle: the same marks re-drawn
// from 0 s, dimmed. The inner box is as wide as the whole track, so the marks' own x() still fit.
function LoopGhost({ wrapAt, viewEnd, children }: Props) {
  return (
    <div className={s.ghost} style={{ left: `${(wrapAt / viewEnd) * 100}%` }} aria-hidden>
      <div className={s.inner} style={{ width: `${(viewEnd / (viewEnd - wrapAt)) * 100}%` }}>
        {children}
      </div>
    </div>
  );
}

export default LoopGhost;
