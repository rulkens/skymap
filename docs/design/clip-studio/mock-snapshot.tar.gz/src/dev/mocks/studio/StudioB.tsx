import type { CSSProperties } from 'react';
import { useDockCover } from './useDockCover';
import cx from 'classnames';
import Button from '../../../components/common/Button/Button';
import Slider from '../../../components/common/Slider/Slider';
import { STEPS, CLIP_END, VIEW_END } from './steps';
import './hideReal.css';
import s from './StudioB.module.css';

type Props = {
  readonly mode: 'overview' | 'camera' | 'cue' | 'empty' | 'invalid' | 'playing';
};

const f = (t: number): CSSProperties => ({ '--f': t / VIEW_END }) as CSSProperties;
const w = (a: number, b: number): CSSProperties =>
  ({ '--f': a / VIEW_END, '--w': (b - a) / VIEW_END }) as CSSProperties;
const noop = () => {};

function StudioB({ mode }: Props) {
  const ref = useDockCover();
  const selected =
    mode === 'camera' || mode === 'playing' ? 'dolly1' : mode === 'cue' ? 'black' : mode === 'invalid' ? 'clash' : null;
  const playhead = mode === 'playing' ? 6.2 : mode === 'cue' ? 20 : 4;
  const start = {
    id: 'start', depth: 0, shape: 'start', cat: 'Start',
    label: mode === 'empty' ? 'Start from the current view' : 'Start from the saved view',
    detail: mode === 'empty' ? 'live' : 'pinned', start: 0, end: 0,
  } as (typeof STEPS)[number];
  const rows =
    mode === 'empty'
      ? [start]
      : mode === 'invalid'
        ? [
            start,
            ...STEPS.slice(0, 13),
            { id: 'clash', depth: 1, shape: 'move', cat: 'Camera', label: 'Zoom to 500 Mpc', detail: '6 s', start: 4, end: 10, error: true },
            ...STEPS.slice(13),
          ]
        : [start, ...STEPS];
  const isError = (id: string) => mode === 'invalid' && (id === 'clash' || id === 'dolly1');

  const free = mode === 'camera';
  return (
    <>
    {mode !== 'empty' && (
      <div className={cx(s.camMode, free && s.camFree)} role="status">
        {free ? (
          <>
            <span>◌ Free camera · this is not the clip’s view at 4.0 s</span>
            <button type="button" className={s.tbtn}>
              Back to playhead<kbd className={s.kbd}>F</kbd>
            </button>
          </>
        ) : (
          <span>● Camera follows the playhead · drag the sky to look around</span>
        )}
      </div>
    )}
    <section ref={ref} className={s.dock} aria-label="Clip studio">
      <header className={s.topbar}>
        <div className={s.clip}>
          <span className={s.title}>{mode === 'empty' ? 'New clip' : 'Cosmic Flows'}</span>
          <button type="button" className={s.picker} aria-label="Open another clip">
            ▾
          </button>
          {mode !== 'empty' && (
            <span className={s.origin} title="Written by hand in the code">
              hand-written · saves as a new clip
            </span>
          )}
          {mode === 'invalid' ? (
            <span className={s.statusError} role="alert">
              ⚠ Can’t play this version · playing the last one that worked
            </span>
          ) : (
            <span className={s.status} role="status">
              {mode === 'empty' ? 'Not saved yet' : mode === 'overview' ? 'No changes' : 'Unsaved changes'}
            </span>
          )}
        </div>
        <div className={s.transport}>
          <button type="button" className={s.tbtn} aria-label="Go to start">
            ⏮<kbd className={s.kbd}>Home</kbd>
          </button>
          <button type="button" className={cx(s.tbtn, s.play)} aria-label={mode === 'playing' ? 'Pause' : 'Play'}>
            {mode === 'playing' ? '❚❚' : '▶'}
            <kbd className={s.kbd}>Space</kbd>
          </button>
          <span className={s.time}>
            {mode === 'empty' ? '0.00 / 0.00 s' : `${playhead.toFixed(2).padStart(5, '0')} / 20.00 s`}
          </span>

        </div>
        <div className={s.tools}>
          <Button className={s.toolBtn}>
            + Add step<kbd className={s.kbd}>A</kbd>
          </Button>
          <Button className={s.toolBtn} variant={mode === 'overview' || mode === 'empty' ? 'secondary' : 'primary'} disabled={mode === 'overview' || mode === 'empty'}>
            {mode === 'empty' ? 'Save' : 'Save as new'}<kbd className={s.kbd}>⌘S</kbd>
          </Button>
          <Button className={s.toolBtn} variant="ghost" disabled={mode === 'overview' || mode === 'empty'}>
            Undo<kbd className={s.kbd}>⌘Z</kbd>
          </Button>
          <Button className={s.toolBtn} variant="ghost" disabled>
            Redo<kbd className={s.kbd}>⇧⌘Z</kbd>
          </Button>
          <span className={s.zoom} aria-label="Zoom">
            <button type="button" className={s.tbtn} aria-label="Zoom out">
              −
            </button>
            <button type="button" className={s.tbtn}>
              Fit
            </button>
            <button type="button" className={s.tbtn} aria-label="Zoom in">
              +
            </button>
          </span>
          <Button className={s.toolBtn} variant="ghost">
            Close studio
          </Button>
        </div>
      </header>

      <div className={s.body}>
        <div className={s.list}>
          <div className={s.headRow}>
            <span className={s.headLabel}>Steps</span>
            <div className={s.ruler}>
              {Array.from({ length: VIEW_END + 1 }, (_, t) => (
                <span key={t} className={cx(s.tick, t % 2 === 0 && s.tickMajor)} style={f(t)}>
                  {t % 2 === 0 ? `${t}` : ''}
                </span>
              ))}
              {mode !== 'empty' && (
                <span className={s.endFlag} style={f(CLIP_END)}>
                  End
                </span>
              )}
            </div>
          </div>
          <div className={s.rows}>
            {mode !== 'empty' && <div className={s.afterEnd} style={w(CLIP_END, VIEW_END)} aria-hidden />}
            {mode !== 'empty' && <div className={s.playhead} style={f(playhead)} aria-hidden />}
            {mode === 'empty' && (
              <div className={s.empty}>
                <p className={s.emptyTitle}>This clip has no steps yet</p>
                <p className={s.emptyText}>
                  Steps play from top to bottom, starting from the current view. Add a camera move or a
                  scene change, or start from an example.
                </p>
                <div className={s.emptyActions}>
                  <Button variant="primary">Add camera move</Button>
                  <Button>Add scene change</Button>
                  <Button variant="ghost">Copy an example ▾</Button>
                </div>
              </div>
            )}
            {rows.map((r) => {
              const active = mode === 'playing' && r.start <= playhead && playhead < Math.max(r.end, r.start + 0.01);
              return (
                <div
                  key={r.id}
                  className={cx(
                    s.row,
                    selected === r.id && s.rowSelected,
                    isError(r.id) && s.rowError,
                    active && s.rowActive,
                  )}
                  aria-selected={selected === r.id}
                >
                  <div className={s.cell} style={{ '--d': r.depth } as CSSProperties}>
                    {r.shape === 'group' ? (
                      <span className={s.twisty}>{'collapsed' in r && r.collapsed ? '▸' : '▾'}</span>
                    ) : (
                      <span className={cx(s.glyph, s[`g_${r.shape}`])} aria-hidden />
                    )}
                    <span className={s.label}>{r.label}</span>
                    {'background' in r && r.background && <span className={s.badge}>background</span>}
                    <span className={s.detail}>{r.detail}</span>
                    {isError(r.id) && <span className={s.errMark}>⚠</span>}
                    {'warn' in r && r.warn && <span className={s.warnMark}>⚠</span>}
                  </div>
                  <div className={s.track}>
                    {r.shape === 'start' && <span className={s.startFlag}>▶</span>}
                    {r.shape === 'cue' && (
                      <>
                        {'tail' in r && r.tail && <span className={s.tail} style={w(r.start, r.start + r.tail)} />}
                        <span className={s.diamond} style={f(r.start)} />
                      </>
                    )}
                    {r.id === 'cross' && (
                      <>
                        <span className={s.tail} style={w(4, 7)} />
                        <span className={s.diamond} style={f(4)} />
                        <span className={s.stack}>2</span>
                      </>
                    )}
                    {r.shape === 'group' && r.id !== 'cross' && <span className={s.bracket} style={w(r.start, r.end)} />}
                    {r.shape === 'gap' && <span className={cx(s.bar, s.barGap)} style={w(r.start, r.end)} />}
                    {r.shape === 'move' && (
                      <span
                        className={cx(s.bar, s.barMove, isError(r.id) && s.barClash, selected === r.id && s.barSelected)}
                        style={w(r.start, r.end)}
                      >
                        {selected === r.id && <span className={s.handle} />}
                      </span>
                    )}
                    {r.shape === 'rate' && (
                      <>
                        <span className={cx(s.bar, s.barRate)} style={w(r.start, r.end)} />
                        {'holdTo' in r && r.holdTo && <span className={s.holdLine} style={w(r.end, r.holdTo)} />}
                      </>
                    )}
                    {r.shape === 'osc' && <span className={cx(s.bar, s.barOsc)} style={w(r.start, r.end)}>∞</span>}
                  </div>
                </div>
              );
            })}
            {mode === 'invalid' && <div className={s.clashZone} style={w(4, 8)} aria-hidden />}
          </div>
        </div>

        <aside className={s.inspector} aria-label="Step settings">
          {(mode === 'overview' || mode === 'empty') && (
            <>
              <p className={s.eyebrow}>Clip</p>
              <label className={s.field}>
                <span className={s.fieldLabel}>Name</span>
                <input className={s.input} defaultValue={mode === 'empty' ? 'New clip' : 'Cosmic Flows'} />
              </label>
              <div className={s.field}>
                <span className={s.fieldLabel}>Starts from</span>
                <div className={s.segmented}>
                  <button type="button" aria-pressed={mode === 'empty'} className={s.seg}>
                    Current view
                  </button>
                  <button type="button" aria-pressed={mode !== 'empty'} className={s.seg}>
                    Saved view
                  </button>
                </div>
                {mode !== 'empty' && (
                  <Button className={s.inlineBtn}>
                    Save current view as start<kbd className={s.kbd}>V</kbd>
                  </Button>
                )}
              </div>
              <div className={s.kv}>
                <span className={s.fieldLabel}>Length</span>
                <span className={s.value}>{mode === 'empty' ? '0.0 s' : '20.0 s'}</span>
              </div>
              <label className={s.check}>
                <input type="checkbox" /> Play again from the start when it ends
              </label>
              <p className={s.hint}>Select a step to change it.</p>
            </>
          )}
          {(mode === 'camera' || mode === 'playing') && (
            <>
              <p className={s.eyebrow}>Camera move · distance</p>
              <h2 className={s.h}>Pull back to 300 Mpc</h2>
              <Slider label="Distance" value={0.62} onChange={noop} format={() => '300 Mpc'} />
              <Slider label="Duration" value={0.2} onChange={noop} format={() => '4.0 s'} />
              <div className={s.field}>
                <span className={s.fieldLabel}>Easing</span>
                <div className={s.easeRow}>
                  <svg className={s.curve} viewBox="0 0 40 24" aria-hidden>
                    <path d="M2 22 C 18 22, 22 2, 38 2" />
                  </svg>
                  <button type="button" className={s.select}>
                    Slow start and end ▾
                  </button>
                </div>
              </div>
              {mode === 'playing' && (
                <div className={s.kv}>
                  <span className={s.fieldLabel}>Distance now</span>
                  <span className={s.value}>18.3 Mpc</span>
                </div>
              )}
              <p className={s.hint}>Starts at 4.0 s, after the step before it in “In order”.</p>
              <label className={s.check}>
                <input type="checkbox" /> Run in background (the next step doesn’t wait)
              </label>
              <Button className={s.inlineBtn} variant={mode === 'camera' ? 'primary' : 'secondary'}>
                Use current view<kbd className={s.kbd}>V</kbd>
              </Button>
              <div className={s.footer}>
                <Button variant="ghost">
                  Duplicate<kbd className={s.kbd}>⌘D</kbd>
                </Button>
                <Button variant="ghost">
                  Delete<kbd className={s.kbd}>⌫</kbd>
                </Button>
              </div>
            </>
          )}
          {mode === 'cue' && (
            <>
              <p className={s.eyebrow}>Scene change · opacity</p>
              <h2 className={s.h}>Fade to 0 %</h2>
              <div className={s.field}>
                <span className={s.fieldLabel}>Layers</span>
                <div className={s.chips}>
                  {['Flow', 'Milky Way disk', 'Structure rings', 'Galaxy labels'].map((c) => (
                    <span key={c} className={s.chip}>
                      {c} <button type="button" className={s.chipX} aria-label={`Remove ${c}`}>×</button>
                    </span>
                  ))}
                  <button type="button" className={s.chipAdd}>+ Layer</button>
                </div>
              </div>
              <Slider label="Opacity" value={0} onChange={noop} format={() => '0 %'} />
              <Slider label="Fade time" value={0.3} onChange={noop} format={() => '3.0 s'} />
              <p className={s.hint}>Happens at 20.0 s. A scene change takes no time on the timeline: the next step starts at once.</p>
              <div className={s.warnBox} role="alert">
                <p className={s.warnTitle}>⚠ Cut short at the end</p>
                <p className={s.warnText}>
                  The clip ends at 20.0 s and resets every fade, so this 3 s fade is never seen.
                </p>
                <Button>Add a 3 s hold after it</Button>
              </div>
            </>
          )}
          {mode === 'invalid' && (
            <>
              <p className={s.eyebrow}>Camera move · distance</p>
              <h2 className={s.h}>Zoom to 500 Mpc</h2>
              <Slider label="Distance" value={0.66} onChange={noop} format={() => '500 Mpc'} />
              <Slider label="Duration" value={0.3} onChange={noop} format={() => '6.0 s'} />
              <div className={s.errBox} role="alert">
                <p className={s.warnTitle}>⚠ Two moves change the distance at once</p>
                <p className={s.warnText}>
                  From 4.0 to 8.0 s this step and “Pull back to 300 Mpc” both set the distance. Run one
                  after the other, or change something else here.
                </p>
                <div className={s.footer}>
                  <Button>Run after it</Button>
                  <Button variant="ghost">
                    Undo<kbd className={s.kbd}>⌘Z</kbd>
                  </Button>
                </div>
              </div>
            </>
          )}
        </aside>
      </div>
      <footer className={s.keys}>
        ↑↓ select · ←→ fold · Enter edit · ⌫ delete · ⌘D duplicate · ⌘G group · [ ] shorter / longer · drag a bar’s end to
        change its length
      </footer>
    </section>
    </>
  );
}

export default StudioB;
