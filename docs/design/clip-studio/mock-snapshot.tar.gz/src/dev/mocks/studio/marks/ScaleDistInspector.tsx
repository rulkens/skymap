import Panel, { Head, Grid, Sec, Row, Wide, Num, Pick, Out, Actions, UseView } from '../InspectorGrid';
import Glyph from '../StudioDGlyph';
import d from '../StudioD.module.css';

type Props = Record<string, never>;

// sondermarkenFlyout's dolly at 35 s: one log move over 24 decades, 801 m (Earth-fixed Start)
// to 29.5 Gpc (absolute). Values on the app's ladder; stored unit + frame ride the label tip.
function ScaleDistInspector(_: Props) {
  return (
    <Panel>
      <Head glyph="dist" ch="dist" where="In order › Together 1/3" range="0:03.0–1:33.0" title="Distance → 29.5 Gpc" />
      <Grid>
        <Sec title="Move" />
        <Row label="To" tip="Stored as 29,500 Mpc, absolute frame" unit="Gpc">
          <Num value="29.5" fill={0.97} />
        </Row>
        <Row label="From" tip="The Start's range, Earth-fixed">
          <Out>
            801 m
            <span className={d.frameChip}><Glyph kind="body" className={d.frameIcon} />Earth</span>
          </Out>
        </Row>
        <Row label="Span" tip="Log space: equal time per decade">
          <Out>24 decades</Out>
        </Row>
        <Sec title="Timing" />
        <Row label="Duration" unit="s" reset>
          <Num value="90.0" fill={0.9} />
        </Row>
        <Row label="Ease" tip="Default: in-out cubic">
          <Pick dim>In-out</Pick>
        </Row>
        <Row label="Space" tip="Distance defaults to log">
          <Pick dim>log</Pick>
        </Row>
        <Sec title="At 0:35.0" />
        <Row label="Now">
          <Out>16,941 km</Out>
        </Row>
        <Wide>
          <UseView captures="Distance" />
        </Wide>
      </Grid>
      <Actions />
    </Panel>
  );
}

export default ScaleDistInspector;
