import cx from 'classnames';
import Panel, { Head, Grid, Sec, Row, Num, Pick, Out, Seg, Btn, Actions } from '../InspectorGrid';
import Glyph from '../StudioDGlyph';
import { FLY, WPS } from '../rows-famousFlythrough';
import sd from '../StudioD.module.css';
import s from './FlyPathInspector.module.css';

type Props = { readonly wp?: string };

const f1 = (v: number) => v.toFixed(1);
const clock = (v: number) => (v < 60 ? `${f1(v)} s` : `${Math.floor(v / 60)}:${(v % 60).toFixed(1).padStart(4, '0')}`);

// The flyPath's own knobs (the old debug panel's tuning sliders, now authored values) and one
// waypoint's. Helper defaults are dim; only `over` is authored in this clip, so only it resets.
function PathView() {
  return (
    <Panel>
      <Head glyph="fly" where={`Fly · ${WPS.length} waypoints`} range={`0–${clock(FLY.total)}`} title={`Fly → ${WPS[WPS.length - 1]!.name}`} />
      <Grid>
        <Row label="Owns" tip="Distance, look-at, turn, tilt; roll free">
          <span className={s.owns}>
            <Glyph kind="dist" className={cx(s.ownG, sd.c_dist)} />
            <Glyph kind="look" className={cx(s.ownG, sd.c_look)} />
            <Glyph kind="turn" className={cx(s.ownG, sd.c_turn)} />
          </span>
        </Row>
        <Row label="Cruise" unit="s" reset tip="Travel time, split by arc length"><Num value="100" fill={0.5} /></Row>
        <Row label="Total" unit="s" tip={`Cruise + ${f1(FLY.total - FLY.over)} s linger`}><Out>{f1(FLY.total)}</Out></Row>
        <Sec title="Pace" />
        <Row label="Ramp" unit="s" tip="Accel/decel each end; 0 = ease"><Num value={f1(FLY.rampSec)} fill={FLY.rampSec / 6} dim /></Row>
        <Row label="Align" unit="s" tip="Start view → down the path"><Num value={String(FLY.align)} fill={FLY.align / 3} dim /></Row>
        <Row label="Linger" unit="×" tip="Slow-down depth at each waypoint"><Num value={String(FLY.linger)} fill={FLY.linger} dim /></Row>
        <Row label="Window" unit="s" tip="Slow-down length, leads the knot"><Num value={f1(FLY.lingerSec)} fill={FLY.lingerSec / 6} dim /></Row>
        <Sec title="Curve" />
        <Row label="Basis" tip="Head-on turns after the knot; banked before">
          <Seg label="Curve basis" value="causal" options={[['causal', 'Head-on'], ['centripetal', 'Banked']]} />
        </Row>
        <Row label="Overshoot" unit="×" tip="How far past a knot before turning"><Num value={String(FLY.turnDelay)} fill={FLY.turnDelay / 3} dim /></Row>
        <Row label="Look ahead" unit="s" tip="Aim leads the eye by this much"><Num value={f1(FLY.lookAhead)} fill={FLY.lookAhead / 6} dim /></Row>
        <Sec title="Pass-by" />
        <Row label="Offset" unit="r" tip="Beside each galaxy, in its radii"><Num value={String(FLY.passOffset)} fill={FLY.passOffset / 16} dim /></Row>
        <Row label="Side" tip="Which side the eye passes">
          <Seg label="Pass side" value="outside" options={[['outside', 'Outside'], ['above', 'Above'], ['screen', 'Screen']]} />
        </Row>
      </Grid>
      <div className={s.foot}>
        <Btn kbd="W" glyph="pass">Waypoint</Btn>
        <Actions />
      </div>
    </Panel>
  );
}

function WaypointView({ wp }: { readonly wp: string }) {
  const i = WPS.findIndex((w) => `wp-${w.id}` === wp);
  const w = WPS[i]!;
  const a = i === 0 ? 0 : WPS[i - 1]!.at;
  const last = i === WPS.length - 1;
  return (
    <Panel label="Waypoint settings">
      <Head glyph={last ? 'settle' : 'pass'} where={`Fly › ${last ? 'Settle' : 'Pass'} ${i + 1}/${WPS.length}`} range={`${f1(a)}–${f1(w.at)} s`} title={w.name} />
      <Grid>
        <Row label="Subject" tip="Catalogue id, resolved at play time" reset>
          <Pick>
            <span className={s.pickId}>{w.id.toUpperCase()}</span>
            {w.name}
          </Pick>
        </Row>
        <Row label="Kind" tip="Subject flies past; point is placed by hand">
          <Seg label="Waypoint kind" value="subject" options={[['subject', 'Subject', 'pass'], ['point', 'Point', 'point']]} />
        </Row>
        <Sec title="Timing" aside={<span className={s.navRow}>‹ {WPS[i - 1]?.id.toUpperCase() ?? 'Start'} · {WPS[i + 1]?.id.toUpperCase() ?? 'End'} › <kbd className={sd.kbd}>[ ]</kbd></span>} />
        <Row label="Leg" unit="s" tip="Auto = arc-length share; pin to hold">
          <span className={s.pair}>
            <Num value={f1(w.at - a)} dim />
            <button type="button" className={s.pinBtn} aria-pressed={false} aria-label="Pin leg"><Glyph kind="pin" className={s.pinG} /></button>
          </span>
        </Row>
        <Row label="Arrive" unit="s" tip={`Cruise share ${f1(w.cruise)} s + linger`}><Out>{f1(w.at)}</Out></Row>
        <Sec title="Dwell" />
        <Row label="Linger" unit="×" tip="Inherits the path; 0 = shape only"><Num value={String(FLY.linger)} fill={FLY.linger} dim /></Row>
        <Row label="Slowest" unit="%" tip="Lowest speed here, of cruise"><Out>{Math.round(w.minPace * 100)}</Out></Row>
        <Sec title="View" />
        <Row label="Aim" tip="Along the path unless pinned">
          <span className={s.pair}>
            <Out>auto</Out>
            <Btn kbd="V">Use view</Btn>
          </span>
        </Row>
        <Row label="Pass" unit="kpc" tip={`${FLY.passOffset} radii beside (path pass-by)`}><Out>{Math.round(FLY.passOffset * w.r)}</Out></Row>
        <Row label="Frame" unit="kpc" tip="Framing distance; floor 150 kpc"><Out>{w.frame}</Out></Row>
      </Grid>
      <Actions />
    </Panel>
  );
}

function FlyPathInspector({ wp }: Props) {
  return wp ? <WaypointView wp={wp} /> : <PathView />;
}

export default FlyPathInspector;
