import cx from 'classnames';
import Panel, { Head, Grid, Sec, Row, Num, Pick, Out, Seg, Btn, Actions, UseView } from '../InspectorGrid';
import StudioTip from '../StudioTip';
import { clipTime } from '../clipTime';
import Glyph from '../StudioDGlyph';
import { FLY, WPS } from '../rows-famousFlythrough';
import sd from '../StudioD.module.css';
import s from './FlyPathInspector.module.css';

type Props = { readonly wp?: string };

const f1 = (v: number) => v.toFixed(1);
const time = clipTime(FLY.total);

// The flyPath's own knobs (the old debug panel's tuning sliders, now authored values) and one
// waypoint's. Helper defaults are dim; only `over` is authored in this clip, so only it resets.
function PathView() {
  return (
    <Panel>
      <Head glyph="fly" where={`Fly · ${WPS.length} waypoints`} range={time.span(0, FLY.total)} title={`Fly → ${WPS[WPS.length - 1]!.name}`} />
      <Grid>
        <Row label="Owns" tip="Distance, look-at, turn, tilt; roll free">
          <span className={s.owns}>
            <Glyph kind="dist" className={cx(s.ownG, sd.c_dist)} />
            <Glyph kind="look" className={cx(s.ownG, sd.c_look)} />
            <Glyph kind="turn" className={cx(s.ownG, sd.c_turn)} />
          </span>
        </Row>
        <Row label="Cruise" unit="s" reset tip={`Travel time; + ${f1(FLY.total - FLY.over)} s linger`}><Num value="100" fill={0.5} /></Row>
        <Sec title="Pace" />
        <Row label="Ramp" unit="s" tip="Accel/decel each end; 0 = ease"><Num value={f1(FLY.rampSec)} fill={FLY.rampSec / 6} dim /></Row>
        <Row label="Align" unit="s" tip="Start view → down the path"><Num value={String(FLY.align)} fill={FLY.align / 3} dim /></Row>
        <Row label="Linger" unit="×" tip="Slow-down depth at each waypoint"><Num value={String(FLY.linger)} fill={FLY.linger} dim /></Row>
        <Row label="Window" unit="s" tip="Slow-down length, leads the knot"><Num value={f1(FLY.lingerSec)} fill={FLY.lingerSec / 6} dim /></Row>
        <Sec title="Curve" />
        <Row label="Basis" tip="Head-on turns after the knot; banked before">
          <Seg label="Curve basis" value="causal" options={[['causal', 'Head-on'], ['centripetal', 'Banked']]} />
        </Row>
        <Row label="Overshoot" unit="×" tip="How far past a knot before turning"><Num value={String(FLY.turnDelay)} fill={FLY.turnDelay / 3} dim /></Row>
        <Row label="Look ahead" unit="s" tip="Aim leads the eye by this much"><Num value={f1(FLY.lookAhead)} fill={FLY.lookAhead / 6} dim /></Row>
        <Sec title="Pass-by" />
        <Row label="Offset" unit="r" tip="Beside each galaxy, in its radii"><Num value={String(FLY.passOffset)} fill={FLY.passOffset / 16} dim /></Row>
        <Row label="Side" tip="Which side the eye passes">
          <Seg label="Pass side" value="outside" options={[['outside', 'Outside'], ['above', 'Above'], ['screen', 'Screen']]} />
        </Row>
      </Grid>
      <div className={s.foot}>
        <Btn kbd="W" glyph="pass" meaning="Adds a waypoint at the playhead">+ Waypoint</Btn>
        <Actions />
      </div>
    </Panel>
  );
}

function WaypointView({ wp }: { readonly wp: string }) {
  const i = WPS.findIndex((w) => `wp-${w.id}` === wp);
  const w = WPS[i]!;
  const a = i === 0 ? 0 : WPS[i - 1]!.at;
  const last = i === WPS.length - 1;
  return (
    <Panel label="Waypoint settings">
      <Head glyph={last ? 'settle' : 'pass'} where={`Fly › ${last ? 'Settle' : `Pass ${i + 1}`} · ${i + 1}/${WPS.length}`} range={time.span(a, w.at)} title={w.name} />
      <Grid>
        <Row label="Subject" tip="Catalogue id, looked up at play" reset>
          <Pick>
            <Glyph kind="subject" className={s.pickG} />
            <span className={s.pickId}>{w.id.toUpperCase()}</span>
            {w.name.replace(/ Galaxy$/, '')}
          </Pick>
        </Row>
        <Row label="Kind" tip="A named subject, or a placed point">
          <Seg label="Waypoint kind" value="subject" options={[['subject', 'Subject', 'pass'], ['point', 'Point', 'point']]} />
        </Row>
        <Sec
          title="Timing"
          aside={
            <span className={s.navRow}>
              <StudioTip name="Previous waypoint" keys={['[']}>
                <button type="button" className={s.navBtn} aria-label="Previous waypoint">
                  <Glyph kind="chevronLeft" className={s.navG} />
                  {WPS[i - 1]?.id.toUpperCase() ?? 'Start'}
                </button>
              </StudioTip>
              <StudioTip name="Next waypoint" keys={[']']}>
                <button type="button" className={s.navBtn} aria-label="Next waypoint">
                  {WPS[i + 1]?.id.toUpperCase() ?? 'End'}
                  <Glyph kind="chevronRight" className={s.navG} />
                </button>
              </StudioTip>
            </span>
          }
        />
        <Row label="Leg" unit="s" tip="Arc-length share; pin to hold it">
          <span className={s.pair}>
            <Num value={f1(w.at - a)} dim />
            <button type="button" className={s.pinBtn} aria-pressed={false} aria-label="Pin leg"><Glyph kind="pin" className={s.pinG} /></button>
          </span>
        </Row>
        <Row label="Arrive" tip={`Cruise share ${f1(w.cruise)} s + linger`}><Out>{time.at(w.at)}</Out></Row>
        <Sec title="Dwell" />
        <Row label="Linger" unit="×" tip="Inherits the path; 0 = shape only"><Num value={String(FLY.linger)} fill={FLY.linger} dim /></Row>
        <Row label="Min speed" tip="Lowest speed here, of cruise"><Out>{Math.round(w.minPace * 100)} % of cruise</Out></Row>
        <Sec title="View" />
        <Row label="Aim" tip="Along the path unless pinned">
          <span className={s.pair}>
            <Out>along path</Out>
            <UseView captures="Aim" />
          </span>
        </Row>
        <Row label="Pass-by" tip={`${FLY.passOffset} radii beside, from the path`}><Out>{Math.round(FLY.passOffset * w.r)} kpc</Out></Row>
        <Row label="Framing" tip="Framing distance; floor 150 kpc"><Out>{w.frame} kpc</Out></Row>
      </Grid>
      <Actions />
    </Panel>
  );
}

function FlyPathInspector({ wp }: Props) {
  return wp ? <WaypointView wp={wp} /> : <PathView />;
}

export default FlyPathInspector;
