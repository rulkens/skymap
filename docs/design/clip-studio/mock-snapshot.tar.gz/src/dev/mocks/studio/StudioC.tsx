import type { CSSProperties } from 'react';
import cx from 'classnames';
import Button from '../../../components/common/Button/Button';
import { CLIP_END, VIEW_END } from './steps';
import './hideReal.css';
import { useDockCover } from './useDockCover';
import b from './StudioB.module.css';
import s from './StudioC.module.css';

type Props = Record<string, never>;

const x = (a: number, e: number): CSSProperties =>
  ({ '--f': a / VIEW_END, '--w': (e - a) / VIEW_END }) as CSSProperties;

const LANES = [
  { name: 'Distance', group: 'Camera' },
  { name: 'Turn', group: 'Camera' },
  { name: 'Tilt', group: 'Camera' },
  { name: 'Look-at point', group: 'Camera' },
  { name: 'Layers shown', group: 'Scene' },
  { name: 'Layer opacity', group: 'Scene' },
  { name: 'Settings', group: 'Scene' },
  { name: 'Focus', group: 'Scene' },
];

function StudioC(_: Props) {
  const ref = useDockCover();
  return (
    <section ref={ref} className={s.dock} aria-label="Clip studio">
      <header className={b.topbar}>
        <div className={b.clip}>
          <span className={b.title}>Cosmic Flows</span>
          <span className={b.status}>20.0 s · saved</span>
        </div>
        <div className={b.transport}>
          <button type="button" className={b.tbtn}>
            ⏮<kbd className={b.kbd}>Home</kbd>
          </button>
          <button type="button" className={cx(b.tbtn, b.play)}>
            ▶<kbd className={b.kbd}>Space</kbd>
          </button>
          <span className={b.time}>04.00 / 20.00 s</span>
        </div>
        <div className={b.tools}>
          <Button className={b.toolBtn} variant="ghost">
            Undo<kbd className={b.kbd}>⌘Z</kbd>
          </Button>
          <Button className={b.toolBtn} variant="ghost">
            Close studio
          </Button>
        </div>
      </header>
      <div className={s.grid}>
        <span className={s.name}>Order</span>
        <div className={s.lane}>
          <span className={s.br} style={x(0, 20)}>
            Clip · in order
          </span>
        </div>
        <span className={s.name} />
        <div className={s.lane}>
          <span className={s.br} style={x(4, 15)}>
            Together
          </span>
        </div>
        <span className={s.name} />
        <div className={s.lane}>
          <span className={cx(s.br, s.brSel)} style={x(4, 15)}>
            In order · 3 steps
          </span>
        </div>
        {LANES.map((l, i) => (
          <>
            <span key={`n${l.name}`} className={cx(s.name, i === 0 || i === 4 ? s.first : null)}>
              {i === 0 || i === 4 ? <em className={s.group}>{l.group}</em> : null}
              {l.name}
            </span>
            <div key={l.name} className={s.lane}>
              {l.name === 'Distance' && (
                <>
                  <span className={cx(s.bar, s.sel)} style={x(4, 8)}>
                    300 Mpc
                  </span>
                  <span className={s.bar} style={x(11, 15)}>
                    950 Mpc
                  </span>
                  <div className={s.pop} style={x(4, 8)} role="dialog" aria-label="Pull back to 300 Mpc">
                    <p className={b.eyebrow}>Pull back</p>
                    <div className={s.popRow}>
                      <label className={s.popField}>
                        to <input className={b.input} defaultValue="300" size={5} /> Mpc
                      </label>
                      <label className={s.popField}>
                        over <input className={b.input} defaultValue="4.0" size={3} /> s
                      </label>
                      <button type="button" className={b.select}>
                        Slow start and end ▾
                      </button>
                    </div>
                  </div>
                </>
              )}
              {l.name === 'Turn' && (
                <>
                  <span className={cx(s.bar, s.rate)} style={x(2, 3.5)}>
                    speed
                  </span>
                  <span className={cx(s.bar, s.rate)} style={x(4, 15)}>
                    slow to 1.4°/s
                  </span>
                </>
              )}
              {l.name === 'Tilt' && (
                <span className={cx(s.bar, s.osc)} style={x(0, 24)}>
                  bob ±5.2° ∞
                </span>
              )}
              {l.name === 'Layers shown' && <span className={s.diamond} style={x(2, 2)} />}
              {l.name === 'Layer opacity' && (
                <>
                  <span className={s.diamond} style={x(2, 2)} />
                  <span className={s.tail} style={x(4, 7)} />
                  <span className={s.diamond} style={x(4, 4)} />
                  <span className={s.tail} style={x(20, 23)} />
                  <span className={s.diamond} style={x(20, 20)} />
                </>
              )}
              {l.name === 'Settings' && <span className={s.diamond} style={x(2, 2)} />}
            </div>
          </>
        ))}
        <div className={s.after} style={x(CLIP_END, VIEW_END)} />
        <div className={s.playhead} style={x(4, 4)} />
      </div>
      <footer className={b.keys}>
        One row per thing the clip changes · two bars on one row at once is a clash · click a bar to edit it in place
      </footer>
    </section>
  );
}

export default StudioC;
