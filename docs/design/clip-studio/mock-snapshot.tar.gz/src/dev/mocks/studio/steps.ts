// The real `cosmicFlows` clip (src/compositions/clips/cosmicFlows.ts), one row per authored
// step, timings from compileClip (scratchpad compile.ts). `fork` is drawn as a flag on its child.
export const CLIP_END = 20;
export const VIEW_END = 24;

export const STEPS = [
  { id: 'wait', depth: 0, shape: 'gap', cat: 'Wait', label: 'Wait', detail: '2 s', start: 0, end: 2 },
  { id: 'hide', depth: 0, shape: 'cue', cat: 'Scene', label: 'Hide cosmic web and galaxy labels', detail: 'instant', start: 2, end: 2 },
  { id: 'mask', depth: 0, shape: 'cue', cat: 'Scene', label: 'Fade flow to 0 %', detail: 'instant', start: 2, end: 2 },
  { id: 'flowOn', depth: 0, shape: 'cue', cat: 'Scene', label: 'Turn flow on', detail: 'setting', start: 2, end: 2 },
  { id: 'bob', depth: 0, shape: 'osc', cat: 'Camera', label: 'Bob pitch ±5.2° every 16 s', detail: 'whole clip', start: 0, end: 20, background: true },
  { id: 'spinUp', depth: 0, shape: 'rate', cat: 'Camera', label: 'Ease turn speed to 10.3°/s', detail: '1.5 s', start: 2, end: 3.5, holdTo: 4, background: true },
  { id: 'hold1', depth: 0, shape: 'gap', cat: 'Wait', label: 'Hold', detail: '2 s', start: 2, end: 4 },
  { id: 'cross', depth: 0, shape: 'group', cat: 'Together', label: 'Together', detail: '2 steps · 0 s', start: 4, end: 4, collapsed: true },
  { id: 'pull', depth: 0, shape: 'group', cat: 'Together', label: 'Together', detail: '11 s', start: 4, end: 15 },
  { id: 'order', depth: 1, shape: 'group', cat: 'In order', label: 'In order', detail: '3 steps · 11 s', start: 4, end: 15 },
  { id: 'dolly1', depth: 2, shape: 'move', cat: 'Camera', label: 'Pull back to 300 Mpc', detail: '4 s', start: 4, end: 8 },
  { id: 'hold2', depth: 2, shape: 'gap', cat: 'Wait', label: 'Hold', detail: '3 s', start: 8, end: 11 },
  { id: 'dolly2', depth: 2, shape: 'move', cat: 'Camera', label: 'Pull back to 950 Mpc', detail: '4 s', start: 11, end: 15 },
  { id: 'slow', depth: 1, shape: 'rate', cat: 'Camera', label: 'Slow turn speed to 1.4°/s', detail: '11 s', start: 4, end: 15, holdTo: 20 },
  { id: 'hold3', depth: 0, shape: 'gap', cat: 'Wait', label: 'Hold', detail: '5 s', start: 15, end: 20 },
  { id: 'black', depth: 0, shape: 'cue', cat: 'Scene', label: 'Fade flow, Milky Way, rings, labels to 0 %', detail: '3 s fade', start: 20, end: 20, tail: 3, warn: true },
];
