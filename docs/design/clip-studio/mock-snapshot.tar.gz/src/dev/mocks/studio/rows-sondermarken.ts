// Rows for the real `sondermarkenFlyout` clip at simDays 2461354 (9 Nov 2026 12:00 UTC), timings
// and values from resolveClipFoci + compileClip + evaluateClip. Distances use the app's ladder
// (formatDistance, no ly companion); `scale` is when the dolly crosses each unit. `frame` marks a
// value read in a body frame; `dated` marks a value that changes when the factory's simDays does
// (found by evaluating the factory at two instants and diffing).
import { row } from './stepsD';

export function sondermarkenRows() {
  return [
    row('start', 0, 'start', 'Start', '', '801 m', '–', 0, 0, {
      writes: ['dist', 'look', 'turn'],
      frame: 'Earth',
      dated: true,
    }),
    row('order', 0, 'seq', 'In order', '', 'Wait, Together +1', '97 s', 0, 97, { writes: ['dist', 'turn'] }),
    row('lead', 1, 'wait', 'Wait', '', '', '3 s', 0, 3),
    row('flight', 1, 'all', 'Together', '', 'Distance, Aim +1', '90 s', 3, 93, { writes: ['dist', 'turn'] }),
    row('dolly', 2, 'dist', 'Distance', '→', '29.5 Gpc', '90 s', 3, 93, {
      ch: 'dist',
      scale: [
        { t: 12.0, label: 'km' },
        { t: 42.7, label: 'AU' },
        { t: 50.0, label: 'pc' },
        { t: 54.6, label: 'kpc' },
        { t: 60.7, label: 'Mpc' },
        { t: 70.7, label: 'Gpc' },
      ],
    }),
    row('aim', 2, 'aim', 'Aim', '→', '−90° el', '20 s', 3, 23, { ch: 'turn', frame: 'Earth', dated: true }),
    row('roll', 2, 'roll', 'Roll', '→', '40°', '20 s', 3, 23, { ch: 'turn', dated: true }),
    row('hold', 1, 'hold', 'Hold', '', '', '4 s', 93, 97),
  ];
}
