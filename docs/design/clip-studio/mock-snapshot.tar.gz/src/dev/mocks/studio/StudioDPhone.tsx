import cx from 'classnames';
import { useDockCover } from './useDockCover';
import './hideReal.css';
import s from './StudioDPhone.module.css';

type Props = Record<string, never>;

// 400 px: the owner's ruling (ASK 3, A) — no editor, Play and Close only.
function StudioDPhone(_: Props) {
  const ref = useDockCover();
  return (
    <section ref={ref} className={s.sheet} aria-label="Clip studio">
      <div className={s.head}>
        <span className={s.title}>Cosmic Flows</span>
        <span className={s.meta}>20 s · Clip studio</span>
      </div>
      <p className={s.note} role="status">
        <span className={s.icon} aria-hidden>⇔</span>
        Editing needs a wider screen · ≥ 1024 px
      </p>
      <div className={s.row}>
        <button type="button" className={cx(s.btn, s.primary)}>▶ Play</button>
        <button type="button" className={s.btn}>Close</button>
      </div>
    </section>
  );
}

export default StudioDPhone;
