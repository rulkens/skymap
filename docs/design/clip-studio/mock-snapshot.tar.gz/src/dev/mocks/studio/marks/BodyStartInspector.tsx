import Panel, { Head, Grid, Sec, Row, Wide, Num, Pick, Out, Seg, UseView } from '../InspectorGrid';

type Props = Record<string, never>;

// sondermarkenFlyout's Start: a body-fixed pose (the `b,earth,…` link), so its world pose and the
// Aim and Roll built from it turn with Earth. The studio pins the sim date (Q7). Save keeps these
// as body-frame literals (owner ruling), so the file stays date-independent: ◷ is information only.
function BodyStartInspector(_: Props) {
  return (
    <Panel>
      <Head glyph="start" where="Start" range="0:00.0" title="Start · saved view" />
      <Grid>
        <Sec title="Pose" />
        <Row label="From">
          <Seg label="Start from" value="saved" options={[['saved', 'Saved'], ['live', 'Live']]} />
        </Row>
        <Row label="Frame" tip="Metres and angles about Earth's axes">
          <Seg label="Frame" value="earth" options={[['abs', 'Absolute'], ['earth', 'Earth', 'body']]} />
        </Row>
        <Row label="Site">
          <Out>55.7° N 12.5° E</Out>
        </Row>
        <Row label="Height">
          <Out>46 m</Out>
        </Row>
        <Row label="Range" unit="m">
          <Num value="801" fill={0.1} />
        </Row>
        <Row label="Look" tip="Compass bearing, then tilt">
          <Out>N, −3°</Out>
        </Row>
        <Sec title="Sim date" aside="◷ pinned" />
        <Row label="Date" tip="Pinned while editing" unit="UTC" reset>
          <Pick>9 Nov 2026 12:00</Pick>
        </Row>
        <Row label="Saves as" tip="Earth-frame literals: any date works">
          <Out>Start · Aim · Roll · Earth</Out>
        </Row>
        <Wide>
          <UseView primary captures="the Earth-fixed pose" />
        </Wide>
      </Grid>
    </Panel>
  );
}

export default BodyStartInspector;
