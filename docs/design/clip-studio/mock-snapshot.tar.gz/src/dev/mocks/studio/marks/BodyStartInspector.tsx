import Panel, { Head, Grid, Sec, Row, Wide, Num, Pick, Out, Seg, Chip, Btn } from '../InspectorGrid';

type Props = Record<string, never>;

// sondermarkenFlyout's Start: a body-fixed pose (the `b,earth,…` link), so its world pose and the
// Aim and Roll built from it turn with Earth. The studio pins the sim date (Q7); the Sim date
// section names what moves with it and the chip says what Save freezes.
function BodyStartInspector(_: Props) {
  return (
    <Panel>
      <Head glyph="start" where="Start" range="0.0 s" title="Start · saved view" />
      <Grid>
        <Sec title="Pose" />
        <Row label="From">
          <Seg label="Start from" value="saved" options={[['saved', 'Saved'], ['live', 'Live']]} />
        </Row>
        <Row label="Frame" tip="Earth-fixed: metres and angles about Earth's axes">
          <Seg label="Frame" value="earth" options={[['abs', 'Absolute'], ['earth', 'Earth', 'body']]} />
        </Row>
        <Row label="Site">
          <Out>55.7° N 12.5° E</Out>
        </Row>
        <Row label="Height" unit="m">
          <Out>46</Out>
        </Row>
        <Row label="Range" unit="m ▾">
          <Num value="801" fill={0.1} />
        </Row>
        <Row label="Look" unit="tilt">
          <Out>N · −3°</Out>
        </Row>
        <Sec title="Sim date" aside="◷ pinned" />
        <Row label="Date" tip="Pinned while editing; the factory reads Earth at this instant" unit="UTC" reset>
          <Pick>9 Nov 2026 12:00</Pick>
        </Row>
        <Row label="Moves" tip="+1 day: frozen Start lands 2.6 M km from Earth" unit="◷ 3">
          <Out>Start · Aim · Roll</Out>
        </Row>
        <Wide>
          <Chip action="Save as new">Save → literals at this date</Chip>
        </Wide>
        <Wide>
          <Btn kbd="V" primary>Use current view</Btn>
        </Wide>
      </Grid>
    </Panel>
  );
}

export default BodyStartInspector;
