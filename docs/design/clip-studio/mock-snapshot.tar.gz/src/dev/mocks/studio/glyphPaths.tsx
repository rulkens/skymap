import type { ReactNode } from 'react';

// Inner paths for the studio glyphs the app's icon set lacks, on the Icon frame's 24-unit grid
// (round stroke, currentColor). Glyphs with an app icon (layers, show, warn, …) use that icon.
export const GLYPH_PATHS: Record<string, ReactNode> = {
  wait: <path d="M6 3h12M6 21h12M7.5 3c0 6 9 6 9 9s-9 3 -9 9M16.5 3c0 6 -9 6 -9 9" />,
  hold: <path d="M8.25 4.5v15M15.75 4.5v15" />,
  dist: <path d="M12 2.25v19.5M6.75 7.5L12 2.25 17.25 7.5M6.75 16.5L12 21.75 17.25 16.5" />,
  look: <path d="M12 1.5v6M12 16.5v6M1.5 12h6M16.5 12h6M12 8.25a3.75 3.75 0 1 1 0 7.5a3.75 3.75 0 1 1 0 -7.5" />,
  aim: <path d="M3 12h12M10.5 6.75L15.75 12 10.5 17.25M20.25 3.75v16.5" />,
  rate: <path d="M3 20.25L19.5 6M19.5 6H12.75M19.5 6v6.75" />,
  osc: <path d="M1.5 12c2.7 -7.5 5.4 -7.5 8.1 0s5.4 7.5 8.1 0 3.3 -4.5 4.8 -4.5" />,
  fade: <path d="M12 3a9 9 0 1 0 0 18zM12 3a9 9 0 0 1 0 18" />,
  focus: <path d="M3 8.25V3h5.25M15.75 3H21v5.25M21 15.75V21h-5.25M8.25 21H3v-5.25M12 10.5v3" />,
  seq: <path d="M2.25 5.25h7.5M7.5 12h7.5M12.75 18.75h9" />,
  all: <path d="M3 3v18M6.75 6h13.5M6.75 12h13.5M6.75 18h13.5" />,
  fork: <path d="M6 3v18M6 13.5c0 -6 12 -4.5 12 -10.5" />,
  jstop: <path d="M1.5 19.5Q6 4.5 11.25 19.5M12.75 19.5Q18 4.5 22.5 19.5" />,
  jnostop: <path d="M1.5 19.5Q6 3 12 10.5Q18 3 22.5 19.5" />,
  jblend: <path d="M1.5 6C9 6 15 18 22.5 18M1.5 18C9 18 15 6 22.5 6" />,
  end: <path d="M5.25 3v18M5.25 3.75h13.5l-3.75 4.5 3.75 4.5h-13.5" />,
  magnet: <path d="M6 3v9a6 6 0 0 0 12 0V3M6 7.5h3M15 7.5h3" />,
  grip: <path d="M9 4.5v15M15 4.5v15" />,
  subject: <path d="M12 3.75a8.25 8.25 0 1 1 0 16.5a8.25 8.25 0 1 1 0 -16.5M12 10.5a1.5 1.5 0 1 1 0 3a1.5 1.5 0 1 1 0 -3" />,
  strafe: <path d="M3 12h18M7.5 7.5L3 12l4.5 4.5M16.5 7.5l4.5 4.5 -4.5 4.5M12 4.5v3M12 16.5v3" />,
  frame: <path d="M3 17.25h18M6.75 9.75l10.5 -4.5M12 17.25V12" />,
  body: <path d="M12 3a9 9 0 1 1 0 18a9 9 0 1 1 0 -18M3 12h18M12 3c-3.75 4.5 -3.75 13.5 0 18M12 3c3.75 4.5 3.75 13.5 0 18" />,
  fly: <path d="M2.25 19.5c4.5 -10.5 9 -1.5 13.5 -9l1.5 -3M13.5 6.75l4.5 -0.75 0.3 4.5M4.5 21a1.5 1.5 0 1 1 0 -0.15" />,
  pass: <path d="M15.75 4.5a3.75 3.75 0 1 1 0 7.5a3.75 3.75 0 1 1 0 -7.5M2.25 21.75C4.5 13.5 9 14.25 12 16.5s6 3.75 9.75 1.5" />,
  settle: <path d="M12 3.75a8.25 8.25 0 1 1 0 16.5a8.25 8.25 0 1 1 0 -16.5M12 9.75a2.25 2.25 0 1 1 0 4.5a2.25 2.25 0 1 1 0 -4.5" />,
  point: <path d="M7.5 7.5h9v9H7.5zM12 1.5v4.5M12 18v4.5M1.5 12h4.5M18 12h4.5" />,
  lock: <path d="M6 11.25h12v9.75H6zM8.25 11.25V7.5a3.75 3.75 0 0 1 7.5 0v3.75" />,
  pin: <path d="M12 14.25V22.5M7.5 3h9l-1.5 6 3 5.25H6L9 9z" />,
  edit: <path d="M2.25 6.75l9.75 -4.5 9.75 4.5v10.5l-9.75 4.5 -9.75 -4.5zM2.25 6.75L12 12l9.75 -5.25M12 12v9.75" />,
  loop: <path d="M17 3.5 20 6.5 17 9.5M4 11.5v-1a4 4 0 0 1 4-4h12M7 20.5l-3-3 3-3M20 12.5v1a4 4 0 0 1-4 4H4" />,
  undo: <path d="M9 13.5 4.5 9 9 4.5M4.5 9h10a5 5 0 0 1 0 10H11" />,
  redo: <path d="M15 13.5 19.5 9 15 4.5M19.5 9h-10a5 5 0 0 0 0 10H13" />,
  // picture-in-picture with a turn arrow: swap the main view and the inset
  swap: (
    <>
      <rect x="3" y="5" width="18" height="14" rx="2" />
      <g fill="currentColor" stroke="none">
        <rect x="12.5" y="11.5" width="6" height="5" rx="1" />
      </g>
      <path d="M6.5 13.5V10a2 2 0 0 1 2-2H11M9.5 6.5 11 8 9.5 9.5" />
    </>
  ),
  chevronDown: <path d="M7 10l5 5 5-5" />,
  chevronRight: <path d="M10 7l5 5-5 5" />,
  chevronLeft: <path d="M14 7l-5 5 5 5" />,
  keys: (
    <>
      <rect x="2.5" y="6" width="19" height="12" rx="2" />
      <path d="M6.5 10h.01M10 10h.01M14 10h.01M17.5 10h.01M8 14h8" />
    </>
  ),
  more: (
    <g fill="currentColor" stroke="none">
      <circle cx="6" cy="12" r="1.5" />
      <circle cx="12" cy="12" r="1.5" />
      <circle cx="18" cy="12" r="1.5" />
    </g>
  ),
  fit: <path d="M3 8V5h3M21 8V5h-3M3 16v3h3M21 16v3h-3M7 12h10M9.5 9.5 7 12l2.5 2.5M14.5 9.5 17 12l-2.5 2.5" />,
  // the window a view returns to: an arrow down into a tray
  dock: <path d="M12 3.5v10M8 9.5l4 4 4-4M4 15v4.5h16V15" />,
};
