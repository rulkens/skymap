import type { CSSProperties } from 'react';
import cx from 'classnames';
import Button from '../../../components/common/Button/Button';
import Slider from '../../../components/common/Slider/Slider';
import { CLIP_END, VIEW_END } from './steps';
import './hideReal.css';
import { useDockCover } from './useDockCover';
import b from './StudioB.module.css';
import s from './StudioA.module.css';

type Props = Record<string, never>;

const x = (a: number, e: number): CSSProperties =>
  ({ '--f': a / VIEW_END, '--w': (e - a) / VIEW_END }) as CSSProperties;
const noop = () => {};

function StudioA(_: Props) {
  const ref = useDockCover();
  return (
    <>
      <aside className={s.inspector} aria-label="Step settings">
        <p className={b.eyebrow}>Camera move · distance</p>
        <h2 className={b.h}>Pull back to 300 Mpc</h2>
        <Slider label="Distance" value={0.62} onChange={noop} format={() => '300 Mpc'} />
        <Slider label="Duration" value={0.2} onChange={noop} format={() => '4.0 s'} />
        <div className={b.field}>
          <span className={b.fieldLabel}>Easing</span>
          <button type="button" className={b.select}>
            Slow start and end ▾
          </button>
        </div>
        <Button className={b.inlineBtn}>
          Use current view’s distance<kbd className={b.kbd}>V</kbd>
        </Button>
      </aside>
      <section ref={ref} className={s.dock} aria-label="Clip studio">
        <header className={b.topbar}>
          <div className={b.clip}>
            <span className={b.title}>Cosmic Flows</span>
            <span className={b.status}>20.0 s · saved</span>
          </div>
          <div className={b.transport}>
            <button type="button" className={b.tbtn}>
              ⏮<kbd className={b.kbd}>Home</kbd>
            </button>
            <button type="button" className={cx(b.tbtn, b.play)}>
              ▶<kbd className={b.kbd}>Space</kbd>
            </button>
            <span className={b.time}>04.00 / 20.00 s</span>
          </div>
          <div className={b.tools}>
            <Button className={b.toolBtn}>
              + Add step<kbd className={b.kbd}>A</kbd>
            </Button>
            <Button className={b.toolBtn} variant="ghost">
              Undo<kbd className={b.kbd}>⌘Z</kbd>
            </Button>
            <Button className={b.toolBtn} variant="ghost">
              Close studio
            </Button>
          </div>
        </header>
        <div className={s.canvas}>
          <div className={s.ruler}>
            {Array.from({ length: VIEW_END / 2 + 1 }, (_, i) => (
              <span key={i} className={s.tick} style={x(i * 2, i * 2)}>
                {i * 2}
              </span>
            ))}
          </div>
          <div className={s.afterEnd} style={x(CLIP_END, VIEW_END)} />
          <div className={s.playhead} style={x(4, 4)} />

          <div className={s.laneLabel}>Background</div>
          <div className={s.lane}>
            <span className={cx(s.block, s.osc)} style={x(0, 24)}>
              Bob pitch ±5.2° · whole clip ∞
            </span>
          </div>
          <div className={s.lane}>
            <span className={cx(s.block, s.rate)} style={x(2, 3.5)}>
              Turn
            </span>
            <span className={s.hold} style={x(3.5, 4)} />
          </div>

          <div className={s.laneLabel}>Steps</div>
          <div className={s.main}>
            <span className={cx(s.block, s.gap)} style={x(0, 2)}>
              Wait 2 s
            </span>
            <span className={s.cues} style={x(2, 2)}>
              <span className={s.diamond} />
              <span className={s.cueCount}>3</span>
            </span>
            <span className={cx(s.block, s.gap)} style={x(2, 4)}>
              Hold 2 s
            </span>
            <span className={s.cues} style={x(4, 4)}>
              <span className={s.diamond} />
              <span className={s.tail} />
            </span>
            <div className={s.box} style={x(4, 15)}>
              <span className={s.boxHead}>Together · 11 s</span>
              <div className={s.box2}>
                <span className={s.boxHead}>In order · 3 steps</span>
                <div className={s.inner}>
                  <span className={cx(s.block, s.move, s.sel)} style={{ width: `${(4 / 11) * 100}%` }}>
                    Pull back to 300 Mpc
                  </span>
                  <span className={cx(s.block, s.gap)} style={{ width: `${(3 / 11) * 100}%` }}>
                    Hold 3 s
                  </span>
                  <span className={cx(s.block, s.move)} style={{ width: `${(4 / 11) * 100}%` }}>
                    Pull back to 950 Mpc
                  </span>
                </div>
              </div>
              <span className={cx(s.block, s.rate, s.inLane)}>Slow turn to 1.4°/s</span>
            </div>
            <span className={cx(s.block, s.gap)} style={x(15, 20)}>
              Hold 5 s
            </span>
            <span className={s.cues} style={x(20, 20)}>
              <span className={s.diamond} />
              <span className={cx(s.tail, s.tailLong)} />
              <span className={s.warn}>⚠ cut at end</span>
            </span>
          </div>
        </div>
        <footer className={b.keys}>
          Click a block to edit · drag its end to change length · drag a block sideways to reorder · double-click a box to
          open it
        </footer>
      </section>
    </>
  );
}

export default StudioA;
