import CloseIcon from '../../../components/icons/CloseIcon/CloseIcon';
import s from './TopBar.module.css';

// The `?` sheet: every studio key in one place, grouped by what it acts on. Non-modal,
// drops under the bar's right end; `?` or Escape closes it. A short group shares a column.
const COLUMNS: readonly (readonly (readonly [string, readonly (readonly [string, string])[]])[])[] = [
  [['Play', [['Space', 'Play · pause'], ['Home', 'To start'], ['L', 'Loop'], [', .', 'Nudge frame'], ['⌥ ← →', 'Jump to edge']]]],
  [
    ['Views', [['F', 'Swap views'], ['− =', 'Zoom'], ['0', 'Fit clip']]],
    ['Drag', [['⌥', 'No snap'], ['⇧', 'Fine']]],
  ],
  [['Steps', [['↑ ↓', 'Select'], ['← →', 'Fold'], ['A', 'Add step'], ['⌘ D', 'Duplicate'], ['⌘ G', 'Wrap'], ['⌫', 'Delete']]]],
  [['Clip', [['⌘ Z', 'Undo'], ['⇧ ⌘ Z', 'Redo'], ['⌘ S', 'Save'], ['⇧ ⌘ S', 'Save as new'], ['⌘ O', 'Open clip'], ['Esc', 'Close']]]],
];

function TopBarKeys() {
  return (
    <div className={s.sheet} role="dialog" aria-label="Keyboard shortcuts">
      <div className={s.sheetHead}>
        <span className={s.sheetTitle}>Keys</span>
        <button type="button" className={s.icon} aria-label="Close keys">
          <CloseIcon size={14} />
        </button>
      </div>
      <div className={s.sheetGrid}>
        {COLUMNS.map((groups) => (
          <div key={groups[0]![0]} className={s.sheetCol}>
          {groups.map(([group, rows]) => (
          <section key={group} className={s.sheetGroup}>
            <h3 className={s.sheetGroupTitle}>{group}</h3>
            {rows.map(([k, label]) => (
              <span key={label} className={s.sheetRow}>
                <span className={s.sheetKeys}>
                  {k.split(' ').map((c) => (
                    <kbd key={c} className={s.chip}>{c}</kbd>
                  ))}
                </span>
                {label}
              </span>
            ))}
          </section>
          ))}
          </div>
        ))}
      </div>
    </div>
  );
}

export default TopBarKeys;
