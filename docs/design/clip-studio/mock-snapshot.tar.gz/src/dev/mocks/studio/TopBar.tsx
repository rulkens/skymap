import type { ReactNode } from 'react';
import { useContext } from 'react';
import cx from 'classnames';
import Button from '../../../components/common/Button/Button';
import PlayIcon from '../../../components/icons/PlayIcon/PlayIcon';
import PauseIcon from '../../../components/icons/PauseIcon/PauseIcon';
import PrevIcon from '../../../components/icons/PrevIcon/PrevIcon';
import PlusIcon from '../../../components/icons/PlusIcon/PlusIcon';
import MinusIcon from '../../../components/icons/MinusIcon/MinusIcon';
import CloseIcon from '../../../components/icons/CloseIcon/CloseIcon';
import AlertIcon from '../../../components/icons/AlertIcon/AlertIcon';
import StudioIcon from './StudioIcon';
import StudioTip from './StudioTip';
import KeysSheet from './TopBarKeys';
import TopBarContext from './TopBarContext';
import { clipTime } from './clipTime';
import s from './TopBar.module.css';

// The studio's top bar. Shortcuts live in each control's tip and in the keys sheet (`?`),
// never printed on the bar. `variant`: a = centred transport, b = columns aligned to the
// dock grid below (outline | timeline | inspector), c = minimal with an overflow menu.
type Props = {
  readonly variant?: 'a' | 'b' | 'c';
  readonly title: string;
  readonly handWritten?: boolean;
  readonly generated?: boolean;
  readonly tags?: ReactNode;
  readonly status: string;
  // Q11: once per clip while a hand-written clip is unsaved; `true` = the default copy.
  readonly saveNote?: ReactNode;
  readonly edits?: number;
  readonly playing?: boolean;
  readonly empty?: boolean;
  readonly t: number;
  readonly clipEnd: number;
  // Values that depend on the sim date (◷): they save as body-frame literals, said in the note's tip.
  readonly dated?: number;
  readonly loop?: boolean;
  readonly swapped?: boolean;
  readonly undoLabel?: string;
  readonly zoom?: string;
  // Shots only: tip ids forced open, the keys sheet, the overflow menu.
  readonly tips?: readonly string[];
  readonly keysOpen?: boolean;
  readonly menuOpen?: boolean;
};

const STATUS: Record<string, string> = {
  unsaved: 'Unsaved',
  saved: 'Saved',
  saving: 'Saving…',
  new: 'Not saved',
  unavailable: 'Read-only',
};

function TopBar(props: Props) {
  const ctx = useContext(TopBarContext);
  const p = { ...props, tips: props.tips ?? ctx.tips, keysOpen: props.keysOpen ?? ctx.keysOpen, menuOpen: props.menuOpen ?? ctx.menuOpen };
  const v = props.variant ?? ctx.variant ?? 'b';
  const on = (id: string) => Boolean(p.tips?.includes(id));
  const time = clipTime(p.clipEnd);
  const dirty = p.status === 'unsaved';
  const undoWhat = (p.undoLabel ?? 'Undo').replace(/^Undo\s*/, '');
  const canSave = dirty || p.status === 'failed';
  const below = 'top' as const; // bar tips open over the scene, never over the rows
  const zoomLevel = p.zoom ?? 'Fit';

  const origin = p.handWritten ? 'Hand-written' : p.generated ? 'Generated' : undefined;

  const identity = (
    <div className={s.identity}>
      <StudioTip name="Open clip" meaning={p.title} keys={['⌘', 'O']} state={origin && `${origin} · ${origin === 'Hand-written' ? 'saves rewrite its file' : 'owned by the studio'}`} side={below} open={on('clip')}>
        <button type="button" className={s.titleBtn} aria-label={`Clip: ${p.title}. Open another clip`}>
          <span className={s.title}>{p.title}</span>
          <StudioIcon kind="chevronDown" size={14} />
        </button>
      </StudioTip>
      {origin && <span className={s.origin}>{origin}</span>}
      {p.tags}
    </div>
  );

  const alert =
    p.status === 'invalid' ? (
      <span className={s.alert} role="alert">
        <AlertIcon size={14} />
        Won’t compile · playing last valid
      </span>
    ) : p.status === 'failed' ? (
      <span className={s.alert} role="alert">
        <AlertIcon size={14} />
        Save failed · file changed
        <button type="button" className={s.inlineBtn}>Retry</button>
      </span>
    ) : undefined;

  const status = alert ?? (
    <span className={cx(s.status, dirty && s.statusDirty)} role="status">
      <span className={cx(s.dot, dirty && s.dotDirty, p.status === 'saved' && s.dotSaved)} aria-hidden />
      {STATUS[p.status]}
    </span>
  );

  const note =
    dirty && p.saveNote ? (
      <StudioTip
        name="Makers → literals"
        meaning="Saving flattens makers and constants into numbers"
        state={p.dated ? `◷ ${p.dated} save in Earth's frame · any date works` : 'Keep them: Save as new'}
        side={below}
        open={on('note')}
      >
        <span className={s.note} tabIndex={0}>
          {p.saveNote === true ? 'Makers → literals' : p.saveNote}
        </span>
      </StudioTip>
    ) : undefined;

  const transport = (
    <div className={s.transport}>
      <StudioTip name="To start" keys={['Home']} side={below} open={on('start')}>
        <button type="button" className={s.icon} aria-label="Go to start" disabled={p.empty}>
          <PrevIcon size={16} />
        </button>
      </StudioTip>
      <StudioTip name={p.playing ? 'Pause' : 'Play'} keys={['Space']} state={p.loop ? 'Loops the selection' : undefined} side={below} open={on('play')}>
        <button type="button" className={s.play} aria-label={p.playing ? 'Pause' : 'Play'} disabled={p.empty}>
          {p.playing ? <PauseIcon size={16} /> : <PlayIcon size={16} />}
        </button>
      </StudioTip>
      <StudioTip name="Playhead" meaning="Click to type a time" keys={[',', '.']} state="Nudge one frame" side={below} open={on('time')}>
        <button type="button" className={s.readout} aria-label="Playhead time, click to type">
          {time.at(p.empty ? 0 : p.t)}
          <span className={s.readoutEnd}> / {time.at(p.empty ? 0 : p.clipEnd)}</span>
        </button>
      </StudioTip>
      <StudioTip name="Loop" meaning="Selected step, or the whole clip" keys={['L']} state={p.loop ? 'On' : 'Off'} side={below} open={on('loop')}>
        <button type="button" className={s.icon} aria-label="Loop" aria-pressed={Boolean(p.loop)} disabled={p.empty}>
          <StudioIcon kind="loop" />
        </button>
      </StudioTip>
    </div>
  );

  const swap = (
    <StudioTip
      name="Swap views"
      keys={['F']}
      state={p.swapped ? 'Main: Camera · inset: Edit' : 'Main: Edit · inset: Camera'}
      side={below}
      open={on('swap')}
    >
      <button type="button" className={s.icon} aria-label={p.swapped ? 'Swap: Edit view to main' : 'Swap: Camera view to main'} aria-pressed={Boolean(p.swapped)}>
        <StudioIcon kind="swap" />
      </button>
    </StudioTip>
  );

  const zoom = (
    <div className={s.zoom} role="group" aria-label="Zoom">
      <StudioTip name="Zoom out" keys={['−']} side={below} open={on('zoomOut')}>
        <button type="button" className={s.icon} aria-label="Zoom out" disabled={p.empty}>
          <MinusIcon size={14} />
        </button>
      </StudioTip>
      <StudioTip name="Fit clip" keys={['0']} side={below} open={on('fit')}>
        <button type="button" className={s.zoomLevel} aria-pressed={!p.zoom} disabled={p.empty}>
          {zoomLevel}
        </button>
      </StudioTip>
      <StudioTip name="Zoom in" keys={['=']} side={below} open={on('zoomIn')}>
        <button type="button" className={s.icon} aria-label="Zoom in" disabled={p.empty}>
          <PlusIcon size={14} />
        </button>
      </StudioTip>
    </div>
  );

  const history = (
    <div className={s.cluster}>
      <StudioTip
        name="Undo"
        keys={['⌘', 'Z']}
        state={undoWhat && <><span className={s.tipDim}>Last edit</span> {undoWhat[0]!.toUpperCase() + undoWhat.slice(1)}</>}
        side={below}
        open={on('undo')}
      >
        <button type="button" className={s.icon} aria-label={p.undoLabel ?? 'Undo'} disabled={p.empty}>
          <StudioIcon kind="undo" />
        </button>
      </StudioTip>
      <StudioTip name="Redo" keys={['⇧', '⌘', 'Z']} side={below} open={on('redo')}>
        <button type="button" className={s.icon} aria-label="Redo" disabled>
          <StudioIcon kind="redo" />
        </button>
      </StudioTip>
    </div>
  );

  const saveState =
    p.status === 'unavailable' ? 'Dev server only' : dirty ? `Unsaved · ${p.edits ?? 3} edits` : STATUS[p.status];
  const save = (
    <div className={s.split}>
      <StudioTip name="Save" meaning={p.handWritten ? 'Rewrites the clip file' : undefined} keys={['⌘', 'S']} state={saveState} side={below} open={on('save')}>
        <Button
          className={cx(s.save, v !== 'c' && s.saveSplit)}
          variant={canSave ? 'primary' : 'secondary'}
          disabled={!canSave || p.empty}
        >
          Save
        </Button>
      </StudioTip>
      {v !== 'c' && (
        <StudioTip name="Save as new" keys={['⇧', '⌘', 'S']} side={below} open={on('saveAs')}>
          <button
            type="button"
            className={cx(s.caret, canSave && s.caretPrimary)}
            aria-label="Save as new"
            aria-haspopup="menu"
            disabled={p.status === 'unavailable' || p.empty}
          >
            <StudioIcon kind="chevronDown" size={14} />
          </button>
        </StudioTip>
      )}
    </div>
  );

  const keys = (
    <StudioTip name="Keys" keys={['?']} side={below} open={on('keys')}>
      <button type="button" className={s.icon} aria-label="Keyboard shortcuts" aria-pressed={Boolean(p.keysOpen)} aria-expanded={Boolean(p.keysOpen)}>
        <StudioIcon kind="keys" />
      </button>
    </StudioTip>
  );

  const close = (
    <StudioTip name="Close studio" keys={['Esc']} state={dirty ? `${p.edits ?? 3} unsaved edits kept until reload` : undefined} side={below} open={on('close')}>
      <button type="button" className={s.icon} aria-label="Close studio">
        <CloseIcon size={16} />
      </button>
    </StudioTip>
  );

  const more = (
    <div className={s.menuWrap}>
      <StudioTip name="More" side={below} open={on('more')}>
        <button type="button" className={cx(s.icon, p.menuOpen && s.pressed)} aria-label="More" aria-haspopup="menu" aria-expanded={Boolean(p.menuOpen)}>
          <StudioIcon kind="more" />
        </button>
      </StudioTip>
      {p.menuOpen && (
        <div className={s.menu} role="menu">
          <button type="button" role="menuitem" className={s.menuItem} disabled={p.status === 'unavailable'}>
            Save as new
          </button>
          <span className={s.menuRule} />
          <span className={s.menuRow}>
            Zoom
            {zoom}
          </span>
          <span className={s.menuRule} />
          <button type="button" role="menuitem" className={s.menuItem}>
            Keys
          </button>
        </div>
      )}
    </div>
  );

  const sep = <span className={s.sep} aria-hidden />;

  return (
    <header className={cx(s.bar, s[`v_${v}`])} aria-label="Clip">
      {v === 'a' && (
        <>
          <div className={s.left}>
            {identity}
            {status}
            {note}
          </div>
          <div className={s.centre}>
            {transport}
            {swap}
          </div>
          <div className={s.right}>
            {zoom}
            {sep}
            {history}
            {save}
            {sep}
            {keys}
            {close}
          </div>
        </>
      )}
      {v === 'b' && (
        <>
          <div className={s.left}>
            {identity}
            {status}
            {note}
          </div>
          <div className={s.centre}>
            {transport}
            {swap}
            <span className={s.grow} />
            {zoom}
          </div>
          <div className={s.right}>
            {history}
            {save}
            <span className={s.grow} />
            {keys}
            {close}
          </div>
        </>
      )}
      {v === 'c' && (
        <>
          <div className={s.left}>
            {identity}
            {status}
            {note}
          </div>
          <div className={s.centre}>
            {transport}
            {swap}
          </div>
          <div className={s.right}>
            {history}
            {save}
            {more}
            {close}
          </div>
        </>
      )}
      {p.keysOpen && <KeysSheet />}
    </header>
  );
}

export default TopBar;
