import type { CSSProperties } from 'react';
import cx from 'classnames';
import Glyph from './StudioDGlyph';
import StudioTip from './StudioTip';
import { clipTime } from './clipTime';
import { cosmicRows } from './stepsD';
import { envelope, ss, sample, distanceAt, DIST_LO, DIST_HI } from './studioDCurves';
import PerpetualCut from './marks/PerpetualCut';
import EndMark from './marks/EndMark';
import LoopGhost from './marks/LoopGhost';
import s from './StudioD.module.css';

type Props = {
  readonly r: ReturnType<typeof cosmicRows>[number];
  readonly ancestors: ReturnType<typeof cosmicRows>;
  readonly viewEnd: number;
  readonly clipEnd: number;
  readonly mode: string;
  readonly sel: boolean;
  readonly joinSel: boolean;
  readonly groupSel: boolean;
  readonly wrapAt?: number;
  readonly viewStart?: number;
};

const ch = (c: string) => (c ? s[`c_${c}`] : undefined);

// Crossfade treatment per mode. t1 (the ruling): both moves taper linearly across exactly the
// overlap window, two hairlines mark it through every row it touches, and the join chip sits
// inside it. t2 (lens) and t3 (value curve) stay for comparison only; t3 lives in the join inspector.
function StudioDTrack({ r, ancestors, viewEnd, clipEnd, mode, sel, joinSel, groupSel, wrapAt, viewStart = 0 }: Props) {
  const v0 = viewStart;
  const time = clipTime(clipEnd);
  const fmtRange = (a: number, z: number) => time.span(a, z);
  const x = (t: number) => `${((t - v0) / (viewEnd - v0)) * 100}%`;
  const span = (a: number, z: number): CSSProperties => ({ left: x(a), width: `${((z - a) / (viewEnd - v0)) * 100}%` });
  const at = (t: number): CSSProperties => ({ left: x(t) });

  const bands = ancestors.map((a) => (
    <span key={a.id} className={cx(s.band, s[`band_${a.kind}`], groupSel && a.id === 'pull' && s.bandSel)} style={span(a.start, a.end)} aria-hidden />
  ));

  const mark = (() => {
    switch (r.kind) {
      case 'start':
        return <Glyph kind="start" className={s.startFlag} />;
      case 'wait':
      case 'hold':
        return <span className={cx(s.spacer, r.kind === 'hold' && s.spacerHold)} style={span(r.start, r.end)} />;
      case 'seq':
      case 'all':
        return <GroupMark />;
      case 'dist':
      case 'aim':
      case 'look':
      case 'turn':
      case 'roll':
      case 'strafe':
        return <MoveBar />;
      case 'end':
        return <EndMark r={r} viewEnd={viewEnd} viewStart={v0} clipEnd={clipEnd} sel={sel} />;
      case 'rate':
        return <Rate />;
      case 'osc':
        return <Osc />;
      default:
        return <Cue />;
    }
  })();

  function MoveBar() {
    const plain = !r.taper || mode !== 't1';
    const text = [r.op, r.subj, r.val].filter(Boolean).join(' ');
    // Zoomed past a bar's start, its label sticks to the window's left edge.
    const sticky = v0 > r.start ? ((v0 - r.start) / (r.end - r.start)) * 100 : 0;
    const pad = Math.max(sticky, r.taper && !plain && r.taper.dir === 'in' ? ((r.taper.z - r.start) / (r.end - r.start)) * 100 : 0);
    return (
      <span className={cx(s.move, ch(r.ch), sel && s.moveSel, r.error && s.moveErr, r.fuse && s[`fuse_${r.fuse}`])} style={span(r.start, r.end)}>
        {plain ? (
          <span className={s.moveRect} />
        ) : (
          <svg className={s.moveSvg} viewBox="0 0 100 100" preserveAspectRatio="none" aria-hidden>
            <polygon
              points={envelope((u) => {
                const t = r.start + u * (r.end - r.start);
                const k = Math.min(1, Math.max(0, (t - r.taper!.a) / (r.taper!.z - r.taper!.a)));
                return r.taper!.dir === 'out' ? 1 - k : k;
              }, 48)}
              vectorEffect="non-scaling-stroke"
            />
          </svg>
        )}
        <span className={s.moveText} style={{ paddingLeft: `calc(${pad}% + var(--space-3))` }}>{text}</span>
        {r.subj && <Glyph kind="subject" className={s.moveSubj} />}
        {(r.scale ?? []).map((k) => (
          <span key={k.label} className={s.scaleTick} style={{ left: `${((k.t - r.start) / (r.end - r.start)) * 100}%` }}>
            <span className={s.scaleLabel}>{k.label}</span>
          </span>
        ))}
        {sel && (
          <>
            <span className={cx(s.edge, s.edgeL)} />
            <span className={cx(s.edge, s.edgeR)} />
          </>
        )}
      </span>
    );
  }

  // The blend window's two hairlines, on the tapered moves and on their group row.
  const blendWin = mode === 't1' ? (r.taper ?? (r.join?.kind === 'blend' ? { a: r.join.a, z: r.join.z } : null)) : null;
  const hairs = blendWin && (
    <>
      <span className={cx(s.blendHair, s.c_dist)} style={at(blendWin.a)} />
      <span className={cx(s.blendHair, s.c_dist)} style={at(blendWin.z)} />
    </>
  );

  function Rate() {
    const [a, b] = r.rate!;
    const len = r.end - r.start;
    const pts = sample(0, 1, 24, (u) => 100 - 88 * (a + (b - a) * ss(u)), (u) => u * 100);
    return (
      <>
        <svg className={cx(s.rate, ch(r.ch))} style={span(r.start, r.end)} viewBox="0 0 100 100" preserveAspectRatio="none" aria-hidden>
          <polygon className={s.rateFill} points={`0,100 ${pts} 100,100`} />
          <polyline className={s.rateEdge} points={pts} vectorEffect="non-scaling-stroke" />
        </svg>
        <span className={cx(s.rateHead, ch(r.ch))} style={{ left: x(r.end), top: `calc(${100 - 88 * b}% - 0px)` }} />
        {r.holdTo > r.end && (
          <span className={cx(s.rateHold, ch(r.ch))} style={{ ...span(r.end, r.holdTo), top: `${100 - 88 * b}%` }} />
        )}
        {r.bg && <BgTag t={r.start} len={len} />}
      </>
    );
  }

  function Osc() {
    const len = r.end - r.start;
    const pts = sample(0, len, 120, (t) => 1 - 0.8 * Math.sin((2 * Math.PI * t) / r.period), (t) => t);
    return (
      <>
        <svg className={cx(s.osc, ch(r.ch))} style={span(r.start, r.end)} viewBox={`0 0 ${len} 2`} preserveAspectRatio="none" aria-hidden>
          <polyline points={pts} vectorEffect="non-scaling-stroke" />
        </svg>
        {r.bg && <BgTag t={r.start} len={len} />}
      </>
    );
  }

  function BgTag({ t }: { readonly t: number; readonly len: number }) {
    return (
      // Left of the mark when there is room, else inside it at its start (a fork at 0 s).
      <span className={s.bgTag} style={t / viewEnd > 0.07 ? { right: `calc(100% - ${x(t)} + var(--space-3))` } : { left: `calc(${x(t)} + var(--space-3))` }}>
        <Glyph kind="fork" className={s.bgIcon} />
        Background
      </span>
    );
  }

  function Cue() {
    const shape = r.kind === 'hide' || r.kind === 'show' ? s.cueHollow : r.kind === 'set' ? s.cueSquare : r.kind === 'focus' ? s.cueRing : s.cueDiamond;
    // A frame roll is not an opacity: its tail is a plain line, never an envelope.
    const envMode = r.kind !== 'frame' && (mode === 't1' || (r.id !== 'flowIn' && r.id !== 'galOut'));
    return (
      <>
        {r.over > 0 && envMode && <Envelope />}
        {r.over > 0 && !envMode && <span className={cx(s.tailLine, ch(r.ch))} style={span(r.start, r.start + r.over)} />}
        <span className={cx(s.cue, shape, ch(r.ch), sel && s.cueSel)} style={at(r.start)} />
      </>
    );
  }

  function Envelope() {
    const a = r.start;
    const z = a + r.over;
    const lv = (t: number) => r.from + (r.to - r.from) * ss((t - a) / r.over);
    // A fade cut off by End draws solid up to End and dashed for the unseen rest.
    const cut = r.warn ? Math.max(a, Math.min(z, clipEnd)) : z;
    const piece = (p: number, q: number, cls?: string) =>
      q > p && (
        <svg className={cx(s.env, ch(r.ch), cls)} style={span(p, q)} viewBox="0 0 100 100" preserveAspectRatio="none" aria-hidden>
          <polygon points={envelope((u) => lv(p + u * (q - p)), 32)} vectorEffect="non-scaling-stroke" />
        </svg>
      );
    return (
      <>
        {piece(a, cut)}
        {piece(cut, z, s.envCut)}
        {r.levelTo > z && r.to > 0 && <span className={cx(s.envHeld, ch(r.ch))} style={{ ...span(z, r.levelTo), '--h': r.to } as CSSProperties} />}
      </>
    );
  }

  // A blend chip fills its overlap window (icon + length); a stop / no-stop join is an instant,
  // so its chip centres on it with its name. The chip's tip names the join in full.
  function JoinChip() {
    const j = r.join!;
    const win = j.z > j.a;
    const meaning = j.kind === 'blend' ? 'Both moves run; weight passes across' : j.kind === 'nostop' ? 'Speed carries through' : 'Comes to rest, then goes';
    return (
      <StudioTip
        name={j.label}
        meaning={meaning}
        state="Click to edit the join"
        style={{ position: 'absolute', top: 0, bottom: 0, zIndex: 3, ...(win ? span(j.a, j.z) : at(j.a)) }}
      >
        <button
          type="button"
          className={cx(s.join, s.c_dist, joinSel && s.joinSel, win && s.joinWin)}
          style={{ left: 0, width: win ? '100%' : undefined }}
          aria-pressed={joinSel}
          aria-label={j.label}
        >
          <Glyph kind={`j${j.kind}`} className={s.joinIcon} />
          {win ? `${+(j.z - j.a).toFixed(1)} s` : j.label}
        </button>
      </StudioTip>
    );
  }

  function GroupMark() {
    const zero = r.start === r.end;
    if (zero) {
      return (
        <>
          {mode !== 't1' && r.id === 'cross' ? <LayerXfade /> : null}
          <span className={s.zeroGroup} style={at(r.start)} />
          <span className={s.zeroLabel} style={at(r.start)}>Together · 0 s</span>
        </>
      );
    }
    const lensRow = r.join?.kind === 'blend' && mode !== 't1';
    return (
      <>
        <span className={cx(s.bracket, s[`bracket_${r.kind}`], r.collapsed && s.bracketCollapsed, groupSel && s.bracketSel)} style={span(r.start, r.end)}>
          <span className={s.bracketLabel} style={v0 > r.start ? { left: `calc(${((v0 - r.start) / (r.end - r.start)) * 100}% + var(--space-4))` } : undefined}>
            {r.kind === 'seq' ? 'In order' : 'Together'}
          </span>
        </span>
        {r.collapsed &&
          r.kids.map((k, i) => (
            <span key={i} className={cx(s.kid, ch(k.ch))} style={{ ...span(k.a, k.z), top: `calc(55% + ${i} * var(--space-2))` }} />
          ))}
        {r.join && !lensRow && <JoinChip />}
        {lensRow && mode === 't2' && <Lens />}
        {lensRow && mode === 't3' && <ValueCurve />}
      </>
    );
  }

  // T2: both moves end to end on the group row, the overlap a lens of crossing weights.
  function Lens() {
    const j = r.join!;
    return (
      <>
        <span className={cx(s.lensBar, s.c_dist)} style={span(4, j.a)}>→ 300 Mpc</span>
        <span className={cx(s.lensBar, s.lensBarB, s.c_dist)} style={span(j.z, r.end)}>→ 950 Mpc</span>
        <span className={cx(s.lens, s.c_dist, joinSel && s.lensSel)} style={span(j.a, j.z)}>
          <svg viewBox="0 0 100 100" preserveAspectRatio="none" aria-hidden>
            <polygon className={s.lensA} points={`0,100 ${sample(0, 1, 24, (u) => 100 - 100 * (1 - ss(u)), (u) => u * 100)} 100,100`} />
            <polygon className={s.lensB} points={`0,100 ${sample(0, 1, 24, (u) => 100 - 100 * ss(u), (u) => u * 100)} 100,100`} />
            <polyline className={cx(s.lensLine, s.lensLineDash)} points={sample(0, 1, 24, (u) => 100 - 100 * (1 - ss(u)), (u) => u * 100)} vectorEffect="non-scaling-stroke" />
            <polyline className={s.lensLine} points={sample(0, 1, 24, (u) => 100 - 100 * ss(u), (u) => u * 100)} vectorEffect="non-scaling-stroke" />
          </svg>
          <span className={cx(s.lensGrip, s.lensGripL)} />
          <span className={cx(s.lensGrip, s.lensGripR)} />
        </span>
        <span className={s.lensLabel} style={at((j.a + j.z) / 2)}>Blend 1 s</span>
      </>
    );
  }

  // T3: the evaluated distance (log) across the group row; the join zone shaded.
  function ValueCurve() {
    const j = r.join!;
    const y = (t: number) => 92 - 84 * ((distanceAt(t, 'blend') - DIST_LO) / (DIST_HI - DIST_LO));
    return (
      <>
        <span className={cx(s.curveZone, s.c_dist, joinSel && s.curveZoneSel)} style={span(j.a, j.z)} />
        <svg className={cx(s.curve, s.c_dist)} style={span(r.start, r.end)} viewBox={`${r.start} 0 ${r.end - r.start} 100`} preserveAspectRatio="none" aria-hidden>
          <polyline points={sample(r.start, r.end, 140, y, (t) => t)} vectorEffect="non-scaling-stroke" />
        </svg>
        <span className={cx(s.curveTick, s.curveTickL)} style={{ right: `calc(100% - ${x(r.start)})`, top: '72%' }}>0.14</span>
        <span className={s.curveTick} style={{ left: x(9), top: '62%' }}>300</span>
        <span className={s.curveTick} style={{ left: x(r.end), top: '2%' }}>950 Mpc</span>
        <span className={s.lensLabel} style={at((j.a + j.z) / 2)}>Blend 1 s</span>
      </>
    );
  }

  // The flow ⇄ galaxies dissolve on its Together row, for t2 (lens) and t3 (curves).
  function LayerXfade() {
    const up = sample(0, 1, 24, (u) => 100 - 100 * ss(u), (u) => u * 100);
    const down = sample(0, 1, 24, (u) => 100 - 100 * (1 - ss(u)), (u) => u * 100);
    return (
      <>
        <span className={cx(s.lens, s.lensLayer, s.c_layers, mode === 't3' && s.lensCurve)} style={span(4, 7)}>
          <svg viewBox="0 0 100 100" preserveAspectRatio="none" aria-hidden>
            {mode === 't2' && <polygon className={s.lensA} points={`0,100 ${down} 100,100`} />}
            {mode === 't2' && <polygon className={s.lensB} points={`0,100 ${up} 100,100`} />}
            <polyline className={s.lensLine} points={up} vectorEffect="non-scaling-stroke" />
            <polyline className={cx(s.lensLine, s.lensLineDash)} points={down} vectorEffect="non-scaling-stroke" />
          </svg>
          {mode === 't2' && (
            <>
              <span className={cx(s.lensGrip, s.lensGripL)} />
              <span className={cx(s.lensGrip, s.lensGripR)} />
            </>
          )}
        </span>
        <span className={s.curveTick} style={{ left: `calc(${x(7)} + var(--space-2))`, top: '0%' }}>flow 100 %</span>
        <span className={s.curveTick} style={{ left: `calc(${x(7)} + var(--space-2))`, top: '62%' }}>galaxies 0 %</span>
      </>
    );
  }

  return (
    <div className={cx(s.track, v0 > 0 && s.trackClip)}>
      {bands}
      {hairs}
      {mark}
      {/* Zoomed: a step wholly outside the window leaves an edge tab with its range. */}
      {r.kind !== 'start' && Math.max(r.end, r.start + r.over) < v0 && (
        <span className={cx(s.offView, ch(r.ch))}>◂ {fmtRange(r.start, Math.max(r.end, r.start + r.over))}</span>
      )}
      {r.start > viewEnd && <span className={cx(s.offView, s.offViewR, ch(r.ch))}>{fmtRange(r.start, r.end)} ▸</span>}
      {r.dur === '∞' && <PerpetualCut r={r} clipEnd={clipEnd} viewEnd={viewEnd} />}
      {wrapAt !== undefined && r.kind !== 'end' && (
        <LoopGhost wrapAt={wrapAt} viewEnd={viewEnd}>
          {bands}
          {mark}
        </LoopGhost>
      )}
      {r.warn && <span className={s.cutTag} style={{ right: `calc(100% - ${x(clipEnd)} + var(--space-8))` }}>{`${+(r.start + r.over - clipEnd).toFixed(1)} s unseen`}</span>}
    </div>
  );
}

export default StudioDTrack;
