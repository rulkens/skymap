import Icon from '../../../components/Icon/Icon';
import { GLYPH_PATHS } from './glyphPaths';

type Props = { readonly kind: string; readonly size?: number };

// Bar-sized studio icons the app's set lacks, in its Icon frame (24-unit grid, round stroke).
function StudioIcon({ kind, size = 16 }: Props) {
  return <Icon size={size}>{GLYPH_PATHS[kind]}</Icon>;
}

export default StudioIcon;
