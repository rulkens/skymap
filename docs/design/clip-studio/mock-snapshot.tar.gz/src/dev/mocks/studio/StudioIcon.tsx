import type { ReactNode } from 'react';
import Icon from '../../../components/Icon/Icon';

type Props = { readonly kind: string; readonly size?: number };

// Studio icons the app's set lacks, drawn in its Icon frame (24-unit grid, round stroke).
const PATH: Record<string, ReactNode> = {
  loop: <path d="M17 3.5 20 6.5 17 9.5M4 11.5v-1a4 4 0 0 1 4-4h12M7 20.5l-3-3 3-3M20 12.5v1a4 4 0 0 1-4 4H4" />,
  undo: <path d="M9 13.5 4.5 9 9 4.5M4.5 9h10a5 5 0 0 1 0 10H11" />,
  redo: <path d="M15 13.5 19.5 9 15 4.5M19.5 9h-10a5 5 0 0 0 0 10H13" />,
  // picture-in-picture with a turn arrow: swap the main view and the inset
  swap: (
    <>
      <rect x="3" y="5" width="18" height="14" rx="2" />
      <g fill="currentColor" stroke="none">
        <rect x="12.5" y="11.5" width="6" height="5" rx="1" />
      </g>
      <path d="M6.5 13.5V10a2 2 0 0 1 2-2H11M9.5 6.5 11 8 9.5 9.5" />
    </>
  ),
  chevronDown: <path d="M7 10l5 5 5-5" />,
  keys: (
    <>
      <rect x="2.5" y="6" width="19" height="12" rx="2" />
      <path d="M6.5 10h.01M10 10h.01M14 10h.01M17.5 10h.01M8 14h8" />
    </>
  ),
  more: (
    <g fill="currentColor" stroke="none">
      <circle cx="6" cy="12" r="1.5" />
      <circle cx="12" cy="12" r="1.5" />
      <circle cx="18" cy="12" r="1.5" />
    </g>
  ),
  fit: <path d="M3 8V5h3M21 8V5h-3M3 16v3h3M21 16v3h-3M7 12h10M9.5 9.5 7 12l2.5 2.5M14.5 9.5 17 12l-2.5 2.5" />,
};

function StudioIcon({ kind, size = 16 }: Props) {
  return <Icon size={size}>{PATH[kind]}</Icon>;
}

export default StudioIcon;
