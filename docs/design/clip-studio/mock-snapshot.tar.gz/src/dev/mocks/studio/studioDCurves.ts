// Shape maths for the studio-d mock: smootherstep weights (the seq crossfade mix), the
// cosmicFlows In-order distance curve under each join kind, and SVG point strings.

export const ss = (u: number) => {
  const x = Math.min(1, Math.max(0, u));
  return x * x * x * (x * (6 * x - 15) + 10);
};
const inOut = (u: number) => {
  const x = Math.min(1, Math.max(0, u));
  return x < 0.5 ? 4 * x * x * x : 1 - (-2 * x + 2) ** 3 / 2;
};
const hermite = (p0: number, m0: number, p1: number, m1: number, u: number, dt: number) => {
  const x = Math.min(1, Math.max(0, u));
  const x2 = x * x;
  const x3 = x2 * x;
  return (2 * x3 - 3 * x2 + 1) * p0 + (x3 - 2 * x2 + x) * dt * m0 + (-2 * x3 + 3 * x2) * p1 + (x3 - x2) * dt * m1;
};

// log10 distance (Mpc): 0.14 at the start, 300 after the first pull, 950 after the second.
const A0 = Math.log10(0.14);
const A1 = Math.log10(300);
const B1 = Math.log10(950);
export const DIST_LO = A0;
export const DIST_HI = B1;

/** log10 distance at t for the In order block starting at 4 s, by join kind. */
export function distanceAt(t: number, kind: string) {
  if (kind === 'blend') {
    const a = A0 + (A1 - A0) * inOut((t - 4) / 4);
    const b = A1 + (B1 - A1) * inOut((t - 7) / 4);
    if (t <= 7) return a;
    if (t >= 8) return b;
    const w = ss(t - 7);
    return (1 - w) * a + w * b;
  }
  if (kind === 'nostop') {
    const vA = (A1 - A0) / 4;
    const vB = (B1 - A1) / 4;
    const v = (2 * vA * vB) / (vA + vB);
    return t <= 8 ? hermite(A0, 0, A1, v, (t - 4) / 4, 4) : hermite(A1, v, B1, 0, (t - 8) / 4, 4);
  }
  return t <= 8 ? A0 + (A1 - A0) * inOut((t - 4) / 4) : A1 + (B1 - A1) * inOut((t - 8) / 4);
}

/** "x,y x,y …" for a polyline sampled over [a, z]; f returns y already in viewBox units. */
export function sample(a: number, z: number, n: number, f: (t: number) => number, x: (t: number) => number) {
  const out: string[] = [];
  for (let i = 0; i <= n; i++) {
    const t = a + ((z - a) * i) / n;
    out.push(`${x(t).toFixed(3)},${f(t).toFixed(3)}`);
  }
  return out.join(' ');
}

/** Centre-symmetric envelope polygon (height = weight) over a 100×100 box. */
export function envelope(w: (u: number) => number, n = 32) {
  const top: string[] = [];
  const bot: string[] = [];
  for (let i = 0; i <= n; i++) {
    const u = i / n;
    const h = 46 * w(u);
    top.push(`${(u * 100).toFixed(2)},${(50 - h).toFixed(2)}`);
    bot.unshift(`${(u * 100).toFixed(2)},${(50 + h).toFixed(2)}`);
  }
  return [...top, ...bot].join(' ');
}
