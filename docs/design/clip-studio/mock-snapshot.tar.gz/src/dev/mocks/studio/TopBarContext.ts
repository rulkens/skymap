import { createContext } from 'react';

// Entry files pick the top bar's variant (and force tips / sheets open for shots) without
// a prop threaded through StudioD. TopBar's own props win over this.
const TopBarContext = createContext<{
  readonly variant?: 'a' | 'b' | 'c';
  readonly tips?: readonly string[];
  readonly keysOpen?: boolean;
  readonly menuOpen?: boolean;
}>({});

export default TopBarContext;
