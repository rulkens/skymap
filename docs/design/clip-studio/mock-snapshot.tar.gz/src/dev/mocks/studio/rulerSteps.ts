// Ruler ticks for any clip length: the major step is the first on the ladder that keeps labels
// ≥ 64 px apart on a track `px` CSS pixels wide (the 1728-wide mock's track is ~900 px), minor a
// fifth of it. Reproduces the shared states' hand-picked 2 s (24 s view) and 5 s (40 s view).
const LADDER = [0.1, 0.2, 0.5, 1, 2, 5, 10, 15, 30, 60, 120, 300];

export function rulerSteps(span: number, px = 900) {
  const major = LADDER.find((m) => (m * px) / span >= 64) ?? 600;
  return { major, minor: major / 5 };
}
