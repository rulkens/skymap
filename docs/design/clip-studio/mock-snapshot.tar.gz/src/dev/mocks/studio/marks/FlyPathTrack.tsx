import type { CSSProperties } from 'react';
import cx from 'classnames';
import Glyph from '../StudioDGlyph';
import StudioTip from '../StudioTip';
import { clipTime } from '../clipTime';
import { FLY, PACE, WPS, flyRows } from '../rows-famousFlythrough';
import sd from '../StudioD.module.css';
import s from './FlyPathTrack.module.css';

type Props = {
  readonly r: ReturnType<typeof flyRows>[number];
  readonly sel: boolean;
  readonly selWp: string;
  readonly viewEnd: number;
};

// The flyPath composite on a 2× profile lane: one bar owning the camera (three channel rules on
// top), the evaluated pace as its curve (ramp in, a dip at each waypoint's linger, settle), and a
// knot sitting on the curve where it reaches each waypoint. A waypoint row draws its leg + knot.
function FlyPathTrack({ r, sel, selWp, viewEnd }: Props) {
  const x = (t: number) => `${(t / viewEnd) * 100}%`;
  const span = (a: number, z: number): CSSProperties => ({ left: x(a), width: `${((z - a) / viewEnd) * 100}%` });
  const pace = (a: number, z: number, h: number) =>
    PACE.map((p, i) => [i * 0.2, p] as const)
      .filter(([t]) => t >= a - 1e-6 && t <= z + 1e-6)
      .map(([t, p]) => `${(((t - a) / (z - a)) * 100).toFixed(2)},${(h - Math.min(p, 1) * h).toFixed(2)}`)
      .join(' ');
  const knotKind = (i: number) => (i === WPS.length - 1 ? 'settle' : 'pass');
  const selIdx = WPS.findIndex((w) => `wp-${w.id}` === selWp);

  if (r.kind === 'fly') {
    const legA = selIdx > 0 ? WPS[selIdx - 1]!.at : 0;
    const paceAt = (t: number) => Math.min(1, PACE[Math.round(t / 0.2)] ?? 0);
    // Knot ids where they fit (≥ 3.2 s apart); the selected waypoint always keeps its label.
    const order = WPS.map((_, k) => k).sort((p, q) => Number(q === selIdx) - Number(p === selIdx) || p - q);
    const shown = new Set<number>();
    for (const k of order) if ([...shown].every((m) => Math.abs(WPS[m]!.at - WPS[k]!.at) >= 3.2)) shown.add(k);
    return (
      <div className={sd.track}>
        {selIdx >= 0 && <span className={s.legHi} style={span(legA, WPS[selIdx]!.at)} />}
        <span className={cx(s.bar, sel && s.barSel)} style={span(0, FLY.total)}>
          <span className={s.rules} aria-hidden>
            <span className={sd.c_dist} />
            <span className={sd.c_look} />
            <span className={sd.c_turn} />
          </span>
          <span className={s.lockTag}>
            <StudioTip name="Owns the camera" meaning="Distance, look-at, turn, tilt">
              <Glyph kind="lock" className={s.lock} />
            </StudioTip>
          </span>
          <svg className={s.pace} viewBox="0 0 100 100" preserveAspectRatio="none" aria-hidden>
            <polygon points={`0,100 ${pace(0, FLY.total, 100)} 100,100`} vectorEffect="non-scaling-stroke" />
            <polyline points={pace(0, FLY.total, 100)} vectorEffect="non-scaling-stroke" />
          </svg>
          {sel && (
            <>
              <span className={cx(sd.edge, sd.edgeL)} />
              <span className={cx(sd.edge, sd.edgeR)} />
            </>
          )}
        </span>
        {WPS.map((w, k) => (
          <span key={w.id}>
            <span className={cx(s.tick, k === selIdx && s.tickSel)} style={{ left: x(w.at), '--p': paceAt(w.at) } as CSSProperties} />
            <span
              className={cx(s.knot, s[`k_${knotKind(k)}`], k === selIdx && s.knotSel)}
              style={{ left: x(w.at), '--p': paceAt(w.at) } as CSSProperties}
              aria-label={w.name}
            />
            {shown.has(k) && (
              <span className={cx(s.kLabel, k === selIdx && s.kLabelSel, k === WPS.length - 1 && s.kLabelEnd)} style={{ left: x(w.at) }}>
                {w.id.toUpperCase()}
              </span>
            )}
          </span>
        ))}
      </div>
    );
  }

  const i = WPS.findIndex((w) => `wp-${w.id}` === r.id);
  if (i < 0) return undefined;
  const w = WPS[i]!;
  const a = i === 0 ? 0 : WPS[i - 1]!.at;
  return (
    <div className={sd.track}>
      <span className={sd.band} style={span(0, FLY.total)} aria-hidden />
      <span className={cx(s.leg, sel && s.legSel)} style={span(a, w.at)} />
      <span className={cx(s.knot, s.knotRow, s[`k_${knotKind(i)}`], sel && s.knotSel)} style={{ left: x(w.at) }}>
        {sel && <span className={s.grip} aria-label="Drag to pin this leg" />}
      </span>
      {sel && (
        <span className={s.knotTag} style={{ left: x(w.at) }}>
          {clipTime(FLY.total).at(w.at)}<span className={s.knotTagDim}> · drag to pin leg</span>
        </span>
      )}
    </div>
  );
}

export default FlyPathTrack;
