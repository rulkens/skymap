import type { CSSProperties, ReactNode } from 'react';
import { useState } from 'react';
import cx from 'classnames';
import { useDockCover } from './useDockCover';
import Button from '../../../components/common/Button/Button';
import Glyph from './StudioDGlyph';
import StudioTip from './StudioTip';
import Track from './StudioDTrack';
import Inspector from './StudioDInspector';
import Views from './StudioDViews';
import TopBar from './TopBar';
import { clipTime } from './clipTime';
import { CHANNELS, cosmicRows, deepRows, row } from './stepsD';
import './hideReal.css';
import s from './StudioD.module.css';

// `clip` swaps in another real clip (round-2 per-clip states); absent = Cosmic Flows / deep.
// `track` returning undefined falls back to the shared Track; `parentKinds` get a twisty.
type Props = {
  readonly state: string;
  readonly clip?: {
    readonly title: string;
    readonly rows: ReturnType<typeof cosmicRows>;
    readonly clipEnd: number;
    readonly viewEnd: number;
    readonly major: number;
    readonly minor: number;
    readonly t: number;
    readonly sel: string;
    readonly status?: string;
    readonly undo?: string;
    readonly parentKinds?: readonly string[];
    // Row ids drawn at 2× height (a composite's profile lane, e.g. a flyPath's pace curve).
    readonly tall?: readonly string[];
    // The Camera view at the playhead (labels off); the Edit view is the live scene behind.
    readonly inset: string;
    readonly track?: (r: ReturnType<typeof cosmicRows>[number], sel: boolean) => ReactNode;
    readonly inspector?: ReactNode;
    readonly legend?: ReactNode;
    // `loop: true` clips: End becomes the wrap, and past it the track ghosts the next cycle.
    readonly loop?: boolean;
    readonly height?: string;
    readonly tags?: ReactNode;
    readonly saveNote?: ReactNode;
    // Values depending on the sim date (◷); they save as body-frame literals.
    readonly dated?: number;
    // Zoomed in: the visible window starts at `viewStart` and `zoom` names the level (e.g. '4×');
    // the ruler then carries an overview strip of the window over the whole clip (`fitEnd`).
    readonly viewStart?: number;
    readonly zoom?: string;
    readonly fitEnd?: number;
    // Rows scrolled off the top; a thumb sized to the visible share shows when rows overflow.
    readonly scroll?: number;
  };
};

// Per-state knobs. `variant` picks the rows, `mode` the crossfade treatment (t1, the ruling).
const CFG: Record<string, Record<string, string | number | boolean>> = {
  overview: { sel: 'dolly2', view: 'tip', t: 7.4, status: 'unsaved' },
  playing: { sel: 'dolly2', view: 'playing', t: 9.6, playing: true, status: 'saved' },
  pip: { sel: 'dolly2', view: 'step', t: 7.4, status: 'unsaved' },
  detached: { sel: 'dolly2', view: 'step', t: 7.4, status: 'unsaved', detached: true },
  swapped: { sel: 'dolly1', view: 'free', t: 7.4, swapped: true, status: 'unsaved' },
  'cue-selected': { sel: 'black', view: 'cue', t: 18.6, status: 'saving' },
  'after-end': { sel: 'black', view: 'cue', t: 21.6, status: 'unsaved' },
  'group-selected': { sel: 'pull', view: 'group', t: 7.4, status: 'saved' },
  'join-selected': { joinSel: 'order', view: 'join', join: 'nostop', variant: 'nostop', t: 9.2, status: 'unsaved' },
  'start-selected': { sel: 'start', view: 'start', t: 0, status: 'failed' },
  'focus-ring': { sel: 'dolly2', focus: 'slow', view: 'step', t: 7.4, status: 'unsaved' },
  invalid: { sel: 'clash', view: 'invalid', variant: 'invalid', t: 6.2, status: 'invalid' },
  empty: { view: 'clip', variant: 'empty', t: 0, status: 'new' },
  deep: { sel: 'd250', view: 'deep', t: 22.6, status: 'unavailable', deep: true },
  'scrub-snap': { sel: 'dolly2', view: 'step', t: 8, snap: true, loop: true, status: 'unsaved' },
  'edge-drag': { sel: 'dolly2', view: 'step', t: 7.4, status: 'unsaved', drag: true },
  'unsaved-close': { sel: 'dolly2', view: 'step', t: 7.4, status: 'unsaved', tip: 'close' },
  'xfade-t1': { joinSel: 'order', view: 'join', t: 7.4, status: 'unsaved', mode: 't1' },
  'xfade-t2': { joinSel: 'order', view: 'join', t: 7.4, status: 'unsaved', mode: 't2' },
  'xfade-t3': { joinSel: 'order', view: 'join', t: 7.4, status: 'unsaved', mode: 't3' },
};

const inset = (name: string) => new URL(`./assets/insets/${name}.jpg`, import.meta.url).href;

function StudioD({ state, clip }: Props) {
  const ref = useDockCover();
  const [visRows, setVisRows] = useState(0);
  const c = CFG[state] ?? CFG.overview!;
  const deep = Boolean(c.deep);
  const empty = c.variant === 'empty';
  const clipEnd = clip ? clip.clipEnd : deep ? 35 : empty ? 0 : 20;
  const time = clipTime(clipEnd);
  const authored = clip ? clip.rows : deep ? deepRows() : cosmicRows(String(c.variant ?? 'blend'));
  // Every clip closes on an End row that mirrors Start: stop, or loop with its seam check.
  const base = authored.some((r) => r.kind === 'end')
    ? authored
    : [...authored, row('end', 0, 'end', 'End', '', 'stop', '–', clipEnd, clipEnd, { join: { kind: 'stop', a: 0, z: clipEnd, label: 'Stop' } })];
  // An edge drag moves the bar and every enclosing bracket live.
  const rows = c.drag
    ? base.map((r) => (r.id === 'dolly2' ? { ...r, end: 12, dur: '5 s' } : r.id === 'order' ? { ...r, end: 12, dur: '8 s', val: 'Distance ×2 · blend 1 s' } : r))
    : base;
  const dragRow = rows.findIndex((r) => r.id === 'dolly2');
  const viewEnd = clip ? clip.viewEnd : deep ? 40 : 24;
  const major = clip ? clip.major : deep ? 5 : 2;
  const minor = clip ? clip.minor : deep ? 1 : 0.4;
  const t = clip ? clip.t : Number(c.t);
  const mode = String(c.mode ?? 't1');
  const sel = clip ? clip.sel : String(c.sel ?? '');
  const joinSel = String(c.joinSel ?? '');
  const playing = Boolean(c.playing);
  const swapped = Boolean(c.swapped);
  const status = clip?.status ?? String(c.status);
  const scrollRows = clip?.scroll ?? (deep ? 3.5 : 0);
  const v0 = clip?.viewStart ?? 0;
  const frac = (v: number) => (v - v0) / (viewEnd - v0);
  const x = (v: number) => `${frac(v) * 100}%`;
  const after = t > clipEnd && !clip?.loop;

  const ancestors = rows.map((r, i) => {
    const out: typeof rows = [];
    for (let j = i - 1, d = r.depth; j >= 0 && d > 0; j--) {
      if (rows[j]!.depth === d - 1) {
        out.unshift(rows[j]!);
        d--;
      }
    }
    return out;
  });
  const notches = rows
    .filter((r) => r.kind !== 'seq' && r.kind !== 'all' && r.kind !== 'start' && r.kind !== 'end' && r.start <= clipEnd)
    .map((r) => ({ t: r.start, ch: r.ch, id: r.id }))
    .filter((n, i, a) => a.findIndex((m) => m.t === n.t && m.ch === n.ch) === i);
  const tall = (id: string) => (mode !== 't1' && (id === 'order' || id === 'cross')) || Boolean(clip?.tall?.includes(id));
  const defaultInset = after || empty ? 'cosmic-start' : deep ? 'far' : 'cosmic';

  return (
    <section
      ref={ref}
      className={s.dock}
      style={{ height: clip?.height ?? (deep ? '46%' : '56%') } as CSSProperties}
      aria-label="Clip studio"
    >
      <div className={s.grabber} role="separator" aria-orientation="horizontal" aria-label="Resize studio">
        <StudioTip name="Resize" meaning="Drag to share the screen with the views">
          <span className={s.grabPill} />
        </StudioTip>
      </div>
      <Views
        t={t}
        clipEnd={clipEnd || 20}
        swapped={swapped}
        detached={Boolean(c.detached)}
        route={!clip && !empty && !deep}
        inset={clip?.inset ?? inset(defaultInset)}
      />

      <TopBar
        title={clip?.title ?? (empty ? 'New clip' : deep ? 'Grand tour 08 — cosmic web' : 'Cosmic Flows')}
        handWritten={!empty}
        tags={clip?.tags}
        status={status}
        saveNote={clip?.saveNote ?? true}
        dated={clip?.dated}
        playing={playing}
        empty={empty}
        t={t}
        clipEnd={clipEnd}
        loop={Boolean(c.loop)}
        swapped={swapped}
        undoLabel={clip?.undo ?? (state === 'invalid' ? 'Undo add' : state === 'join-selected' ? 'Undo no stop' : 'Undo blend')}
        zoom={clip?.zoom}
        tips={c.tip ? [String(c.tip)] : undefined}
      />

      <div className={s.body}>
        <div className={s.list}>
          <div className={s.headRow}>
            <div className={s.headCell}>
              <span className={s.colStep}>
                <span className={s.headLabel}>Step</span>
                <StudioTip name="Add step" meaning="After the selected step" keys={['A']} className={s.addTip}>
                  <button type="button" className={cx(s.tbtn, s.addBtn)}>+ Add</button>
                </StudioTip>
              </span>
              <span className={s.headLabel}>Value</span>
              <StudioTip name="Duration" meaning="∞ runs until End cuts it" className={s.durHead}>
                <Glyph kind="clock" className={s.durGlyph} />
              </StudioTip>
              <span className={s.chans} aria-label="Channels">
                {CHANNELS.map((ch) => (
                  <StudioTip key={ch.key} name={ch.name} meaning="Steps that write this channel">
                    <Glyph kind={ch.key} className={cx(s.chanGlyph, s.chanHead, s[`c_${ch.key}`])} />
                  </StudioTip>
                ))}
              </span>
            </div>
            <div className={s.ruler}>
              {c.loop && (
                <span className={s.loopBand} style={{ left: x(7), width: `${frac(11) * 100 - frac(7) * 100}%` }}>
                  <span className={cx(s.loopGrip, s.loopGripL)} />
                  <span className={cx(s.loopGrip, s.loopGripR)} />
                </span>
              )}
              {clip?.zoom && clip.fitEnd && (
                <span className={s.zoomStrip} aria-label="Visible window">
                  <span className={s.zoomWin} style={{ left: `${(v0 / clip.fitEnd) * 100}%`, width: `${((viewEnd - v0) / clip.fitEnd) * 100}%` }} />
                  <span className={s.zoomEnd} style={{ left: `${(clipEnd / clip.fitEnd) * 100}%` }} />
                </span>
              )}
              {Array.from({ length: Math.round(viewEnd / minor) + 1 }, (_, i) => {
                const v = +(i * minor).toFixed(3);
                if (v < v0 - 1e-6) return null;
                const isMajor = Math.abs(v / major - Math.round(v / major)) < 1e-6;
                // The first visible label carries the unit, also when zoomed past 0.
                const first = v === 0 || (v0 > 0 && v - v0 < major - 1e-6);
                return (
                  <span key={i} className={cx(s.tick, isMajor && s.tickMajor)} style={{ left: x(v) }}>
                    {isMajor && (v < clipEnd - minor || empty || clipEnd > viewEnd) && v < viewEnd && <span className={s.tickLabel}>{time.tick(v, first)}</span>}
                  </span>
                );
              })}
              {notches.filter((n) => n.t >= v0 && n.t <= viewEnd).map((n) => (
                <span key={n.id} className={cx(s.notch, n.ch && s[`c_${n.ch}`], c.snap && n.t === 8 && s.notchLit)} style={{ left: x(n.t) }} />
              ))}
              {c.snap && <span className={cx(s.notch, s.notchLit)} style={{ left: x(8) }} />}
              {!empty && clipEnd <= viewEnd && (
                <>
                  <span className={cx(s.endFlag, clip?.loop && s.endFlagLoop)} style={{ left: x(clipEnd) }}>
                    {clip?.loop && <Glyph kind="loop" className={s.headIcon} />}
                    {clip?.loop ? 'Loop' : 'End'} {time.at(clipEnd)}
                  </span>
                  <span className={s.afterLabel}>{clip?.loop ? 'cycle 2' : 'after End · reverted'}</span>
                </>
              )}
              {!empty && (
                <span className={cx(s.head, c.snap && s.headSnap, after && s.headAfter)} style={{ left: x(t) }}>
                  {c.snap && <Glyph kind="magnet" className={s.headIcon} />}
                  {time.at(t)}
                </span>
              )}
              {c.snap && <span className={s.snapLabel} style={{ left: x(t) }}>Blend end</span>}
            </div>
          </div>

          <div className={s.scroller}>
            <div
              className={s.rowsInner}
              style={{ transform: `translateY(calc(${-scrollRows} * var(--row-h)))`, '--scroll': scrollRows } as CSSProperties}
            >
              {rows.map((r, i) => {
                const group = r.kind === 'seq' || r.kind === 'all';
                const parent = group || Boolean(clip?.parentKinds?.includes(r.kind));
                const isSel = r.id === sel;
                const active = playing && !group && r.kind !== 'end' && r.start <= t && t < Math.max(r.end, r.start + r.over, r.start + 0.01);
                const flagged = r.warn || r.error;
                return (
                  <div
                    key={r.id}
                    className={cx(
                      s.row,
                      isSel && s.rowSel,
                      r.id === joinSel && s.rowJoinSel,
                      r.error && s.rowErr,
                      active && s.rowActive,
                      tall(r.id) && s.rowTall,
                      r.id === c.focus && s.rowFocus,
                    )}
                    aria-selected={isSel}
                  >
                    <div className={s.cell} style={{ '--d': r.depth } as CSSProperties}>
                      {isSel && <Glyph kind="grip" className={s.grip} />}
                      {ancestors[i]!.map((a, k) => (
                        <span key={a.id} className={cx(s.rail, s[`rail_${a.kind}`])} style={{ '--k': k } as CSSProperties} aria-hidden />
                      ))}
                      <span className={s.colStep}>
                        <span className={s.twisty}>{parent && <Glyph kind={r.collapsed ? 'chevronRight' : 'chevronDown'} className={s.twistyG} />}</span>
                        <span className={cx(s.iconWrap, r.ch && s[`c_${r.ch}`], parent && s.iconGroup, r.bg && s.iconBg)}>
                          <Glyph kind={r.kind} className={s.icon} />
                        </span>
                        <span className={cx(s.name, parent && s.nameGroup)}>{r.name}</span>
                      </span>
                      <span className={s.value}>
                        <span className={s.op}>{r.op}</span>
                        {r.subj && (
                          <StudioTip name={`Subject ${r.subj}`} meaning="Looked up when the clip plays" className={s.subjTip}>
                            <span className={s.subj}>
                              <Glyph kind="subject" className={s.subjIcon} />
                              {r.subj}
                            </span>
                          </StudioTip>
                        )}
                        <span className={s.val}>{r.val}</span>
                        {r.sub && <span className={s.sub}> · {r.sub}</span>}
                        {r.frame && (
                          <StudioTip name={`${r.frame} frame`} meaning={`Read in ${r.frame}'s body frame`}>
                            <span className={s.frameChip}>
                              <Glyph kind="body" className={s.frameIcon} />
                              {r.frame}
                            </span>
                          </StudioTip>
                        )}
                        {r.dated && (
                          <StudioTip name="Sim date" meaning="Value depends on the sim date" state="Saves in Earth's frame">
                            <span className={s.dated}>
                              <Glyph kind="clock" className={s.datedIcon} />
                            </span>
                          </StudioTip>
                        )}
                      </span>
                      <span className={cx(s.dur, flagged && s.durWarn)}>
                        {time.dur(r.dur)}
                        {flagged && <Glyph kind="warn" className={s.durIcon} />}
                      </span>
                      <span className={s.chans}>
                        {CHANNELS.map((ch) => (
                          <span key={ch.key} className={s.chanSlot}>
                            {r.writes.includes(ch.key) && <Glyph kind={ch.key} className={cx(s.chanGlyph, s[`c_${ch.key}`], group && s.chanGroup)} />}
                          </span>
                        ))}
                      </span>
                    </div>
                    {(r.kind !== 'start' && r.kind !== 'end' && clip?.track?.(r, isSel)) || (
                      <Track
                        r={r}
                        ancestors={ancestors[i]!}
                        viewEnd={viewEnd}
                        clipEnd={clipEnd}
                        mode={mode}
                        sel={isSel}
                        joinSel={r.id === joinSel}
                        groupSel={sel === 'pull'}
                        wrapAt={clip?.loop ? clipEnd : undefined}
                        viewStart={v0}
                      />
                    )}
                  </div>
                );
              })}
              {/* The playhead line runs under chips and labels (they carry a backing) and over bars. */}
              {!empty && <span className={cx(s.playLine, c.snap && s.playLineSnap)} style={{ '--f': frac(t) } as CSSProperties} aria-hidden />}
            </div>
            {deep && <span className={s.scrollThumb} aria-hidden />}
            {clip?.scroll !== undefined && (
              <span
                ref={(el) => {
                  if (el?.parentElement) setVisRows(Math.floor(el.parentElement.clientHeight / 24));
                }}
                className={s.scrollThumbFit}
                style={{ top: `${(clip.scroll / rows.length) * 100}%`, height: `${(Math.min(visRows || rows.length, rows.length) / rows.length) * 100}%` }}
                aria-hidden
              />
            )}
            {empty && (
              <div className={s.empty}>
                <p className={s.emptyTitle}>No steps</p>
                <p className={s.emptyLine}>Steps play top to bottom, Start to End</p>
                <div className={s.emptyRow}>
                  <StudioTip name="Add camera move" keys={['A']}>
                    <Button variant="primary">+ Camera move</Button>
                  </StudioTip>
                  <Button>+ Scene change</Button>
                  <Button>
                    Copy example
                    <Glyph kind="chevronDown" className={s.btnCaret} />
                  </Button>
                </div>
              </div>
            )}
          </div>

          {!empty && (
            <div className={s.overlay} aria-hidden>
              <span className={cx(s.afterEnd, clip?.loop && s.afterLoop)} style={{ left: x(clipEnd), right: 0 }} />
              <span className={s.endLine} style={{ left: x(clipEnd) }} />
              {c.loop && <span className={s.loopZone} style={{ left: x(7), width: `${(frac(11) - frac(7)) * 100}%` }} />}
              {state === 'invalid' && (
                <>
                  <span className={s.clashZone} style={{ left: x(4), width: `${(frac(10) - frac(4)) * 100}%` }} />
                  <span className={s.clashLabel} style={{ left: x(4) }} role="alert">
                    <Glyph kind="warn" className={s.durIcon} />
                    Distance · 2 writers · 4–10 s
                  </span>
                </>
              )}
              {c.drag && (
                <>
                  <span className={s.dragGhost} style={{ left: x(11), top: `calc(${dragRow} * var(--row-h))` }} />
                  <span className={s.dragTag} style={{ left: x(12), top: `calc(${dragRow} * var(--row-h))` }}>
                    Duration 5.0 s <span className={s.dragDelta}>+1.0</span>
                  </span>
                </>
              )}
            </div>
          )}
        </div>
        {clip?.inspector ?? <Inspector view={String(c.view)} join={String(c.join ?? 'blend')} />}
      </div>

      <footer className={s.keys}>
        <span className={s.legend}>
          {CHANNELS.map((ch) => (
            <span key={ch.key} className={s.legendItem}>
              <Glyph kind={ch.key} className={cx(s.chanGlyph, s[`c_${ch.key}`])} />
              {ch.name}
            </span>
          ))}
        </span>
        <span className={s.legend}>
          <span className={s.legendItem}><span className={cx(s.lg, s.lgDiamond)} />cue</span>
          <span className={s.legendItem}><span className={cx(s.lg, s.lgHollow)} />show · hide</span>
          <span className={s.legendItem}><span className={cx(s.lg, s.lgEnv)} />fade</span>
          <span className={s.legendItem}><Glyph kind="jblend" className={s.lgIcon} />blend</span>
          <span className={s.legendItem}><Glyph kind="fork" className={s.lgIcon} />background</span>
          {clip?.legend}
        </span>
      </footer>
    </section>
  );
}

export default StudioD;
