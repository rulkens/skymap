import cx from 'classnames';
import Panel, { Head, Grid, Sec, Row, Wide, Num, Pick, Out, Seg, Chip, Btn, Actions } from './InspectorGrid';
import Glyph from './StudioDGlyph';
import { distanceAt, sample, DIST_LO, DIST_HI } from './studioDCurves';
import s from './StudioD.module.css';

type Props = { readonly view: string; readonly join?: string };

const JOINS = [
  ['stop', 'Stop', 'jstop'],
  ['nostop', 'No stop', 'jnostop'],
  ['blend', 'Blend', 'jblend'],
] as const;

function EaseCurve() {
  return (
    <svg className={s.easeMini} viewBox="0 0 24 14" aria-hidden>
      <path d="M1 13 C 11 13, 13 1, 23 1" />
    </svg>
  );
}

// Distance (log) through the In order block under each join kind; the chosen one bright.
function JoinCurve({ chosen }: { readonly chosen: string }) {
  const y = (k: string) => (t: number) => 54 - 48 * ((distanceAt(t, k) - DIST_LO) / (DIST_HI - DIST_LO));
  const xs = (t: number) => ((t - 4) / 8) * 200;
  return (
    <figure className={s.jCurve}>
      <svg viewBox="0 0 200 60" preserveAspectRatio="none" aria-hidden>
        {['stop', 'nostop', 'blend'].map((k) => (
          <polyline key={k} className={cx(s.jLine, k === chosen && s.jLineOn)} points={sample(4, 12, 96, y(k), xs)} vectorEffect="non-scaling-stroke" />
        ))}
        <line className={s.jMark} x1={xs(chosen === 'blend' ? 7 : 8)} x2={xs(chosen === 'blend' ? 7 : 8)} y1="0" y2="60" />
        {chosen === 'blend' && <line className={s.jMark} x1={xs(8)} x2={xs(8)} y1="0" y2="60" />}
      </svg>
      <figcaption className={s.jAxis}>
        <span>4 s</span>
        <span>distance · log</span>
        <span>12 s</span>
      </figcaption>
    </figure>
  );
}

function StudioDInspector({ view, join = 'blend' }: Props) {
  if (view === 'join') {
    const blend = join === 'blend';
    return (
      <Panel>
        <Head glyph={`j${join}`} ch="dist" where="In order · join 1/1" range={blend ? '7.0–8.0 s' : '8.0 s'} title="Distance → Distance" />
        <Grid>
          <Sec title="Join" />
          <Row label="Kind" tip="What the camera does between two moves on one channel" span>
            <Seg label="Join" options={JOINS} value={join} />
          </Row>
          {blend ? (
            <Row label="Blend" tip="Both moves run; the weight passes from the first to the second" unit="s" reset>
              <Num value="1.0" fill={0.25} />
            </Row>
          ) : (
            <Row label="Speed" tip="Velocity carried through the join instead of a stop">
              <Out>matched</Out>
            </Row>
          )}
          <Wide>
            <JoinCurve chosen={join} />
          </Wide>
          <Sec title="Moves" />
          <Row label="From" unit="4 s">
            <Glyph kind="dist" className={cx(s.miniIcon, s.c_dist)} />
            <span>→ 300 Mpc</span>
          </Row>
          <Row label="To" unit="4 s">
            <Glyph kind="dist" className={cx(s.miniIcon, s.c_dist)} />
            <span>→ 950 Mpc</span>
          </Row>
        </Grid>
      </Panel>
    );
  }
  if (view === 'cue') {
    return (
      <Panel>
        <Head glyph="layers" ch="layers" where="Top level · 18/18" range="20.0 s" title="Fade → 0 %" />
        <Grid>
          <Sec title="Layers" aside="4" />
          <Wide>
            {['Flow', 'Milky Way', 'Rings', 'Labels'].map((c) => (
              <span key={c} className={s.chip}>
                {c}
                <button type="button" className={s.chipX} aria-label={`Remove ${c}`}>×</button>
              </span>
            ))}
            <button type="button" className={s.chipAdd}>+ Layer</button>
          </Wide>
          <Sec title="Value" />
          <Row label="Opacity" unit="%" reset>
            <Num value="0" fill={0} />
          </Row>
          <Row label="Over" tip="Fade length; the step itself takes 0 s" unit="s" reset>
            <Num value="3.0" fill={0.3} />
          </Row>
          <Chip action="+ Hold 3 s">3 s past End · unseen</Chip>
        </Grid>
        <Actions />
      </Panel>
    );
  }
  if (view === 'group') {
    return (
      <Panel>
        <Head glyph="all" where="Top level · 12/18" range="4.0–15.0 s" title="Together · 11 s" />
        <Grid>
          <Row label="Kind" tip="In order: one after another · Together: all at once" span>
            <Seg label="Kind" options={[['seq', 'In order', 'seq'], ['all', 'Together', 'all']]} value="all" />
          </Row>
          <Row label="Runs" tip="Background: the next step starts at once; this one runs under it" span>
            <Seg label="Runs" options={[['wait', 'Awaited'], ['bg', 'Background', 'fork']]} value="wait" />
          </Row>
          <Sec title="Steps" aside="2" />
          <Row label="In order" unit="7 s">
            <Out>Distance ×2 · blend</Out>
          </Row>
          <Row label="Turn spd" unit="11 s">
            <Out>→ 1.4°/s</Out>
          </Row>
        </Grid>
        <Actions group />
      </Panel>
    );
  }
  if (view === 'start') {
    return (
      <Panel>
        <Head glyph="start" where="Start" range="0.0 s" title="Start · saved view" />
        <Grid>
          <Row label="From" tip="Saved: this exact pose · Live: wherever the viewer is" span>
            <Seg label="Start from" options={[['saved', 'Saved view'], ['live', 'Live view']]} value="saved" />
          </Row>
          <Sec title="Pose" />
          <Row label="Look-at" unit="Mpc">
            <Num value="0, −0.01, 0" />
          </Row>
          <Row label="Distance" unit="Mpc">
            <Num value="0.14" />
          </Row>
          <Row label="Turn" unit="°">
            <Num value="−100.0" />
          </Row>
          <Row label="Tilt" unit="°">
            <Num value="−20.6" />
          </Row>
          <Row label="Frame" tip="The axes turn and tilt are measured in">
            <Pick dim>ecliptic</Pick>
          </Row>
          <Wide>
            <Btn primary glyph="look" kbd="V">Use edit view</Btn>
          </Wide>
        </Grid>
      </Panel>
    );
  }
  if (view === 'invalid') {
    return (
      <Panel>
        <Head glyph="dist" ch="dist" where="Together · 2/3" range="4.0–10.0 s" title="Distance → 500 Mpc" />
        <Grid>
          <Chip tone="error" action="Run after">2 writers · 4–10 s</Chip>
          <Sec title="Value" />
          <Row label="Distance" unit="Mpc" reset>
            <Num value="500" fill={0.66} />
          </Row>
          <Sec title="Timing" />
          <Row label="Duration" unit="s" reset>
            <Num value="6.0" fill={0.3} />
          </Row>
          <Row label="Ease">
            <Pick dim>
              <EaseCurve />
              In-out
            </Pick>
          </Row>
        </Grid>
        <Actions />
      </Panel>
    );
  }
  if (view === 'clip') {
    return (
      <Panel label="Clip settings">
        <Head where="Clip" range="0.0 s" title="New clip" />
        <Grid>
          <Row label="Name">
            <input className={s.gridInput} defaultValue="New clip" aria-label="Clip name" />
          </Row>
          <Row label="Start" tip="Live: the clip begins wherever the viewer is" span>
            <Seg label="Start from" options={[['live', 'Live view'], ['saved', 'Saved view']]} value="live" />
          </Row>
          <Row label="Length" unit="s">
            <Out>0.0</Out>
          </Row>
        </Grid>
      </Panel>
    );
  }
  const deep = view === 'deep';
  const free = view === 'free';
  const playing = view === 'playing';
  const tipOpen = view === 'tip';
  return (
    <Panel>
      <Head
        glyph="dist"
        ch="dist"
        where={deep ? 'Together › In order › Together › In order · 1/2' : `Together › In order · ${free ? '1/2' : '2/2'}`}
        range={deep ? '17.0–21.0 s' : free ? '4.0–8.0 s' : '7.0–11.0 s'}
        title={deep ? 'Distance → 250 Mpc' : free ? 'Distance → 300 Mpc' : 'Distance → 950 Mpc'}
      />
      <Grid>
        <Sec title="Value" />
        <Row label="Distance" unit="Mpc" reset>
          <Num value={deep ? '250' : free ? '300' : '950'} fill={deep ? 0.55 : free ? 0.62 : 0.8} />
        </Row>
        {playing && (
          <Row label="Now" unit="Mpc">
            <Out>412 · 9.6 s</Out>
          </Row>
        )}
        <Wide>
          <Btn primary={free} glyph="look" kbd="V">Use edit view</Btn>
        </Wide>
        <Sec title="Timing" />
        <Row label="Starts" tip="Set by In order · after the blend" unit="s" tipOpen={tipOpen}>
          <Out>{deep ? '17.0' : free ? '4.0' : '7.0'}</Out>
        </Row>
        <Row label="Duration" unit="s" reset>
          <Num value="4.0" fill={0.2} />
        </Row>
        <Row label="Ease" tip="Speed ramp: slow start and end">
          <Pick dim>
            <EaseCurve />
            In-out
          </Pick>
        </Row>
        <Sec title={deep || free ? 'Join after' : 'Join before'} />
        <Row label={deep ? 'Stop' : 'Blend'} span>
          <button type="button" className={s.gridLink}>
            <Glyph kind={deep ? 'jstop' : 'jblend'} className={cx(s.miniIcon, s.c_dist)} />
            {deep ? '→ 400 Mpc' : free ? '→ 950 Mpc · 1 s' : '→ 300 Mpc · 1 s'}
            <span className={s.linkGo}>›</span>
          </button>
        </Row>
      </Grid>
      <Actions />
    </Panel>
  );
}

export default StudioDInspector;
