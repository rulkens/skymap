// Rows for the studio-d mock. Cosmic Flows is the real `cosmicFlows` clip with one edit: the
// inner In order lost its 3 s hold and blends its two pull-backs over 1 s (seq overlap).
// Deep is the real grand-tour cosmic-web beat with its dwell inlined, plus two wraps an author
// might make (hide + pull-back paired, the pull-back split in two), to reach depth 4.

export const CHANNELS = [
  { key: 'dist', name: 'Distance' },
  { key: 'look', name: 'Look-at' },
  { key: 'turn', name: 'Turn · tilt' },
  { key: 'layers', name: 'Layers' },
  { key: 'settings', name: 'Settings · focus' },
];

const D = {
  ch: '',
  sub: '',
  writes: [] as string[],
  bg: false,
  over: 0,
  from: 1,
  to: 1,
  levelTo: 0,
  rate: null as null | [number, number],
  holdTo: 0,
  taper: null as null | { dir: 'in' | 'out'; a: number; z: number },
  warn: false,
  error: false,
  collapsed: false,
  join: null as null | { kind: string; a: number; z: number; label: string },
  kids: [] as { ch: string; a: number; z: number }[],
  amp: 0,
  period: 0,
  subj: '',
  // Body frame a value is read in ('' = absolute), sim-date dependence, unit crossings on a bar.
  frame: '',
  dated: false,
  scale: [] as { t: number; label: string }[],
  // Matched join (No stop): the bar end that fuses with its neighbour on the next row.
  fuse: '',
};

export const row = (
  id: string,
  depth: number,
  kind: string,
  name: string,
  op: string,
  val: string,
  dur: string,
  start: number,
  end: number,
  more: Partial<typeof D> = {},
) => {
  const r = { id, depth, kind, name, op, val, dur, start, end, ...D, ...more };
  return { ...r, writes: r.writes.length ? r.writes : r.ch ? [r.ch] : [] };
};

export function cosmicRows(variant: string) {
  const nostop = variant === 'nostop';
  const d2a = nostop ? 8 : 7;
  const d2z = nostop ? 12 : 11;
  const rows = [
    row('start', 0, 'start', 'Start', '', variant === 'empty' ? 'live view' : 'saved view', '–', 0, 0, {
      writes: ['dist', 'look', 'turn'],
    }),
    row('wait', 0, 'wait', 'Wait', '', '', '2 s', 0, 2),
    row('hide', 0, 'hide', 'Hide', '', 'web density, filaments +1', '0 s', 2, 2, { ch: 'layers' }),
    row('mask', 0, 'fade', 'Fade', '→', '0 %', '0 s', 2, 2, { ch: 'layers', sub: 'flow', from: 1, to: 0 }),
    row('flowOn', 0, 'set', 'Set', '', 'flow on', '0 s', 2, 2, { ch: 'settings' }),
    row('bob', 0, 'osc', 'Bob tilt', '±', '5.2° /16 s', 'end', 2, 20, { ch: 'turn', bg: true, amp: 1, period: 16 }),
    row('spinUp', 0, 'rate', 'Turn speed', '→', '10°/s', '1.5 s', 2, 3.5, {
      ch: 'turn',
      bg: true,
      rate: [0, 1],
      holdTo: 4,
    }),
    row('hold1', 0, 'hold', 'Hold', '', '', '2 s', 2, 4),
    row('cross', 0, 'all', 'Together', '', 'Fade ×2 · flow ⇄ galaxies', '0 s', 4, 4, { writes: ['layers'] }),
    row('flowIn', 1, 'fade', 'Fade', '→', '100 %', '3 s', 4, 4, {
      ch: 'layers',
      sub: 'flow',
      over: 3,
      from: 0,
      to: 1,
      levelTo: 20,
    }),
    row('galOut', 1, 'fade', 'Fade', '→', '0 %', '3 s', 4, 4, { ch: 'layers', sub: 'galaxies', over: 3, from: 1, to: 0 }),
    row('pull', 0, 'all', 'Together', '', 'In order, Turn speed', '11 s', 4, 15, { writes: ['dist', 'turn'] }),
    row('order', 1, 'seq', 'In order', '', `Distance ×2 · ${nostop ? 'no stop' : 'blend 1 s'}`, nostop ? '8 s' : '7 s', 4, d2z, {
      writes: ['dist'],
      join: nostop ? { kind: 'nostop', a: 8, z: 8, label: 'No stop' } : { kind: 'blend', a: 7, z: 8, label: 'Blend 1 s' },
    }),
    row('dolly1', 2, 'dist', 'Distance', '→', '300 Mpc', '4 s', 4, 8, {
      ch: 'dist',
      taper: nostop ? null : { dir: 'out', a: 7, z: 8 },
      fuse: nostop ? 'out' : '',
    }),
    row('dolly2', 2, 'dist', 'Distance', '→', '950 Mpc', '4 s', d2a, d2z, {
      ch: 'dist',
      taper: nostop ? null : { dir: 'in', a: 7, z: 8 },
      fuse: nostop ? 'in' : '',
    }),
    row('slow', 1, 'rate', 'Turn speed', '→', '1.4°/s', '11 s', 4, 15, { ch: 'turn', rate: [1, 0.14], holdTo: 20 }),
    row('hold3', 0, 'hold', 'Hold', '', '', '5 s', 15, 20),
    row('black', 0, 'fade', 'Fade', '→', '0 %', '3 s', 20, 20, {
      ch: 'layers',
      sub: 'flow, Milky Way +2',
      over: 3,
      from: 1,
      to: 0,
      warn: true,
    }),
  ];
  if (variant === 'empty') return rows.slice(0, 1);
  if (variant === 'invalid') {
    const clash = row('clash', 1, 'dist', 'Distance', '→', '500 Mpc', '6 s', 4, 10, { ch: 'dist', error: true });
    const i = rows.findIndex((r) => r.id === 'slow');
    return [...rows.slice(0, i), clash, ...rows.slice(i)].map((r) =>
      r.id === 'order' || r.id === 'dolly1' || r.id === 'dolly2' ? { ...r, error: r.id !== 'order' } : r,
    );
  }
  return rows;
}

export function deepRows() {
  return [
    row('start', 0, 'start', 'Start', '', 'live view · pinned', '–', 0, 0, { writes: ['dist', 'look', 'turn'] }),
    row('focusOnly', 0, 'set', 'Set', '', 'labels focused only', '0 s', 0, 0, { ch: 'settings' }),
    row('hideRings', 0, 'hide', 'Hide', '', 'cluster rings', '1 s', 0, 0, { ch: 'layers', over: 1, from: 1, to: 0 }),
    row('showSc', 0, 'show', 'Show', '', 'supercluster rings', '2 s', 0, 0, { ch: 'layers', over: 2, from: 0, to: 1, levelTo: 13 }),
    row('aim', 0, 'aim', 'Aim', '→', 'Coma Supercluster', '3 s', 0, 3, { ch: 'turn' }),
    row('focusComa', 0, 'focus', 'Focus', '', 'Coma Supercluster', '0 s', 3, 3, { ch: 'settings' }),
    row('hold', 0, 'hold', 'Hold', '', '', '1 s', 3, 4),
    row('density', 0, 'show', 'Show', '', 'web density', '9 s', 4, 4, { ch: 'layers', over: 9, from: 0, to: 1, levelTo: 35 }),
    row('dive', 0, 'all', 'Together', '', 'Look-at, Distance → Coma Supercluster', '9 s', 4, 13, {
      writes: ['look', 'dist'],
      collapsed: true,
      kids: [
        { ch: 'look', a: 4, z: 13 },
        { ch: 'dist', a: 4, z: 13 },
      ],
    }),
    row('dwell', 0, 'all', 'Together', '', 'Together, In order', '22 s', 13, 35, { writes: ['turn', 'settings', 'layers', 'dist'] }),
    row('drift', 1, 'all', 'Together', '', 'Turn, Bob tilt', '22 s', 13, 35, {
      writes: ['turn'],
      collapsed: true,
      kids: [
        { ch: 'turn', a: 13, z: 35 },
        { ch: 'turn', a: 13, z: 35 },
      ],
    }),
    row('pullback', 1, 'seq', 'In order', '', 'Wait, Focus +1', '12 s', 13, 25, { writes: ['settings', 'layers', 'dist'] }),
    row('wait4', 2, 'wait', 'Wait', '', '', '4 s', 13, 17),
    row('defocus', 2, 'focus', 'Focus', '', 'none', '0 s', 17, 17, { ch: 'settings' }),
    row('strip', 2, 'all', 'Together', '', 'Hide, In order', '8 s', 17, 25, { writes: ['layers', 'dist'] }),
    row('hideSurvey', 3, 'hide', 'Hide', '', 'galaxies · SDSS, 2MRS +1', '8 s', 17, 17, { ch: 'layers', over: 8, from: 1, to: 0 }),
    row('steps', 3, 'seq', 'In order', '', 'Distance ×2 · stop', '8 s', 17, 25, {
      writes: ['dist'],
      join: { kind: 'stop', a: 21, z: 21, label: 'Stop' },
    }),
    row('d250', 4, 'dist', 'Distance', '→', '250 Mpc', '4 s', 17, 21, { ch: 'dist' }),
    row('d400', 4, 'dist', 'Distance', '→', '400 Mpc', '4 s', 21, 25, { ch: 'dist' }),
  ];
}
