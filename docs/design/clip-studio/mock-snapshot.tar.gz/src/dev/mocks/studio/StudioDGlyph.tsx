import type { ReactNode } from 'react';

type Props = { readonly kind: string; readonly className?: string };

// One 16-unit stroke set: step types, group kinds, channels, join speed profiles, transport.
const ICON: Record<string, ReactNode> = {
  start: <path d="M5 3l8 5-8 5z" />,
  wait: <path d="M4 2h8M4 14h8M5 2c0 4 6 4 6 6s-6 2-6 6M11 2c0 4-6 4-6 6" />,
  hold: <path d="M5.5 3v10M10.5 3v10" />,
  dist: <path d="M8 1.5v13M4.5 5L8 1.5 11.5 5M4.5 11L8 14.5 11.5 11" />,
  look: <path d="M8 1v4M8 11v4M1 8h4M11 8h4M8 5.5a2.5 2.5 0 1 1 0 5a2.5 2.5 0 1 1 0-5" />,
  aim: <path d="M2 8h8M7 4.5L10.5 8 7 11.5M13.5 2.5v11" />,
  turn: <path d="M13 8a5 5 0 1 1-1.5-3.5M13 2v3h-3" />,
  rate: <path d="M2 13.5L13 4M13 4H8.5M13 4v4.5" />,
  osc: <path d="M1 8c1.8-5 3.6-5 5.4 0s3.6 5 5.4 0 2.2-3 3.2-3" />,
  hide: <path d="M1 8s3-5 7-5 7 5 7 5-3 5-7 5-7-5-7-5zM2.5 13.5l11-11" />,
  show: <path d="M1 8s3-5 7-5 7 5 7 5-3 5-7 5-7-5-7-5zM8 6a2 2 0 1 1 0 4a2 2 0 1 1 0-4" />,
  fade: <path d="M8 2a6 6 0 1 0 0 12zM8 2a6 6 0 0 1 0 12" />,
  set: <path d="M2 4h7M12 4h2M2 12h2M7 12h7M10.5 2v4M5.5 10v4" />,
  focus: <path d="M2 5.5V2h3.5M10.5 2H14v3.5M14 10.5V14h-3.5M5.5 14H2v-3.5M8 7v2" />,
  seq: <path d="M1.5 3.5h5M5 8h5M8.5 12.5h6" />,
  all: <path d="M2 2v12M4.5 4h9M4.5 8h9M4.5 12h9" />,
  fork: <path d="M4 2v12M4 9c0-4 8-3 8-7" />,
  layers: <path d="M1.5 6L8 2.5 14.5 6 8 9.5zM1.5 10L8 13.5 14.5 10" />,
  settings: <path d="M2 4h7M12 4h2M2 12h2M7 12h7M10.5 2v4M5.5 10v4" />,
  jstop: <path d="M1 13Q4 3 7.5 13M8.5 13Q12 3 15 13" />,
  jnostop: <path d="M1 13Q4 2 8 7Q12 2 15 13" />,
  jblend: <path d="M1 4C6 4 10 12 15 12M1 12C6 12 10 4 15 4" />,
  end: <path d="M3.5 2v12M3.5 2.5h9l-2.5 3 2.5 3h-9" />,
  loop: <path d="M3 9a5 5 0 0 0 9 2M13 7a5 5 0 0 0-9-2M3 2v3h3M13 14v-3h-3" />,
  magnet: <path d="M4 2v6a4 4 0 0 0 8 0V2M4 5h2M10 5h2" />,
  undo: <path d="M5 4L2 7l3 3M2 7h8a4 4 0 0 1 0 8H7" />,
  redo: <path d="M11 4l3 3-3 3M14 7H6a4 4 0 0 0 0 8h3" />,
  warn: <path d="M8 2l6.5 12h-13zM8 6.5v3.5M8 12v.5" />,
  grip: <path d="M6 3v10M10 3v10" />,
  // A named subject (FocusId): a target ring with a centre dot, resolved at play time.
  subject: <path d="M8 2.5a5.5 5.5 0 1 1 0 11a5.5 5.5 0 1 1 0-11M8 7a1 1 0 1 1 0 2a1 1 0 1 1 0-2" />,
  strafe: <path d="M2 8h12M5 5L2 8l3 3M11 5l3 3-3 3M8 3v2M8 11v2" />,
  frame: <path d="M2 11.5h12M4.5 6.5l7-3M8 11.5V8" />,
  roll: <path d="M3 11a5.5 5.5 0 0 1 10 0M13 11l-.5-3M13 11l-3 .2M8 8v6" />,
  clock: <path d="M8 2a6 6 0 1 1 0 12a6 6 0 1 1 0-12M8 4.5V8l2.5 1.5" />,
  body: <path d="M8 2a6 6 0 1 1 0 12a6 6 0 1 1 0-12M2 8h12M8 2c-2.5 3-2.5 9 0 12M8 2c2.5 3 2.5 9 0 12" />,
  fly: <path d="M1.5 13c3-7 6-1 9-6l1-2M9 4.5l3-.5.2 3M3 14a1 1 0 1 1 0-.1" />,
  pass: <path d="M10.5 3a2.5 2.5 0 1 1 0 5a2.5 2.5 0 1 1 0-5M1.5 14.5C3 9 6 9.5 8 11s4 2.5 6.5 1" />,
  settle: <path d="M8 2.5a5.5 5.5 0 1 1 0 11a5.5 5.5 0 1 1 0-11M8 6.5a1.5 1.5 0 1 1 0 3a1.5 1.5 0 1 1 0-3" />,
  point: <path d="M5 5h6v6H5zM8 1v3M8 12v3M1 8h3M12 8h3" />,
  lock: <path d="M4 7.5h8v6.5H4zM5.5 7.5V5a2.5 2.5 0 0 1 5 0v2.5" />,
  pin: <path d="M8 9.5V15M5 2h6l-1 4 2 3.5H4L6 6z" />,
  swap: <path d="M2 5h11M10 2l3 3-3 3M14 11H3M6 8l-3 3 3 3" />,
  edit: <path d="M1.5 4.5l6.5-3 6.5 3v7l-6.5 3-6.5-3zM1.5 4.5L8 8l6.5-3.5M8 8v6.5" />,
  camera: <path d="M1.5 4.5h9v7h-9zM10.5 7l4-2.5v7l-4-2.5" />,
};

function StudioDGlyph({ kind, className }: Props) {
  return (
    <svg className={className} viewBox="0 0 16 16" aria-hidden>
      {ICON[kind]}
    </svg>
  );
}

export default StudioDGlyph;
