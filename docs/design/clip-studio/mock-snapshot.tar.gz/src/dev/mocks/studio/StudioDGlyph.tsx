import type { ReactNode } from 'react';
import cx from 'classnames';
import Icon from '../../../components/Icon/Icon';
import LayersIcon from '../../../components/icons/LayersIcon/LayersIcon';
import EyeIcon from '../../../components/icons/EyeIcon/EyeIcon';
import AlertIcon from '../../../components/icons/AlertIcon/AlertIcon';
import TimeIcon from '../../../components/icons/TimeIcon/TimeIcon';
import RollIcon from '../../../components/icons/RollIcon/RollIcon';
import SlidersIcon from '../../../components/icons/SlidersIcon/SlidersIcon';
import PlayIcon from '../../../components/icons/PlayIcon/PlayIcon';
import OrbitIcon from '../../../components/icons/OrbitIcon/OrbitIcon';
import ClipIcon from '../../../components/icons/ClipIcon/ClipIcon';
import ExternalLinkIcon from '../../../components/icons/ExternalLinkIcon/ExternalLinkIcon';
import { GLYPH_PATHS } from './glyphPaths';
import g from './StudioDGlyph.module.css';

// `size` is the drawn px, so the Icon frame's stroke keeps the set's one weight; the caller's
// class sizes the box and sets `stroke` (the colour), which the frame's <g> inherits.
type Props = { readonly kind: string; readonly className?: string; readonly size?: number };

const APP: Record<string, (size: number) => ReactNode> = {
  layers: (n) => <LayersIcon size={n} />,
  show: (n) => <EyeIcon size={n} />,
  hide: (n) => <EyeIcon size={n} struck />,
  warn: (n) => <AlertIcon size={n} />,
  clock: (n) => <TimeIcon size={n} />,
  roll: (n) => <RollIcon size={n} />,
  settings: (n) => <SlidersIcon size={n} />,
  set: (n) => <SlidersIcon size={n} />,
  start: (n) => <PlayIcon size={n} />,
  turn: (n) => <OrbitIcon size={n} />,
  camera: (n) => <ClipIcon size={n} />,
  detach: (n) => <ExternalLinkIcon size={n} />,
};

function StudioDGlyph({ kind, className, size = 12 }: Props) {
  return (
    <span className={cx(g.glyph, className)} aria-hidden>
      {APP[kind]?.(size) ?? <Icon size={size}>{GLYPH_PATHS[kind]}</Icon>}
    </span>
  );
}

export default StudioDGlyph;
