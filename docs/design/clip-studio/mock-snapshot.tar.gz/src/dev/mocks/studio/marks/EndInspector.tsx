import Panel, { Head, Grid, Sec, Row, Out, Seg, Wide, Btn } from '../InspectorGrid';

type Props = {
  readonly loop: boolean;
  readonly end: string;
  readonly seam: readonly (readonly [string, string, string, string, string, string])[];
};

// The End row: the clip-level `loop` flag (stop / loop) and the seam check, pose(End) against
// pose(0 s) per channel, value and speed. The compiler does not verify a seam; the studio shows it.
function EndInspector({ loop, end, seam }: Props) {
  const ok = seam.filter((r) => r[5] === '✓').length;
  return (
    <Panel label="End settings">
      <Head glyph={loop ? 'loop' : 'end'} where="Clip" range={end} title={loop ? 'End · loop' : 'End · stop'} />
      <Grid>
        <Sec title="At End" />
        <Row label="Then" tip="Loop rewinds to 0 s until Stop or Close" reset={loop}>
          <Seg label="At End" value={loop ? 'loop' : 'stop'} options={[['stop', 'stop', 'end'], ['loop', 'loop', 'loop']]} />
        </Row>
        <Sec title="Seam" aside={`${end} → 0 s · ✓ ${ok}/${seam.length}`} />
        {seam.map(([, name, a, b, unit, mark]) => (
          <Row key={name} label={name} unit={unit}>
            <Out>
              {a} → {b} {mark}
            </Out>
          </Row>
        ))}
        <Wide>
          <Btn kbd="⇧L" glyph="loop">Preview seam ± 3 s</Btn>
        </Wide>
      </Grid>
    </Panel>
  );
}

export default EndInspector;
