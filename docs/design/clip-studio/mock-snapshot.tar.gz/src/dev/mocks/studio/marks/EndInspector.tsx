import Panel, { Head, Grid, Sec, Row, Out, Seg, Wide, Btn } from '../InspectorGrid';

type Props = {
  readonly loop: boolean;
  readonly end: string;
  readonly start?: string;
  readonly seam: readonly (readonly [string, string, string, string, string, string])[];
};

// The End row: the clip-level `loop` flag (stop / loop) and the seam check, pose(End) against
// pose(0 s) per channel, value and speed. The compiler does not verify a seam; the studio shows it.
// The naming table: a space before units, none before degrees (`63°`, `1.4°/s`).
const u = (unit: string) => (unit ? (unit.startsWith('°') ? unit : ` ${unit}`) : '');

function EndInspector({ loop, end, start = '0:00.0', seam }: Props) {
  const ok = seam.filter((r) => r[5] === '✓').length;
  return (
    <Panel label="End settings">
      <Head glyph={loop ? 'loop' : 'end'} where="Clip" range={end} title={loop ? 'End · loop' : 'End · stop'} />
      <Grid>
        <Sec title="At End" />
        <Row label="Then" tip="Loop rewinds to the start" reset={loop}>
          <Seg label="At End" value={loop ? 'loop' : 'stop'} options={[['stop', 'stop', 'end'], ['loop', 'loop', 'loop']]} />
        </Row>
        {loop && <Sec title="Seam" aside={`${end} → ${start} · ✓ ${ok}/${seam.length}`} />}
        {loop && seam.map(([, name, a, b, unit, mark]) => (
          <Row key={name} label={name}>
            <Out>
              {a}{u(unit)} → {b}{u(unit)}
              {mark !== '✓' && <b> {mark}</b>}
            </Out>
          </Row>
        ))}
        {loop && (
          <Wide>
            <Btn kbd="⇧L" glyph="loop" meaning="Plays 3 s either side of the wrap">Preview seam</Btn>
          </Wide>
        )}
      </Grid>
    </Panel>
  );
}

export default EndInspector;
