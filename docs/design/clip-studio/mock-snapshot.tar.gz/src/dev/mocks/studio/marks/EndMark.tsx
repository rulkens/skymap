import Glyph from '../StudioDGlyph';
import s from './EndMark.module.css';

type Props = {
  readonly r: { readonly start: number; readonly join: null | { readonly kind: string } };
  readonly viewEnd: number;
  readonly sel: boolean;
};

const clock = (t: number) => (t >= 60 ? `${Math.floor(t / 60)}:${String(Math.round(t % 60)).padStart(2, '0')}` : `${t} s`);

// The End row's mark. Stop: a stop cap on End. Loop: a return line from End back to 0 s, so the
// wrap reads as one more join (End → Start) with its seam check beside it.
function EndMark({ r, viewEnd, sel }: Props) {
  const x = (t: number) => `${(t / viewEnd) * 100}%`;
  const end = r.start;
  if (r.join?.kind !== 'loop') {
    return <span className={s.stop} data-sel={sel} style={{ left: x(end) }} aria-label={`Stop at ${clock(end)}`} />;
  }
  return (
    <>
      <span className={s.wrap} data-sel={sel} style={{ left: x(0), width: x(end) }} aria-hidden>
        <span className={s.arrow} />
      </span>
      <span className={s.wrapLabel} style={{ left: `calc(${x(end)} / 2)` }}>
        <Glyph kind="loop" className={s.icon} />
        {clock(end)} → 0 s
      </span>
      <span className={s.loopCap} data-sel={sel} style={{ left: x(end) }} aria-hidden>
        <Glyph kind="loop" className={s.icon} />
      </span>
    </>
  );
}

export default EndMark;
