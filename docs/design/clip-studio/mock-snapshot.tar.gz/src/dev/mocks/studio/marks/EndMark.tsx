import Glyph from '../StudioDGlyph';
import { clipTime } from '../clipTime';
import s from './EndMark.module.css';

type Props = {
  readonly r: { readonly start: number; readonly join: null | { readonly kind: string } };
  readonly viewEnd: number;
  readonly viewStart?: number;
  readonly clipEnd: number;
  readonly sel: boolean;
};

// The End row's mark, mirroring Start's. Stop: a stop cap on End. Loop: a return line from End
// back to 0 s, so the wrap reads as one more join (End → Start) with its seam check beside it.
function EndMark({ r, viewEnd, viewStart = 0, clipEnd, sel }: Props) {
  const time = clipTime(clipEnd);
  const x = (t: number) => `${((t - viewStart) / (viewEnd - viewStart)) * 100}%`;
  const end = r.start;
  if (end > viewEnd) return null;
  if (r.join?.kind !== 'loop') {
    return <span className={s.stop} data-sel={sel} style={{ left: x(end) }} aria-label={`Stop at ${time.at(end)}`} />;
  }
  return (
    <>
      <span className={s.wrap} data-sel={sel} style={{ left: x(0), width: x(end) }} aria-hidden>
        <span className={s.arrow} />
      </span>
      <span className={s.wrapLabel} style={{ left: `calc(${x(end)} / 2)` }}>
        <Glyph kind="loop" className={s.icon} />
        {time.at(end)} → {time.at(0)}
      </span>
      <span className={s.loopCap} data-sel={sel} style={{ left: x(end) }} aria-hidden>
        <Glyph kind="loop" className={s.icon} />
      </span>
    </>
  );
}

export default EndMark;
