import type { ReactNode } from 'react';
import cx from 'classnames';
import CompactInfoTip from '../../../components/common/CompactInfoTip/CompactInfoTip';
import Glyph from './StudioDGlyph';
import g from './InspectorGrid.module.css';

// Shared inspector shell for every studio-d inspector: a dense label | control | unit | reset
// grid. Meaning rides subtle channels: dotted labels open a one-line tip, defaults are dim and
// dashed, authored values are bright with a ↺ reset, units are suffixes, warnings are one-line chips.

type Props = { readonly label?: string; readonly children: ReactNode };

/** The inspector panel: header, then the grid, then the action row. */
function InspectorGrid({ label = 'Step settings', children }: Props) {
  return (
    <aside className={g.panel} aria-label={label}>
      {children}
    </aside>
  );
}

/** Where the step sits (path · index) and its time range; the title names step + value once. */
export function Head({ glyph, ch, where, range, title }: { readonly glyph?: string; readonly ch?: string; readonly where: string; readonly range?: string; readonly title: string }) {
  return (
    <header className={g.head}>
      <p className={g.where}>
        {glyph && <Glyph kind={glyph} className={cx(g.whereIcon, ch && g[`c_${ch}`])} />}
        <span className={g.whereText}>{where}</span>
        {range && <span className={g.range}>{range}</span>}
      </p>
      <h2 className={g.title}>{title}</h2>
    </header>
  );
}

export function Grid({ children }: { readonly children: ReactNode }) {
  return <div className={g.grid}>{children}</div>;
}

export function Sec({ title, aside }: { readonly title: string; readonly aside?: ReactNode }) {
  return (
    <p className={g.sec}>
      <span>{title}</span>
      {aside && <span className={g.secAside}>{aside}</span>}
    </p>
  );
}

/** One property. `tip` dots the label and opens a one-line tip on hover / focus. */
export function Row({
  label,
  tip,
  tipOpen,
  unit,
  reset,
  children,
}: {
  readonly label: string;
  readonly tip?: string;
  readonly tipOpen?: boolean;
  readonly unit?: string;
  readonly reset?: boolean;
  readonly children: ReactNode;
}) {
  return (
    <>
      <span className={g.lab}>
        {tip ? (
          <span className={cx(g.tipWrap, tipOpen && g.tipOpen)}>
            <CompactInfoTip label={tip} align="start">
              <span className={g.tipLabel} tabIndex={0}>
                {label}
              </span>
            </CompactInfoTip>
          </span>
        ) : (
          label
        )}
      </span>
      <span className={g.ctl}>{children}</span>
      <span className={g.unit}>{unit}</span>
      <span className={g.resetCell}>
        {reset && (
          <button type="button" className={g.reset} aria-label={`Reset ${label} to default`}>
            ↺
          </button>
        )}
      </span>
    </>
  );
}

/** A full-width grid line (chips, a curve, a button row). */
export function Wide({ children }: { readonly children: ReactNode }) {
  return <div className={g.wide}>{children}</div>;
}

/** Number field with a thin fill bar (drag to scrub, click to type); `dim` = the default. */
export function Num({ value, fill, dim }: { readonly value: string; readonly fill?: number; readonly dim?: boolean }) {
  return (
    <span className={cx(g.num, dim && g.isDefault)} role="spinbutton" tabIndex={0} aria-valuetext={value}>
      {value}
      {fill !== undefined && <span className={g.fill} style={{ width: `${fill * 100}%` }} />}
    </span>
  );
}

export function Pick({ children, dim }: { readonly children: ReactNode; readonly dim?: boolean }) {
  return (
    <button type="button" className={cx(g.pick, dim && g.isDefault)}>
      {children}
      <span className={g.caret}>▾</span>
    </button>
  );
}

/** Read-only computed text (set by the structure, not editable here). */
export function Out({ children }: { readonly children: ReactNode }) {
  return <span className={g.out}>{children}</span>;
}

export function Seg({ options, value, label }: { readonly options: readonly (readonly [string, string, string?])[]; readonly value: string; readonly label: string }) {
  return (
    <span className={g.seg} role="radiogroup" aria-label={label}>
      {options.map(([k, text, glyph]) => (
        <button key={k} type="button" role="radio" aria-checked={k === value}>
          {glyph && <Glyph kind={glyph} className={g.icon} />}
          {text}
        </button>
      ))}
    </span>
  );
}

/** One-line warning (dashed) or error (solid) with one action. */
export function Chip({ tone = 'warn', children, action }: { readonly tone?: 'warn' | 'error'; readonly children: ReactNode; readonly action?: ReactNode }) {
  return (
    <div className={cx(g.chip, tone === 'error' && g.chipErr)} role="alert">
      <Glyph kind="warn" className={g.icon} />
      <span className={g.chipText}>{children}</span>
      {action && (
        <button type="button" className={g.chipAct}>
          {action}
        </button>
      )}
    </div>
  );
}

export function Btn({ children, kbd, primary, glyph }: { readonly children: ReactNode; readonly kbd?: string; readonly primary?: boolean; readonly glyph?: string }) {
  return (
    <button type="button" className={cx(g.btn, primary && g.btnPrimary)}>
      {glyph && <Glyph kind={glyph} className={g.icon} />}
      {children}
      {kbd && <kbd className={g.kbd}>{kbd}</kbd>}
    </button>
  );
}

/** The step's actions, pinned to the panel foot. */
export function Actions({ group }: { readonly group?: boolean }) {
  return (
    <div className={g.actions}>
      <Btn kbd="⌘D">Duplicate</Btn>
      <Btn kbd={group ? '⇧⌘G' : '⌘G'}>{group ? 'Unwrap' : 'Wrap ▾'}</Btn>
      <Btn kbd="⌫">Delete</Btn>
    </div>
  );
}

export default InspectorGrid;
