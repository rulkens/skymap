import type { ReactNode } from 'react';
import { isValidElement } from 'react';
import cx from 'classnames';
import Slider from '../../../components/common/Slider/Slider';
import CloseIcon from '../../../components/icons/CloseIcon/CloseIcon';
import Glyph from './StudioDGlyph';
import StudioIcon from './StudioIcon';
import StudioTip from './StudioTip';
import g from './InspectorGrid.module.css';

// Shared inspector shell for every studio-d inspector: a dense label | control | unit | reset
// grid. Meaning rides subtle channels: dotted labels open the studio's one tip (StudioTip),
// defaults are dim and dashed, authored values are bright with a ↺ reset, units follow values.
// A ranged number is the app's Slider pill (label in, value + unit in, fill behind both).

type Props = { readonly label?: string; readonly children: ReactNode };

/** The inspector panel: header, then the grid, then the action row. */
function InspectorGrid({ label = 'Step settings', children }: Props) {
  return (
    <aside className={g.panel} aria-label={label}>
      {children}
    </aside>
  );
}

/** Where the step sits (path · index) and its time range; the title names step + value once.
 *  A deep path truncates from the left, so the step's own place stays readable. */
export function Head({ glyph, ch, where, range, title }: { readonly glyph?: string; readonly ch?: string; readonly where: string; readonly range?: string; readonly title: string }) {
  return (
    <header className={g.head}>
      <p className={g.where}>
        {glyph && <Glyph kind={glyph} className={cx(g.whereIcon, ch && g[`c_${ch}`])} />}
        <span className={g.whereText}>
          <bdi className={g.whereInner}>{where}</bdi>
        </span>
        {range && <span className={g.range}>{range}</span>}
      </p>
      <h2 className={g.title}>{title}</h2>
    </header>
  );
}

export function Grid({ children }: { readonly children: ReactNode }) {
  return <div className={g.grid}>{children}</div>;
}

export function Sec({ title, aside }: { readonly title: string; readonly aside?: ReactNode }) {
  return (
    <p className={g.sec}>
      <span>{title}</span>
      {aside && <span className={g.secAside}>{aside}</span>}
    </p>
  );
}

const ResetBtn = ({ label }: { readonly label: string }) => (
  <StudioTip name="Reset" meaning={`${label} back to its default`} side="left">
    <button type="button" className={g.reset} aria-label={`Reset ${label} to default`}>
      <StudioIcon kind="undo" size={12} />
    </button>
  </StudioTip>
);

/** One property. `tip` dots the label and opens StudioTip beside it (over the track); a lone
 *  ranged `Num` child becomes a Slider pill that carries the label and unit itself. */
export function Row({
  label,
  tip,
  tipOpen,
  unit,
  reset,
  span,
  children,
}: {
  readonly label: string;
  readonly tip?: string;
  readonly tipOpen?: boolean;
  readonly unit?: string;
  readonly reset?: boolean;
  /** The control takes the unit and reset columns too (segmented controls, links). */
  readonly span?: boolean;
  readonly children: ReactNode;
}) {
  const dial = isValidElement<NumProps>(children) && children.type === Num && children.props.fill !== undefined;
  if (dial) {
    const pill = <Num {...children.props} label={label} unit={unit} tipped={Boolean(tip)} />;
    return (
      <>
        {tip ? (
          <StudioTip name={label} meaning={tip} state={children.props.dim ? 'Default' : undefined} side="left" open={tipOpen} className={g.dialCell}>
            {pill}
          </StudioTip>
        ) : (
          <span className={g.dialCell}>{pill}</span>
        )}
        <span className={g.resetCell}>{reset && <ResetBtn label={label} />}</span>
      </>
    );
  }
  return (
    <>
      <span className={g.lab}>
        {tip ? (
          <StudioTip name={label} meaning={tip} side="left" open={tipOpen}>
            <span className={g.tipLabel} tabIndex={0}>
              {label}
            </span>
          </StudioTip>
        ) : (
          label
        )}
      </span>
      <span className={cx(g.ctl, span && g.ctlSpan)}>{children}</span>
      {!span && (
        <>
          <span className={g.unit}>{unit}</span>
          <span className={g.resetCell}>{reset && <ResetBtn label={label} />}</span>
        </>
      )}
    </>
  );
}

/** A full-width grid line (chips, a curve, a button row). */
export function Wide({ children }: { readonly children: ReactNode }) {
  return <div className={g.wide}>{children}</div>;
}

type NumProps = {
  readonly value: string;
  readonly fill?: number;
  readonly dim?: boolean;
  readonly label?: string;
  readonly unit?: string;
  readonly tipped?: boolean;
};

/** A number. Ranged (`fill`): the app's Slider pill, drag to scrub. Unbounded (a vector, a
 *  typed time): a text field sized to sit with the pills. `dim` = the default value. */
export function Num({ value, fill, dim, label = '', unit, tipped }: NumProps) {
  if (fill === undefined) {
    return (
      <span className={cx(g.num, dim && g.isDefault)} role="textbox" tabIndex={0} aria-label={value}>
        {value}
      </span>
    );
  }
  const n = parseFloat(value.replace('−', '-').replace('±', '').trim()) || 0;
  const max = fill > 0 ? Math.abs(n) / fill || 1 : Math.max(1, Math.abs(n));
  const shown = unit ? `${value}${unit === '×' || unit === '°' ? '' : ' '}${unit}` : value;
  return (
    <span className={cx(g.dial, dim && g.dialDefault, tipped && g.dialTipped, !label && g.dialBare)}>
      <Slider label={label} value={Math.abs(n)} min={0} max={max} step={0.01} format={() => shown} onChange={() => undefined} />
    </span>
  );
}

export function Pick({ children, dim }: { readonly children: ReactNode; readonly dim?: boolean }) {
  return (
    <button type="button" className={cx(g.pick, dim && g.isDefault)}>
      {children}
      <span className={g.caret}>
        <StudioIcon kind="chevronDown" size={12} />
      </span>
    </button>
  );
}

/** Read-only computed text (set by the structure, not editable here). */
export function Out({ children }: { readonly children: ReactNode }) {
  return <span className={g.out}>{children}</span>;
}

export function Seg({ options, value, label }: { readonly options: readonly (readonly [string, string, string?])[]; readonly value: string; readonly label: string }) {
  return (
    <span className={g.seg} role="radiogroup" aria-label={label}>
      {options.map(([k, text, glyph]) => (
        <button key={k} type="button" role="radio" aria-checked={k === value}>
          {glyph && <Glyph kind={glyph} className={g.icon} />}
          {text}
        </button>
      ))}
    </span>
  );
}

/** One-line warning (dashed) or error (solid) with one action. */
export function Chip({ tone = 'warn', children, action }: { readonly tone?: 'warn' | 'error'; readonly children: ReactNode; readonly action?: ReactNode }) {
  return (
    <div className={cx(g.chip, tone === 'error' && g.chipErr)} role="alert">
      <Glyph kind="warn" className={g.icon} />
      <span className={g.chipText}>{children}</span>
      {action && (
        <button type="button" className={g.chipAct}>
          {action}
        </button>
      )}
    </div>
  );
}

/** A button. Its key (`kbd`) and meaning live in its StudioTip, never printed on it (Q30). */
export function Btn({
  children,
  kbd,
  tip,
  meaning,
  primary,
  glyph,
}: {
  readonly children: ReactNode;
  readonly kbd?: string;
  readonly tip?: string;
  readonly meaning?: string;
  readonly primary?: boolean;
  readonly glyph?: string;
}) {
  const btn = (
    <button type="button" className={cx(g.btn, primary && g.btnPrimary)}>
      {glyph && <Glyph kind={glyph} className={g.icon} />}
      {children}
    </button>
  );
  if (!kbd && !meaning) return btn;
  return (
    <StudioTip name={tip ?? (typeof children === 'string' ? children.replace(/ ▾$/, '') : '')} meaning={meaning} keys={kbd ? Array.from(kbd) : undefined}>
      {btn}
    </StudioTip>
  );
}

/** "Use current view": one name everywhere; the inspector context says what it captures. */
export function UseView({ primary, captures }: { readonly primary?: boolean; readonly captures: string }) {
  return (
    <Btn primary={primary} glyph="look" kbd="V" meaning={`Sets ${captures} from the Edit view`}>
      Use current view
    </Btn>
  );
}

export function RemoveX({ label }: { readonly label: string }) {
  return (
    <button type="button" className={g.removeX} aria-label={`Remove ${label}`}>
      <CloseIcon size={10} />
    </button>
  );
}

/** The step's actions, right under the grid. */
export function Actions({ group }: { readonly group?: boolean }) {
  return (
    <div className={g.actions}>
      <Btn kbd="⌘D">Duplicate</Btn>
      <Btn kbd={group ? '⇧⌘G' : '⌘G'} tip={group ? 'Unwrap' : 'Wrap in In order / Together'}>
        {group ? 'Unwrap' : 'Wrap'}
      </Btn>
      <Btn kbd="⌫">Delete</Btn>
    </div>
  );
}

export default InspectorGrid;
