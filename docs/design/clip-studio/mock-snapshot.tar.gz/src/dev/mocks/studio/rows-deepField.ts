// Rows for the real grand-tour beat `deepField` (tours/grandTour/deepField.ts): compileClip gives
// 4 s, with every cue at 0 s. The quasar reveal fades over 6 s, so 2 s of it plays after End and,
// since a clip's scene reverts when it ends, is never seen in the studio preview.
import { row } from './stepsD';

export function deepFieldRows() {
  return [
    row('start', 0, 'start', 'Start', '', 'live view · pinned', '–', 0, 0, { writes: ['dist', 'look', 'turn'] }),
    row('defocus', 0, 'focus', 'Focus', '', 'none', '0 s', 0, 0, { ch: 'settings' }),
    row('rings', 0, 'hide', 'Hide', '', 'rings · void, supercluster', '2 s', 0, 0, { ch: 'layers', over: 2, from: 1, to: 0 }),
    row('quasars', 0, 'show', 'Show', '', 'quasars', '6 s', 0, 0, { ch: 'layers', over: 6, from: 0, to: 1, warn: true }),
    row('home', 0, 'look', 'Look-at', '→', '0, 0, 0 Mpc', '4 s', 0, 4, { ch: 'look' }),
  ];
}
