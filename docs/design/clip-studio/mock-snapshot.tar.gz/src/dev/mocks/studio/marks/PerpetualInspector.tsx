import Panel, { Head, Grid, Sec, Row, Num, Out, Seg, Actions } from '../InspectorGrid';

type Props = Record<string, never>;

// flowOrbit's forked oscillate. Length ∞ = no `over`; Fade exists only for a window, so it sits
// dim at its default. Phase at End decides whether a replay of the clip loops cleanly.
function PerpetualInspector(_: Props) {
  return (
    <Panel>
      <Head glyph="osc" ch="turn" where="Background · 2/4" range="0.0 s → ∞" title="Bob tilt ± 6.9°" />
      <Grid>
        <Sec title="Wave" />
        <Row label="Swing" tip="Peak tilt either side of the path" unit="°" reset>
          <Num value="± 6.9" fill={0.46} />
        </Row>
        <Row label="Period" unit="s" reset>
          <Num value="30.0" fill={0.5} />
        </Row>
        <Row label="Length" tip="∞ runs until End cuts it">
          <Seg label="Length" value="inf" options={[['inf', '∞'], ['win', 'window']]} />
        </Row>
        <Row label="Fade" tip="Window only" unit="s">
          <Num value="–" dim />
        </Row>
        <Sec title="Seam" aside="at End 30.0 s" />
        <Row label="Phase" tip="360° = back where it started">
          <Out>360° ✓</Out>
        </Row>
        <Sec title="Run" />
        <Row label="Background" tip="Runs under the timeline, adds no time">
          <Seg label="Background" value="on" options={[['on', 'on'], ['off', 'off']]} />
        </Row>
      </Grid>
      <Actions />
    </Panel>
  );
}

export default PerpetualInspector;
