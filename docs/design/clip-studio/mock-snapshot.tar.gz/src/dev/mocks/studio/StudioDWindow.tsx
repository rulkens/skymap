import s from './StudioDWindow.module.css';

const VIEW = new URL('./assets/camera-view-full.jpg', import.meta.url).href;

type Props = Record<string, never>;

// Q24–Q25: the Camera view detached into window 2 — the renderer fills it, a minimal label and
// Dock back; closing the window docks it back as well.
function StudioDWindow(_: Props) {
  return (
    <div className={s.win} aria-label="Camera view window">
      <img className={s.view} src={VIEW} alt="" />
      <span className={s.label}>
        <b>Camera</b> · Cosmic Flows · 7.4 s
      </span>
      <button type="button" className={s.back}>⤓ Dock back</button>
      <div className={s.progress} aria-hidden>
        <span className={s.fill} />
      </div>
    </div>
  );
}

export default StudioDWindow;
