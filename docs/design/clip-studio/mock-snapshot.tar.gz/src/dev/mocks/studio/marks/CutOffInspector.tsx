import Panel, { Head, Grid, Sec, Row, Wide, Num, Chip, Actions } from '../InspectorGrid';
import d from '../StudioD.module.css';

type Props = Record<string, never>;

// deepField's quasar reveal: a 6 s fade in a 4 s clip. One fix on the chip (hold past it);
// shortening the fade to End is the Over field itself.
function CutOffInspector(_: Props) {
  return (
    <Panel>
      <Head glyph="layers" ch="layers" where="Top level · 3/4" range="0.0 s" title="Show · quasars" />
      <Grid>
        <Sec title="Layers" aside="1" />
        <Wide>
          <span className={d.chip}>
            Quasars
            <button type="button" className={d.chipX} aria-label="Remove Quasars">×</button>
          </span>
          <button type="button" className={d.chipAdd}>+ Layer</button>
        </Wide>
        <Sec title="Value" />
        <Row label="Over" tip="Fade length; the step itself takes 0 s" unit="s" reset>
          <Num value="6.0" fill={0.6} />
        </Row>
        <Chip action="+ Hold 2 s">2 s past End · unseen</Chip>
      </Grid>
      <Actions />
    </Panel>
  );
}

export default CutOffInspector;
