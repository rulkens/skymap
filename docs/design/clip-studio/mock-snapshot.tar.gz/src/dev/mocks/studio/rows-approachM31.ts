// Rows for the real grand-tour beat `approachM31` (tours/grandTour/approachM31.ts), timings by
// hand from the clip model (cues take zero time; `frameTo` and `show` run their `over` alongside).
// Every FocusId-bound effect carries `subj`: the named subject shows as a pill in the Value column
// and as a target ring where its bar lands, because the number only exists at play time.
import { row } from './stepsD';

export function approachM31Rows() {
  return [
    row('start', 0, 'start', 'Start', '', 'live view · pinned', '–', 0, 0, { writes: ['dist', 'look', 'turn'] }),
    row('frame', 0, 'frame', 'Frame', '→', 'supergalactic', '3 s', 0, 0, { ch: 'settings', over: 3 }),
    row('show', 0, 'show', 'Show', '', 'famous galaxies', '1 s', 0, 0, { ch: 'layers', over: 1, from: 0, to: 1, levelTo: 10 }),
    row('turnTo', 0, 'all', 'Together', '', 'Aim, Strafe', '3 s', 0, 3, { writes: ['turn', 'look'] }),
    row('aim', 1, 'aim', 'Aim', '→', '', '3 s', 0, 3, { ch: 'turn', subj: 'M31' }),
    row('strafe', 1, 'strafe', 'Strafe', '', '+10°', '3 s', 0, 3, { ch: 'look', subj: 'M31' }),
    row('focus', 0, 'focus', 'Focus', '', '', '0 s', 3, 3, { ch: 'settings', subj: 'M31' }),
    row('hold', 0, 'hold', 'Hold', '', '', '1 s', 3, 4),
    row('fly', 0, 'all', 'Together', '', 'Look-at, Distance', '6 s', 4, 10, { writes: ['look', 'dist'] }),
    row('look', 1, 'look', 'Look-at', '→', '', '6 s', 4, 10, { ch: 'look', subj: 'M31' }),
    row('dolly', 1, 'dist', 'Distance', '→', '', '6 s', 4, 10, { ch: 'dist', subj: 'M31', sub: 'scale 0.7' }),
  ];
}
