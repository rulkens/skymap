import Glyph from '../StudioDGlyph';
import sd from '../StudioD.module.css';
import s from './CameraInset.module.css';

type Props = { readonly src: string; readonly time: string; readonly bottom: string };

// Q21: the Camera view as a picture-in-picture over the Edit view: what the clip camera sees at
// the playhead. F (or the swap button) trades the two; the inset never covers the dock.
function CameraInset({ src, time, bottom }: Props) {
  return (
    <figure className={s.inset} style={{ bottom }} aria-label="Camera view">
      <img className={s.img} src={src} alt="" />
      <figcaption className={s.cap}>
        <span className={s.dot} />
        Camera<span className={s.time}>{time}</span>
        <button type="button" className={sd.tbtn} aria-label="Swap views">
          <Glyph kind="swap" className={sd.btnIcon} />
          <kbd className={sd.kbd}>F</kbd>
        </button>
      </figcaption>
    </figure>
  );
}

export default CameraInset;
