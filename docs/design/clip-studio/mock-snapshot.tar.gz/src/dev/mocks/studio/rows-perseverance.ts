// Rows for the real `perseveranceToSondermarken` clip (97 s, compileClip at J2000). Values are
// the factory's literals at that instant: distances on the app's ladder (8.6 m → 4.5 AU → 801 m),
// aims as yaw, pitch. `aimAt` is one authored row although it compiles to a yaw and a pitch tween.
import { row } from './stepsD';

export function perseveranceRows() {
  const pair = (id: string, d: number, a: number, z: number, aim: string, roll: string) => [
    row(id, d, 'all', 'Together', '', 'Aim, Roll', `${z - a} s`, a, z, { writes: ['turn'] }),
    row(`${id}Aim`, d + 1, 'aim', 'Aim', '→', aim, `${z - a} s`, a, z, { ch: 'turn' }),
    row(`${id}Roll`, d + 1, 'roll', 'Roll', '→', roll, `${z - a} s`, a, z, { ch: 'turn' }),
  ];
  return [
    row('start', 0, 'start', 'Start', '', 'saved view · 8.6 m', '–', 0, 0, { writes: ['dist', 'look', 'turn'], dated: true }),
    row('main', 0, 'seq', 'In order', '', 'Wait, Together +2', '97 s', 0, 97, { writes: ['dist', 'look', 'turn'] }),
    row('lead', 1, 'wait', 'Wait', '', '', '3 s', 0, 3),
    row('out', 1, 'all', 'Together', '', 'Distance, In order ×2', '45 s', 3, 48, { writes: ['dist', 'look', 'turn'] }),
    row('outDist', 2, 'dist', 'Distance', '→', '4.5 AU', '45 s', 3, 48, { ch: 'dist' }),
    row('outLookSeq', 2, 'seq', 'In order', '', 'Wait, Look-at', '45 s', 3, 48, { writes: ['look'] }),
    row('outLookWait', 3, 'wait', 'Wait', '', '', '33 s', 3, 36),
    row('outLook', 3, 'look', 'Look-at', '→', '0, 0, 0 AU', '12 s', 36, 48, { ch: 'look' }),
    row('outAimSeq', 2, 'seq', 'In order', '', 'Aim, Wait +1', '45 s', 3, 48, { writes: ['turn'] }),
    row('outDown', 3, 'aim', 'Aim', '→', '30.1°, 2.9°', '14 s', 3, 17, { ch: 'turn' }),
    row('outAimWait', 3, 'wait', 'Wait', '', '', '19 s', 17, 36),
    ...pair('outSwing', 3, 36, 48, '30.1°, 40.0°', '0°'),
    row('sysHold', 1, 'hold', 'Hold', '', '', '4 s', 48, 52),
    row('in', 1, 'all', 'Together', '', 'Distance, Look-at +1', '45 s', 52, 97, { writes: ['dist', 'look', 'turn'] }),
    row('inDist', 2, 'dist', 'Distance', '→', '801 m', '45 s', 52, 97, { ch: 'dist' }),
    row('inLook', 2, 'look', 'Look-at', '→', '−0.18, 0.89, 0.38 AU', '12 s', 52, 64, { ch: 'look' }),
    row('inAimSeq', 2, 'seq', 'In order', '', 'Together, Wait +1', '45 s', 52, 97, { writes: ['turn'] }),
    ...pair('inDescend', 3, 52, 68, '56.1°, 74.6°', '−35.9°'),
    row('inAimWait', 3, 'wait', 'Wait', '', '', '15 s', 68, 83),
    ...pair('inTilt', 3, 83, 97, '8.1°, −7.0°', '−11.4°'),
  ];
}
