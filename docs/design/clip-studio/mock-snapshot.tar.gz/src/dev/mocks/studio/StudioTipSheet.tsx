import PlayIcon from '../../../components/icons/PlayIcon/PlayIcon';
import Glyph from './StudioDGlyph';
import StudioIcon from './StudioIcon';
import StudioTip from './StudioTip';
import s from './StudioTipSheet.module.css';

// Contact sheet for the shot: one sample trigger per place a StudioTip is used, all open.
function StudioTipSheet() {
  return (
    <div className={s.sheet} aria-label="Tooltip contact sheet">
      <figure className={s.cell}>
        <StudioTip name="Play" keys={['Space']} state="From 7.40 s" open>
          <button type="button" className={s.play} aria-label="Play"><PlayIcon size={16} /></button>
        </StudioTip>
        <figcaption className={s.cap}>Transport</figcaption>
      </figure>
      <figure className={s.cell}>
        <StudioTip name="Undo" keys={['⌘', 'Z']} state={<><span className={s.dim}>Last edit</span> Blend 1 s</>} open>
          <button type="button" className={s.icon} aria-label="Undo blend"><StudioIcon kind="undo" /></button>
        </StudioTip>
        <figcaption className={s.cap}>Undo · state</figcaption>
      </figure>
      <figure className={s.cell}>
        <StudioTip name="Swap views" keys={['F']} state="Main: Edit · inset: Camera" open>
          <button type="button" className={s.icon} aria-label="Swap views"><StudioIcon kind="swap" /></button>
        </StudioTip>
        <figcaption className={s.cap}>View control</figcaption>
      </figure>
      <figure className={s.cell}>
        <StudioTip name="Distance" meaning="Camera distance to target" state="Written by 3 steps" open>
          <span className={s.chan} tabIndex={0}><Glyph kind="dist" className={s.glyph} /></span>
        </StudioTip>
        <figcaption className={s.cap}>Channel glyph</figcaption>
      </figure>
      <figure className={s.cell}>
        <StudioTip name="Ramp" meaning="Time to reach cruise speed" state={<><span className={s.dim}>Default</span> 1.4 s · ↺ resets</>} open>
          <span className={s.label} tabIndex={0}>Ramp</span>
        </StudioTip>
        <figcaption className={s.cap}>Inspector label</figcaption>
      </figure>
      <figure className={s.cell}>
        <StudioTip name="Blend" meaning="Overlap crossfades the two moves" state="1.0 s · In order" open>
          <span className={s.mark} tabIndex={0}><Glyph kind="jblend" className={s.glyph} /></span>
        </StudioTip>
        <figcaption className={s.cap}>Timeline mark</figcaption>
      </figure>
    </div>
  );
}

export default StudioTipSheet;
