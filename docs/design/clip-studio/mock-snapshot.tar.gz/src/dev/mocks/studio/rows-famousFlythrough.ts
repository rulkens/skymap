// Rows for the famousFlythrough clip (src/data/animation/clips/famousFlythrough.ts): one flyPath,
// 12 atFocus waypoints, `over: 100`, every other knob the helper default (pathDefaults.ts).
// Timings come from buildPathTrack run on the seed positions (famous_galaxies.seed.json → RA/Dec
// → Cartesian, arrivalFraming at 60°) with the live start pinned at the extragalactic pose:
// `at` = wall-clock arrival at the knot, `cruise` = its leg's arc-length share of the 100 s,
// `r` = subject radius (kpc), `frame` = framing distance (kpc), `PACE` = d(base)/d(wall) every 0.2 s.

import { row } from './stepsD';

export const FLY = {
  total: 107.46,
  over: 100,
  align: 1.35,
  rampSec: 1.4,
  linger: 0.7,
  lingerSec: 1.4,
  turnDelay: 1.1,
  lookAhead: 1.3,
  passOffset: 4,
};

export const WPS = [
  {id: "c65", name: "Sculptor Galaxy", mpc: 3.7, r: 14.4, frame: 230, cruise: 7.48, at: 8.68, minPace: 0.4},
  {id: "m31", name: "Andromeda Galaxy", mpc: 0.78, r: 20.2, frame: 323, cruise: 5.03, at: 14.26, minPace: 0.39},
  {id: "m101", name: "Pinwheel Galaxy", mpc: 7.11, r: 24.8, frame: 397, cruise: 6.64, at: 21.43, minPace: 0.39},
  {id: "m51", name: "Whirlpool Galaxy", mpc: 8.58, r: 17.1, frame: 274, cruise: 2.14, at: 24.15, minPace: 0.39},
  {id: "m63", name: "Sunflower Galaxy", mpc: 9.04, r: 15.5, frame: 249, cruise: 1.48, at: 26.23, minPace: 0.39},
  {id: "m104", name: "Sombrero Galaxy", mpc: 8.6, r: 10.6, frame: 169, cruise: 14.05, at: 40.71, minPace: 0.39},
  {id: "m83", name: "Southern Pinwheel Galaxy", mpc: 4.9, r: 9.7, frame: 155, cruise: 11.68, at: 52.85, minPace: 0.39},
  {id: "c77", name: "Centaurus A", mpc: 3.68, r: 13.7, frame: 219, cruise: 3.39, at: 56.81, minPace: 0.39},
  {id: "m33", name: "Triangulum Galaxy", mpc: 0.88, r: 7.9, frame: 150, cruise: 8.34, at: 65.66, minPace: 0.39},
  {id: "m81", name: "Bode's Galaxy", mpc: 3.6, r: 11.3, frame: 181, cruise: 8.52, at: 74.69, minPace: 0.4},
  {id: "m64", name: "Black Eye Galaxy", mpc: 4.41, r: 6.7, frame: 150, cruise: 8.64, at: 83.83, minPace: 0.39},
  {id: "m87", name: "Virgo A", mpc: 16.78, r: 17.4, frame: 278, cruise: 22.61, at: 107.46, minPace: 0.03},
];

export const PACE = '0 0.14 0.29 0.43 0.58 0.72 0.87 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 0.69 0.48 0.41 0.4 0.45 0.62 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 0.62 0.44 0.39 0.4 0.44 0.65 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 0.98 0.62 0.43 0.39 0.4 0.5 0.65 1.01 1.01 1.01 1.01 1.01 1.01 1.01 0.76 0.48 0.42 0.39 0.43 0.54 0.87 1.01 1.01 1.01 1 0.56 0.46 0.39 0.41 0.46 0.72 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 0.68 0.47 0.4 0.39 0.42 0.6 0.95 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 0.58 0.48 0.39 0.4 0.45 0.69 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 0.94 0.59 0.42 0.39 0.4 0.47 0.69 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 0.61 0.47 0.39 0.4 0.44 0.66 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 0.68 0.49 0.4 0.4 0.45 0.63 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1 0.56 0.46 0.39 0.41 0.47 0.72 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 1.01 0.78 0.49 0.42 0.35 0.3 0.27 0.25 0.22 0.13 0.03'.split(' ').map(Number);

// Durations follow the naming table: one decimal below 10 s, whole seconds above.
const secs = (v: number) => (v < 10 ? `${v.toFixed(1)} s` : `${Math.round(v)} s`);

export function flyRows() {
  const short = (n: string) => n.replace(/ Galaxy$/, '');
  return [
    row('start', 0, 'start', 'Start', '', 'live view · pinned', '–', 0, 0, { writes: ['dist', 'look', 'turn'] }),
    row('fly', 0, 'fly', 'Fly', '', `via ${short(WPS[0]!.name)}, ${short(WPS[1]!.name)} +${WPS.length - 2}`, secs(FLY.total), 0, FLY.total, {
      writes: ['dist', 'look', 'turn'],
    }),
    ...WPS.map((w, i) => {
      const last = i === WPS.length - 1;
      const from = i === 0 ? 0 : WPS[i - 1]!.at;
      return row(`wp-${w.id}`, 1, last ? 'settle' : 'pass', last ? 'Settle' : 'Pass', last ? '→' : '', w.name, secs(w.at - from), from, w.at, {
        sub: w.id.toUpperCase(),
      });
    }),
  ];
}
