import { distanceAt } from './studioDCurves';
import { clipTime } from './clipTime';
import Glyph from './StudioDGlyph';
import StudioTip from './StudioTip';
import s from './StudioDViews.module.css';

type Props = {
  readonly t: number;
  readonly clipEnd: number;
  readonly swapped: boolean;
  readonly detached?: boolean;
  // Cosmic Flows only: a drawn stand-in for the real clip-path overlay (route, look-at, frame box).
  readonly route?: boolean;
  // What the clip camera sees at the playhead (labels off, Q21), and the Edit view's thumbnail.
  readonly inset: string;
  readonly editInset?: string;
};

// Q21: the main viewport is the Edit view (free camera, the clip's path overlay over the scene's
// own labels); the inset is the Camera view. Same chrome in every clip: Edit label bottom-left,
// Camera inset bottom-right over the dock, each with a detach control (Q24). F or a click swaps.
const EDIT_IMG = new URL('./assets/edit-view.jpg', import.meta.url).href;
const FOV_HALF = Math.PI / 6;

// Cosmic Flows seen from outside: radius ∝ distance, angle = integrated yaw rate (rad/s).
function yawRate(t: number) {
  if (t < 2) return 0;
  if (t < 3.5) return 0.18 * ((t - 2) / 1.5) ** 3;
  if (t < 4) return 0.18;
  if (t < 15) return 0.18 + (0.025 - 0.18) * (1 - Math.cos((Math.PI * (t - 4)) / 11)) * 0.5;
  return 0.025;
}
function route(clipEnd: number) {
  const pts: { x: number; y: number; v: number }[] = [];
  let yaw = 0;
  let prev = 0;
  for (let i = 0; i <= 200; i++) {
    const t = (clipEnd * i) / 200;
    yaw += yawRate(t) * (clipEnd / 200);
    const d = t < 4 ? 0.14 : t > 11 ? 950 : 10 ** distanceAt(t, 'blend');
    const r = (d / 950) * 520;
    const p = { x: 864 + r * Math.cos(yaw + 2.6), y: 228 + r * 0.42 * Math.sin(yaw + 2.6), v: 0 };
    p.v = Math.abs(d - prev);
    prev = d;
    pts.push(p);
  }
  return pts;
}

function Detach({ view }: { readonly view: string }) {
  return (
    <StudioTip name="Open in a window" meaning={`${view} view in its own window`}>
      <button type="button" className={s.detach} aria-label={`Open the ${view} view in a new window`}>
        <Glyph kind="detach" className={s.detachG} />
      </button>
    </StudioTip>
  );
}

function StudioDViews({ t, clipEnd, swapped, detached = false, route: showRoute = false, inset, editInset = EDIT_IMG }: Props) {
  const time = clipTime(clipEnd);
  const after = t > clipEnd;
  const pts = route(clipEnd);
  // Past End the clip's scene has reverted: the camera sits back at the Start pose.
  const at = pts[after ? 0 : Math.round((t / clipEnd) * 200)]!;
  const vMax = Math.max(...pts.map((p) => p.v));
  const segs = pts.slice(1).map((p, i) => ({ a: pts[i]!, b: p, k: Math.min(1, p.v / vMax) }));
  // The frame box at real size: the view cone reaches the look-at, its far edge spans the
  // framed width there. The playhead dot stays a fixed 5 px so it reads at any distance.
  const dx = 864 - at.x;
  const dy = 228 - at.y;
  const len = Math.hypot(dx, dy);
  const ang = Math.atan2(dy, dx);
  const edge = (sgn: number) => {
    const half = len * Math.tan(FOV_HALF);
    return `${864 + sgn * half * Math.cos(ang + Math.PI / 2)},${228 + sgn * half * Math.sin(ang + Math.PI / 2)}`;
  };
  const cam = (
    <>
      <b>Camera</b> · {time.at(t)}
      {after && <span className={s.after}>after End · reverted</span>}
    </>
  );
  return (
    <div className={s.layer}>
      {!swapped && showRoute && (
        <svg className={s.route} viewBox="0 0 1728 440" preserveAspectRatio="xMidYMid meet" aria-label="Clip path">
          {segs.map((g, i) => (
            <line key={i} x1={g.a.x} y1={g.a.y} x2={g.b.x} y2={g.b.y} className={s.seg} style={{ opacity: 0.35 + 0.65 * g.k, strokeWidth: 1.5 + 3.5 * g.k }} />
          ))}
          {len > 1 && <polygon className={s.frustum} points={`${at.x},${at.y} ${edge(-1)} ${edge(1)}`} />}
          {len > 1 && <line className={s.frameEdge} x1={edge(-1).split(',')[0]} y1={edge(-1).split(',')[1]} x2={edge(1).split(',')[0]} y2={edge(1).split(',')[1]} />}
          <line className={s.lookLine} x1={at.x} y1={at.y} x2={864} y2={228} />
          <circle className={s.pin} cx="864" cy="228" r="4" />
          <circle className={s.camDot} cx={at.x} cy={at.y} r="5" />
          <text className={s.pinText} x="874" y="246">Start · look-at</text>
          <text className={s.pinText} x={pts[200]!.x + 10} y={pts[200]!.y + 4}>End {time.at(clipEnd)}</text>
          <text className={s.pinText} x={at.x - 14} y={at.y - 14}>{after ? 'reverted' : time.at(t)}</text>
        </svg>
      )}
      <span className={s.mainLabel}>
        {swapped ? cam : <><b>Edit</b> · free</>}
        {!swapped && showRoute && (
          <span className={s.speed}>
            path
            <span className={s.speedRamp} />
            slow → fast
          </span>
        )}
        <Detach view={swapped ? 'Camera' : 'Edit'} />
      </span>
      {detached ? (
        <span className={s.away} role="status">
          <b>Camera</b> · in window 2
          <StudioTip name="Bring back" meaning="Returns the Camera view to the inset">
            <button type="button" className={s.back}>
              <Glyph kind="dock" className={s.detachG} />
              Bring back
            </button>
          </StudioTip>
        </span>
      ) : (
        <figure className={s.inset}>
          <StudioTip name={swapped ? 'Edit view' : 'Camera view'} meaning={swapped ? 'Free camera, path overlay' : 'What the clip camera sees'} keys={['F']} state="Click to swap">
            <img className={s.insetImg} src={swapped ? editInset : inset} alt="" />
          </StudioTip>
          <figcaption className={s.insetLabel}>
            {swapped ? <><b>Edit</b> · free</> : cam}
            <Detach view={swapped ? 'Edit' : 'Camera'} />
          </figcaption>
        </figure>
      )}
    </div>
  );
}

export default StudioDViews;
