import cx from 'classnames';
import { distanceAt } from './studioDCurves';
import s from './StudioDViews.module.css';

type Props = {
  readonly t: number;
  readonly clipEnd: number;
  readonly swapped: boolean;
  readonly detached?: boolean;
};

// Q21: the main viewport is the Edit view (free camera, the clip's route drawn in the scene);
// the inset is the Camera view (exactly what the clip camera sees at the playhead). F swaps them.
const CAMERA_IMG = new URL('./assets/camera-view.jpg', import.meta.url).href;
const EDIT_IMG = new URL('./assets/edit-view.jpg', import.meta.url).href;

// Cosmic Flows seen from outside: radius ∝ distance, angle = integrated yaw rate (rad/s).
function yawRate(t: number) {
  if (t < 2) return 0;
  if (t < 3.5) return 0.18 * ((t - 2) / 1.5) ** 3;
  if (t < 4) return 0.18;
  if (t < 15) return 0.18 + (0.025 - 0.18) * (1 - Math.cos((Math.PI * (t - 4)) / 11)) * 0.5;
  return 0.025;
}
function route(clipEnd: number) {
  const pts: { x: number; y: number; v: number }[] = [];
  let yaw = 0;
  let prev = 0;
  for (let i = 0; i <= 200; i++) {
    const t = (clipEnd * i) / 200;
    yaw += yawRate(t) * (clipEnd / 200);
    const d = t < 4 ? 0.14 : t > 11 ? 950 : 10 ** distanceAt(t, 'blend');
    const r = (d / 950) * 520;
    const p = { x: 864 + r * Math.cos(yaw + 2.6), y: 228 + r * 0.42 * Math.sin(yaw + 2.6), v: 0 };
    p.v = Math.abs(d - prev);
    prev = d;
    pts.push(p);
  }
  return pts;
}

function StudioDViews({ t, clipEnd, swapped, detached = false }: Props) {
  const pts = route(clipEnd);
  const at = pts[Math.round((t / clipEnd) * 200)]!;
  const vMax = Math.max(...pts.map((p) => p.v));
  const segs = pts.slice(1).map((p, i) => ({ a: pts[i]!, b: p, k: Math.min(1, p.v / vMax) }));
  const ang = Math.atan2(228 - at.y, 864 - at.x);
  const fr = (da: number, len: number) => `${at.x + len * Math.cos(ang + da)},${at.y + len * Math.sin(ang + da)}`;
  return (
    <div className={s.layer}>
      {!swapped && (
        <svg className={s.route} viewBox="0 0 1728 440" preserveAspectRatio="xMidYMid meet" aria-label="Clip route">
          {segs.map((g, i) => (
            <line key={i} x1={g.a.x} y1={g.a.y} x2={g.b.x} y2={g.b.y} className={s.seg} style={{ opacity: 0.45 + 0.55 * g.k, strokeWidth: 2 + 3 * g.k }} />
          ))}
          <polygon className={s.frustum} points={`${at.x},${at.y} ${fr(-0.32, 70)} ${fr(0.32, 70)}`} />
          <circle className={s.camDot} cx={at.x} cy={at.y} r="5" />
          <line className={s.lookLine} x1={at.x} y1={at.y} x2={864} y2={228} />
          <circle className={s.pin} cx="864" cy="228" r="4" />
          <text className={s.pinText} x="874" y="222">Start · look-at</text>
          <text className={s.pinText} x={pts[200]!.x + 10} y={pts[200]!.y + 4}>End {clipEnd} s</text>
          <text className={cx(s.pinText, s.pinNow)} x={at.x + 12} y={at.y + 18}>{t.toFixed(1)} s</text>
        </svg>
      )}
      <span className={s.mainLabel}>
        {swapped ? (
          <>
            <b>Camera</b> · {t.toFixed(1)} s
          </>
        ) : (
          <>
            <b>Edit</b> · free · route
            <span className={s.speed}>
              <span className={s.speedRamp} />
              slow → fast
            </span>
          </>
        )}
        <button type="button" className={s.detach} aria-label="Open this view in a new window">↗</button>
      </span>
      {detached ? (
        <span className={s.away} role="status">
          <b>Camera</b> · in window 2
          <button type="button" className={s.back}>⤓ Bring back</button>
        </span>
      ) : (
      <figure className={s.inset}>
        <img className={s.insetImg} src={swapped ? EDIT_IMG : CAMERA_IMG} alt="" />
        <figcaption className={s.insetLabel}>
          {swapped ? (
            <>
              <b>Edit</b> · free
            </>
          ) : (
            <>
              <b>Camera</b> · {t.toFixed(1)} s
            </>
          )}
          <button type="button" className={s.detach} aria-label="Open this view in a new window">↗</button>
        </figcaption>
      </figure>
      )}
    </div>
  );
}

export default StudioDViews;
