import cx from 'classnames';
import { sample } from '../studioDCurves';
import d from '../StudioD.module.css';
import s from './PerpetualCut.module.css';

type Props = {
  readonly r: { readonly kind: string; readonly ch: string; readonly start: number; readonly period: number };
  readonly clipEnd: number;
  readonly viewEnd: number;
};

// A perpetual step (Dur ∞) has no end of its own: the clip's End cuts it. Past End it fades out
// as a dashed ghost in phase, so "would keep going" and "stops here" read together.
function PerpetualCut({ r, clipEnd, viewEnd }: Props) {
  const x = (t: number) => `${(t / viewEnd) * 100}%`;
  const len = viewEnd - clipEnd;
  const wave = r.kind === 'osc' && r.period > 0;
  const pts = wave
    ? sample(clipEnd, viewEnd, 60, (t) => 1 - 0.8 * Math.sin((2 * Math.PI * (t - r.start)) / r.period), (t) => t - clipEnd)
    : '';
  return (
    <>
      {wave ? (
        <svg className={cx(s.ghost, d[`c_${r.ch}`])} style={{ left: x(clipEnd), width: x(len) }} viewBox={`0 0 ${len} 2`} preserveAspectRatio="none" aria-hidden>
          <polyline points={pts} vectorEffect="non-scaling-stroke" />
        </svg>
      ) : (
        <span className={cx(s.ghostBar, d[`c_${r.ch}`])} style={{ left: x(clipEnd), width: x(len) }} />
      )}
      <span className={s.cut} style={{ left: x(clipEnd) }} aria-hidden />
      <span className={s.tag} style={{ left: x(clipEnd) }}>∞ cut</span>
    </>
  );
}

export default PerpetualCut;
