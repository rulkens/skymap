import StudioB from './studio/StudioB';

function Mock() {
  return <StudioB mode="overview" />;
}

export default Mock;
