import StudioB from './studio/StudioB';

function Mock() {
  return <StudioB mode="empty" />;
}

export default Mock;
