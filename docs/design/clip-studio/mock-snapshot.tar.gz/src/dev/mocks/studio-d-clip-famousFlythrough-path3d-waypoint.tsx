import { useEffect } from 'react';
import cx from 'classnames';
import StudioD from './studio/StudioD';
import FlyPathTrack from './studio/marks/FlyPathTrack';
import FlyPathInspector from './studio/marks/FlyPathInspector';
import Glyph from './studio/StudioDGlyph';
import { FLY, flyRows } from './studio/rows-famousFlythrough';
import { useAppDispatch } from '../../store/hooks';
import type { SkymapHook } from '../../@types/automation/SkymapHook';
import { inspectClipPath, setClipPathScrub } from '../../state/settings/core/debugSlice';
import sd from './studio/StudioD.module.css';
import pl from './studio/marks/PathLegend.module.css';

// Q21 Edit view: the REAL clip-path overlay (route, look-at path, frustum) drawn around a free
// camera outside the route; the Camera view is the inset. the Whirlpool waypoint selected, playhead 23.4 s.
// The overlay is computed once (the live camera at that moment is the path's start) and its scrub
// follows the playhead: scrub01 = t / duration, until the store carries seconds.
const EDIT_POSE = 'a,-5.116,-2.185,5.976,0.8292,0.1539,4.000,0';

function Mock() {
  const sel = 'wp-m51';
  const wp = 'wp-m51';
  const t = 23.4;
  const dispatch = useAppDispatch();
  // Boot sits at the clip's start pose, so the path's live start knot is captured there; then
  // the Edit camera cuts to a view of the route from outside. Re-runs on every fresh page.
  useEffect(() => {
    let live = true;
    const run = async () => {
      while (live && !Reflect.get(window, '__skymap')) await new Promise((r) => setTimeout(r, 250));
      const hook = Reflect.get(window, '__skymap') as SkymapHook | undefined;
      if (!live || !hook) return;
      await hook.ready;
      dispatch(inspectClipPath('famousFlythrough'));
      dispatch(setClipPathScrub(t / FLY.total));
      await hook.nextFrame();
      await hook.nextFrame();
      if (live) window.location.hash = `pose=${EDIT_POSE}`;
    };
    void run();
    return () => {
      live = false;
    };
  }, [dispatch, t]);
  return (
    <>
      <StudioD
        state="overview"
        clip={{
          title: 'Famous galaxies (grand tour)',
          rows: flyRows(true),
          clipEnd: FLY.total,
          viewEnd: 125,
          major: 10,
          minor: 2,
          t,
          sel,
          status: 'saved',
          inset: new URL('./studio/assets/insets/m51.jpg', import.meta.url).href,
          undo: 'Undo',
          parentKinds: ['fly'],
          tall: ['fly'],
          track: (r, isSel) => (r.kind === 'start' ? undefined : <FlyPathTrack r={r} sel={isSel} selWp={wp} viewEnd={125} />),
          inspector: <FlyPathInspector wp={wp || undefined} />,
          legend: (
            <>
              <span className={sd.legendItem}><Glyph kind="pass" className={sd.lgIcon} />pass</span>
              <span className={sd.legendItem}><Glyph kind="settle" className={sd.lgIcon} />settle</span>
              <span className={sd.legendItem}><span className={cx(pl.sw, pl.route)} />route slow → fast</span>
              <span className={sd.legendItem}><span className={cx(pl.sw, pl.look)} />look-at</span>
              <span className={sd.legendItem}><span className={pl.frame} />frame</span>
            </>
          ),
        }}
      />
    </>
  );
}

export default Mock;
