import { useEffect } from 'react';
import cx from 'classnames';
import StudioD from './studio/StudioD';
import FlyPathTrack from './studio/marks/FlyPathTrack';
import FlyPathInspector from './studio/marks/FlyPathInspector';
import CameraInset from './studio/marks/CameraInset';
import Glyph from './studio/StudioDGlyph';
import { FLY, flyRows } from './studio/rows-famousFlythrough';
import { useAppDispatch, useAppSelector } from '../../store/hooks';
import { selectClipPathInspectId } from '../../state/settings/selectors';
import { inspectClipPath, setClipPathScrub } from '../../state/settings/core/debugSlice';
import inset from './studio/marks/inset-famous-52s.jpg';
import sd from './studio/StudioD.module.css';
import pl from './studio/marks/PathLegend.module.css';

// Q21 Edit view: the REAL clip-path overlay (route, look-at path, frustum) drawn around a free
// camera outside the route; the Camera view is the inset. the Whirlpool waypoint selected, playhead 23.4 s.
// The overlay is computed once (the live camera at that moment is the path's start) and its scrub
// follows the playhead: scrub01 = t / duration, until the store carries seconds.
function Mock() {
  const sel = 'wp-m51';
  const wp = 'wp-m51';
  const t = 23.4;
  const dispatch = useAppDispatch();
  const inspected = useAppSelector(selectClipPathInspectId);
  // Settings writes before the engine exists crash its saga, so wait for `window.__skymap`.
  useEffect(() => {
    const id = window.setInterval(() => {
      if (!('__skymap' in window)) return;
      window.clearInterval(id);
      if (inspected !== 'famousFlythrough') dispatch(inspectClipPath('famousFlythrough'));
      dispatch(setClipPathScrub(t / FLY.total));
    }, 1000);
    return () => window.clearInterval(id);
  }, [dispatch, inspected, t]);
  const time = (v: number) =>
    v < 60
      ? `${v.toFixed(1)} s`
      : `${Math.floor(v / 60)}:${Number.isInteger(v) ? String(v % 60).padStart(2, '0') : (v % 60).toFixed(1).padStart(4, '0')}`;
  return (
    <>
      <CameraInset src={inset} time={time(t)} bottom="calc(56% + var(--space-6))" />
      <StudioD
        state="overview"
        clip={{
          title: 'Famous galaxies (grand tour)',
          rows: flyRows(),
          clipEnd: FLY.total,
          viewEnd: 125,
          major: 10,
          minor: 2,
          t,
          sel,
          status: 'saved',
          undo: 'Undo',
          time,
          parentKinds: ['fly'],
          tall: ['fly'],
          cam: (
            <div className={sd.cam} role="radiogroup" aria-label="Main view">
              <button type="button" role="radio" aria-checked className={sd.camSeg}><Glyph kind="edit" className={sd.btnIcon} />Edit</button>
              <button type="button" role="radio" aria-checked={false} className={sd.camSeg}><Glyph kind="camera" className={sd.btnIcon} />Camera</button>
              <kbd className={sd.kbd}>F</kbd>
            </div>
          ),
          track: (r, isSel) => (r.kind === 'start' ? undefined : <FlyPathTrack r={r} sel={isSel} selWp={wp} viewEnd={125} />),
          inspector: <FlyPathInspector wp={wp || undefined} />,
          legend: (
            <>
              <span className={sd.legendItem}><Glyph kind="pass" className={sd.lgIcon} />pass</span>
              <span className={sd.legendItem}><Glyph kind="settle" className={sd.lgIcon} />settle</span>
              <span className={sd.legendItem}><span className={cx(pl.sw, pl.route)} />route slow → fast</span>
              <span className={sd.legendItem}><span className={cx(pl.sw, pl.look)} />look-at</span>
              <span className={sd.legendItem}><span className={pl.frame} />frame</span>
            </>
          ),
        }}
      />
    </>
  );
}

export default Mock;
