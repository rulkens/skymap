import StudioD from './studio/StudioD';

function Mock() {
  return <StudioD state="deep" />;
}

export default Mock;
