import StudioD from './studio/StudioD';

function Mock() {
  return <StudioD state="playing" />;
}

export default Mock;
