import StudioD from './studio/StudioD';

function Mock() {
  return <StudioD state="xfade-t1" />;
}

export default Mock;
