import StudioD from './studio/StudioD';

function Mock() {
  return <StudioD state="pip" />;
}

export default Mock;
