import StudioD from './studio/StudioD';

function Mock() {
  return <StudioD state="swapped" />;
}

export default Mock;
