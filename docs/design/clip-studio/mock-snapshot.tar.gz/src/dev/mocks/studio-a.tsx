import StudioA from './studio/StudioA';

function Mock() {
  return <StudioA />;
}

export default Mock;
