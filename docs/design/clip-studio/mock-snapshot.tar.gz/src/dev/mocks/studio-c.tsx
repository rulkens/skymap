import StudioC from './studio/StudioC';

function Mock() {
  return <StudioC />;
}

export default Mock;
