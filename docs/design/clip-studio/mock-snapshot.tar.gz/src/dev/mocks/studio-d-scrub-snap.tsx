import StudioD from './studio/StudioD';

function Mock() {
  return <StudioD state="scrub-snap" />;
}

export default Mock;
