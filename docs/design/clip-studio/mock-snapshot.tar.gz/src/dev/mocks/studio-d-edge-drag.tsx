import StudioD from './studio/StudioD';

function Mock() {
  return <StudioD state="edge-drag" />;
}

export default Mock;
