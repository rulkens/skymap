import StudioD from './studio/StudioD';
import ScaleDistInspector from './studio/marks/ScaleDistInspector';
import Glyph from './studio/StudioDGlyph';
import { sondermarkenRows } from './studio/rows-sondermarken';
import d from './studio/StudioD.module.css';

// sondermarkenFlyout at 35 s (16,941 km up): the 24-decade dolly selected.
function Mock() {
  return (
    <StudioD
      state="clip-sondermarken"
      clip={{
        title: 'Søndermarken to the Edge',
        rows: sondermarkenRows(),
        clipEnd: 97,
        viewEnd: 116,
        major: 10,
        minor: 2,
        t: 35,
        sel: 'dolly',
        inset: new URL('./studio/assets/insets/earth.jpg', import.meta.url).href,
        status: 'unsaved',
        undo: 'Undo distance',
        height: '44%',
        dated: 3,
        inspector: <ScaleDistInspector />,
        legend: (
          <>
            <span className={d.legendItem}><span className={d.frameChip}><Glyph kind="body" className={d.frameIcon} />Earth</span>body frame</span>
            <span className={d.legendItem}><Glyph kind="clock" className={d.datedIcon} />sim date</span>
          </>
        ),
      }}
    />
  );
}

export default Mock;
