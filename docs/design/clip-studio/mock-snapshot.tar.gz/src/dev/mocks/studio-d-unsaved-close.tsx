import StudioD from './studio/StudioD';

function Mock() {
  return <StudioD state="unsaved-close" />;
}

export default Mock;
