import StudioD from './studio/StudioD';

function Mock() {
  return <StudioD state="focus-ring" />;
}

export default Mock;
