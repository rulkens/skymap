import StudioD from './studio/StudioD';
import LiteralTurnInspector from './studio/marks/LiteralTurnInspector';
import { perseveranceRows } from './studio/rows-perseverance';
import { rulerSteps } from './studio/rulerSteps';

const time = (v: number) => (v >= 60 ? `${Math.floor(v / 60)}:${String(Math.round(v % 60)).padStart(2, '0')}` : `${+v.toFixed(1)} s`);

function Mock() {
  const fitEnd = 97 * 1.2;
  const { major, minor } = rulerSteps(fitEnd);
  return (
    <StudioD
      state="clip"
      clip={{
        title: 'Perseverance to Søndermarken',
        rows: perseveranceRows(),
        clipEnd: 97,
        viewEnd: fitEnd,
        major,
        minor,
        t: 41.3,
        sel: 'outDown',
        time,
        scroll: 0,
        undo: 'Undo aim',
        inspector: <LiteralTurnInspector which="aim" />,
      }}
    />
  );
}

export default Mock;
