import StudioD from './studio/StudioD';
import LiteralTurnInspector from './studio/marks/LiteralTurnInspector';
import { perseveranceRows } from './studio/rows-perseverance';
import { rulerSteps } from './studio/rulerSteps';

function Mock() {
  const fitEnd = 97 * 1.2;
  const { major, minor } = rulerSteps(fitEnd);
  return (
    <StudioD
      state="clip"
      clip={{
        title: 'Perseverance to Søndermarken',
        rows: perseveranceRows(),
        clipEnd: 97,
        viewEnd: fitEnd,
        major,
        minor,
        t: 41.3,
        sel: 'outDown',
        inset: new URL('./studio/assets/insets/mars.jpg', import.meta.url).href,
        scroll: 0,
        undo: 'Undo aim',
        inspector: <LiteralTurnInspector which="aim" />,
      }}
    />
  );
}

export default Mock;
