import StudioD from './studio/StudioD';
import BodyStartInspector from './studio/marks/BodyStartInspector';
import Glyph from './studio/StudioDGlyph';
import { sondermarkenRows } from './studio/rows-sondermarken';
import d from './studio/StudioD.module.css';

// sondermarkenFlyout at 0 s: the Earth-fixed, sim-date-dependent Start selected.
function Mock() {
  return (
    <StudioD
      state="clip-sondermarken-start"
      clip={{
        title: 'Søndermarken to the Edge',
        rows: sondermarkenRows(),
        clipEnd: 97,
        viewEnd: 116,
        major: 10,
        minor: 2,
        t: 0,
        sel: 'start',
        status: 'unsaved',
        undo: 'Undo distance',
        height: '52%',
        time: (v) => `${Math.floor(v / 60)}:${String(Math.round(v % 60)).padStart(2, '0')}`,
        saveNote: <span className={d.saveNote}>Makers → literals · <Glyph kind="clock" className={d.datedIcon} /> 3</span>,
        inspector: <BodyStartInspector />,
        legend: (
          <>
            <span className={d.legendItem}><span className={d.frameChip}><Glyph kind="body" className={d.frameIcon} />Earth</span>body frame</span>
            <span className={d.legendItem}><Glyph kind="clock" className={d.datedIcon} />sim date</span>
          </>
        ),
      }}
    />
  );
}

export default Mock;
