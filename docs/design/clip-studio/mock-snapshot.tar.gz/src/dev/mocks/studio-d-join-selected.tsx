import StudioD from './studio/StudioD';

function Mock() {
  return <StudioD state="join-selected" />;
}

export default Mock;
