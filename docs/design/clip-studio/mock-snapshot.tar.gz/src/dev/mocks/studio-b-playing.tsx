import StudioB from './studio/StudioB';

function Mock() {
  return <StudioB mode="playing" />;
}

export default Mock;
