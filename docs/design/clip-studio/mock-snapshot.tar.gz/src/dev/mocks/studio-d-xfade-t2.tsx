import StudioD from './studio/StudioD';

function Mock() {
  return <StudioD state="xfade-t2" />;
}

export default Mock;
