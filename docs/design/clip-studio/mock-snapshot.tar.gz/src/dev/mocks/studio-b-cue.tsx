import StudioB from './studio/StudioB';

function Mock() {
  return <StudioB mode="cue" />;
}

export default Mock;
