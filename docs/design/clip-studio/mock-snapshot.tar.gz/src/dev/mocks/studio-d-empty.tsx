import StudioD from './studio/StudioD';

function Mock() {
  return <StudioD state="empty" />;
}

export default Mock;
