import StudioD from './studio/StudioD';
import EndInspector from './studio/marks/EndInspector';
import { earthLoopRows } from './studio/rows-flowOrbit';
import s from './studio/StudioD.module.css';
import './studio/marks/hideInfoCard.css';

// earthCosmicWebLoop (`loop: true`, 148 s) at 2:12 with its End row selected: the wrap, the
// seam check, and the next cycle ghosted past the wrap.
const SEAM = [
  ['dist', 'Distance', '19,140', '19,140', 'km', '✓'],
  ['dist', 'Dist rate', '0', '0', '/s', '✓'],
  ['look', 'Look-at', 'Earth', 'Earth', '', '✓'],
  ['turn', 'Turn', '427.6', '67.6', '°', '✓'],
  ['turn', 'Turn rate', '2.43', '2.43', '°/s', '✓'],
  ['turn', 'Tilt', '29.7', '29.7', '°', '✓'],
  ['layers', 'Layers', 'labels off', 'off', '', '✓'],
] as const;

function Mock() {
  return (
    <StudioD
      state="clip-flowOrbit-loop"
      clip={{
        title: 'Earth ⇄ Cosmic web (loop)',
        rows: earthLoopRows(),
        clipEnd: 148,
        viewEnd: 172,
        major: 30,
        minor: 10,
        t: 132,
        sel: 'end',
        inset: new URL('./studio/assets/insets/earth.jpg', import.meta.url).href,
        status: 'saved',
        undo: 'Undo loop',
        loop: true,
        inspector: <EndInspector loop end="2:28.0" seam={SEAM} />,
        legend: (
          <>
            <span className={s.legendItem}>↺ wrap to 0:00.0</span>
            <span className={s.legendItem}>dim · next cycle</span>
          </>
        ),
      }}
    />
  );
}

export default Mock;
