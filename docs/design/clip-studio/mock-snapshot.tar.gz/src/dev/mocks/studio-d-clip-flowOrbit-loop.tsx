import StudioD from './studio/StudioD';
import EndInspector from './studio/marks/EndInspector';
import { earthLoopRows } from './studio/rows-flowOrbit';
import s from './studio/StudioD.module.css';
import './studio/marks/hideInfoCard.css';

// earthCosmicWebLoop (`loop: true`, 148 s) at 2:12 with its End row selected: the wrap, the
// seam check, and the next cycle ghosted past the wrap.
const clock = (v: number) => {
  const m = Math.floor(v / 60);
  const sec = v - m * 60;
  const ss = Number.isInteger(v) ? String(sec).padStart(2, '0') : sec.toFixed(1).padStart(4, '0');
  return m ? `${m}:${ss}` : `${Number.isInteger(v) ? v : v.toFixed(1)} s`;
};

const SEAM = [
  ['dist', 'Distance', '19,140', '19,140', 'km', '✓'],
  ['dist', 'Dist rate', '0', '0', '/s', '✓'],
  ['look', 'Look-at', 'Earth', 'Earth', '', '✓'],
  ['turn', 'Turn', '427.6', '67.6', '°', '✓'],
  ['turn', 'Turn rate', '2.43', '2.43', '°/s', '✓'],
  ['turn', 'Tilt', '29.7', '29.7', '°', '✓'],
  ['layers', 'Layers', 'labels off', 'off', '', '✓'],
] as const;

function Mock() {
  return (
    <StudioD
      state="clip-flowOrbit-loop"
      clip={{
        title: 'Earth ⇄ Cosmic web (loop)',
        rows: earthLoopRows(),
        clipEnd: 148,
        viewEnd: 172,
        major: 30,
        minor: 10,
        t: 132,
        sel: 'end',
        status: 'saved',
        undo: 'Undo loop',
        time: clock,
        loop: true,
        inspector: <EndInspector loop end="2:28.0" seam={SEAM} />,
        legend: (
          <>
            <span className={s.legendItem}>↺ wrap to 0 s</span>
            <span className={s.legendItem}>dim · next cycle</span>
          </>
        ),
      }}
    />
  );
}

export default Mock;
