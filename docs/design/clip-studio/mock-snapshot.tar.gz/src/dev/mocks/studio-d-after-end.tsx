import StudioD from './studio/StudioD';

function Mock() {
  return <StudioD state="after-end" />;
}

export default Mock;
