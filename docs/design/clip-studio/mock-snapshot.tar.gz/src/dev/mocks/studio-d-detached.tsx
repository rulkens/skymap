import StudioD from './studio/StudioD';

function Mock() {
  return <StudioD state="detached" />;
}

export default Mock;
