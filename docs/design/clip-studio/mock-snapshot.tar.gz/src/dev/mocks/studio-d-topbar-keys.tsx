import StudioD from './studio/StudioD';
import TopBarContext from './studio/TopBarContext';

function Mock() {
  return (
    <TopBarContext.Provider value={{ variant: 'b', keysOpen: true }}>
      <StudioD state="overview" />
    </TopBarContext.Provider>
  );
}

export default Mock;
