import StudioD from './studio/StudioD';

function Mock() {
  return <StudioD state="group-selected" />;
}

export default Mock;
