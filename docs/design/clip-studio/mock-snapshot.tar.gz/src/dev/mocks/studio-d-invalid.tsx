import StudioD from './studio/StudioD';

function Mock() {
  return <StudioD state="invalid" />;
}

export default Mock;
