import StudioD from './studio/StudioD';
import TopBarContext from './studio/TopBarContext';

function Mock() {
  return (
    <TopBarContext.Provider value={{ variant: 'b', tips: ['play', 'undo'] }}>
      <StudioD state="pip" />
    </TopBarContext.Provider>
  );
}

export default Mock;
