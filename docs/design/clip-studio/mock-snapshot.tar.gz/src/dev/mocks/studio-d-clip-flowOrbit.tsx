import StudioD from './studio/StudioD';
import PerpetualInspector from './studio/marks/PerpetualInspector';
import { flowOrbitRows } from './studio/rows-flowOrbit';
import s from './studio/StudioD.module.css';

// flowOrbit at 21.3 s: the forked perpetual bob (Dur ∞) selected; End is a plain stop.
function Mock() {
  return (
    <StudioD
      state="clip-flowOrbit"
      clip={{
        title: 'Flow Orbit',
        rows: flowOrbitRows(),
        clipEnd: 30,
        viewEnd: 36,
        major: 5,
        minor: 1,
        t: 21.3,
        sel: 'bob',
        status: 'unsaved',
        height: '40%',
        undo: 'Undo swing',
        inspector: <PerpetualInspector />,
        legend: (
          <>
            <span className={s.legendItem}>∞ perpetual</span>
            <span className={s.legendItem}>⫽ cut at End</span>
          </>
        ),
      }}
    />
  );
}

export default Mock;
