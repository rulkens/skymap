import StudioD from './studio/StudioD';
import FlyPathTrack from './studio/marks/FlyPathTrack';
import FlyPathInspector from './studio/marks/FlyPathInspector';
import Glyph from './studio/StudioDGlyph';
import { FLY, flyRows } from './studio/rows-famousFlythrough';
import sd from './studio/StudioD.module.css';

// famousFlythrough: one flyPath through 12 famous galaxies. Selected: the path, playhead approaching M83.
function Mock() {
  const sel = 'fly';
  const wp = '';
  const t = 52.0;
  return (
    <StudioD
      state="overview"
      clip={{
        title: 'Famous galaxies (grand tour)',
        rows: flyRows(),
        clipEnd: FLY.total,
        viewEnd: 125,
        major: 10,
        minor: 2,
        t,
        sel,
        status: 'saved',
        undo: 'Undo',
        // Under 60 s: seconds with tenths; from 60 s: m:ss, tenths only off the whole second (ruler).
        time: (v) =>
          v < 60
            ? `${v.toFixed(1)} s`
            : `${Math.floor(v / 60)}:${Number.isInteger(v) ? String(v % 60).padStart(2, '0') : (v % 60).toFixed(1).padStart(4, '0')}`,
        parentKinds: ['fly'],
        tall: ['fly'],
        track: (r, isSel) => (r.kind === 'start' ? undefined : <FlyPathTrack r={r} sel={isSel} selWp={wp} viewEnd={125} />),
        inspector: <FlyPathInspector wp={wp || undefined} />,
        legend: (
          <>
            <span className={sd.legendItem}><Glyph kind="pass" className={sd.lgIcon} />pass</span>
            <span className={sd.legendItem}><Glyph kind="settle" className={sd.lgIcon} />settle</span>
          </>
        ),
      }}
    />
  );
}

export default Mock;
