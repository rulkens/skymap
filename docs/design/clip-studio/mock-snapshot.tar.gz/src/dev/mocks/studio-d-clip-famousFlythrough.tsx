import StudioD from './studio/StudioD';
import FlyPathTrack from './studio/marks/FlyPathTrack';
import FlyPathInspector from './studio/marks/FlyPathInspector';
import Glyph from './studio/StudioDGlyph';
import { FLY, flyRows } from './studio/rows-famousFlythrough';
import sd from './studio/StudioD.module.css';

// famousFlythrough: one flyPath through 12 famous galaxies. Selected: the path, playhead approaching M83.
function Mock() {
  const sel = 'fly';
  const wp = '';
  const t = 52.0;
  return (
    <StudioD
      state="overview"
      clip={{
        title: 'Famous galaxies (grand tour)',
        rows: flyRows(),
        clipEnd: FLY.total,
        viewEnd: 125,
        major: 10,
        minor: 2,
        t,
        sel,
        status: 'saved',
        inset: new URL('./studio/assets/insets/m83.jpg', import.meta.url).href,
        undo: 'Undo',
        parentKinds: ['fly'],
        tall: ['fly'],
        track: (r, isSel) => (r.kind === 'start' ? undefined : <FlyPathTrack r={r} sel={isSel} selWp={wp} viewEnd={125} />),
        inspector: <FlyPathInspector wp={wp || undefined} />,
        legend: (
          <>
            <span className={sd.legendItem}><Glyph kind="pass" className={sd.lgIcon} />pass</span>
            <span className={sd.legendItem}><Glyph kind="settle" className={sd.lgIcon} />settle</span>
          </>
        ),
      }}
    />
  );
}

export default Mock;
