import StudioDWindow from './studio/StudioDWindow';

function Mock() {
  return <StudioDWindow />;
}

export default Mock;
