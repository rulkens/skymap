import TipSheet from './studio/StudioTipSheet';
import StudioD from './studio/StudioD';

function Mock() {
  return (
    <>
      <StudioD state="overview" />
      <TipSheet />
    </>
  );
}

export default Mock;
