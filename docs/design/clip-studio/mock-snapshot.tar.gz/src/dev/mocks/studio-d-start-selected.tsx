import StudioD from './studio/StudioD';

function Mock() {
  return <StudioD state="start-selected" />;
}

export default Mock;
