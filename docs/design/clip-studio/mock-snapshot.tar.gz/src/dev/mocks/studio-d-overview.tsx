import StudioD from './studio/StudioD';

function Mock() {
  return <StudioD state="overview" />;
}

export default Mock;
