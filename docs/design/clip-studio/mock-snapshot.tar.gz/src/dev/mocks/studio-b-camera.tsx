import StudioB from './studio/StudioB';

function Mock() {
  return <StudioB mode="camera" />;
}

export default Mock;
