import StudioD from './studio/StudioD';
import CutOffInspector from './studio/marks/CutOffInspector';
import { deepFieldRows } from './studio/rows-deepField';
import { rulerSteps } from './studio/rulerSteps';

function Mock() {
  const { major, minor } = rulerSteps(7.2);
  return (
    <StudioD
      state="clip"
      clip={{
        title: 'Grand tour 11 — deep field',
        rows: deepFieldRows(),
        clipEnd: 4,
        viewEnd: 7.2,
        major,
        minor,
        t: 2.4,
        sel: 'quasars',
        undo: 'Undo over',
        inspector: <CutOffInspector />,
      }}
    />
  );
}

export default Mock;
