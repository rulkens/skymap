import StudioD from './studio/StudioD';
import LiteralTurnInspector from './studio/marks/LiteralTurnInspector';
import { perseveranceRows } from './studio/rows-perseverance';
import { rulerSteps } from './studio/rulerSteps';

// 4× on the outbound leg's last third: the swing (36–48 s), the system hold and the inbound start.
function Mock() {
  const fitEnd = 97 * 1.2;
  const [a, z] = [30, 30 + fitEnd / 4];
  const { major, minor } = rulerSteps(z - a);
  return (
    <StudioD
      state="clip"
      clip={{
        title: 'Perseverance to Søndermarken',
        rows: perseveranceRows(),
        clipEnd: 97,
        viewStart: a,
        viewEnd: z,
        fitEnd,
        zoom: '4×',
        major,
        minor,
        t: 41.3,
        sel: 'outSwingRoll',
        inset: new URL('./studio/assets/insets/mars.jpg', import.meta.url).href,
        scroll: 6,
        undo: 'Undo roll',
        inspector: <LiteralTurnInspector which="roll" />,
      }}
    />
  );
}

export default Mock;
