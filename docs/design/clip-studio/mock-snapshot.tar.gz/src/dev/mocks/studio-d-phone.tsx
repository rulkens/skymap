import StudioDPhone from './studio/StudioDPhone';

function Mock() {
  return <StudioDPhone />;
}

export default Mock;
